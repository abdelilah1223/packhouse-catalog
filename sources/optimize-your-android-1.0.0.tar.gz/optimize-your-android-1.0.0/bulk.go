package main

import (
	"fmt"
	"os"
	"path/filepath"
	"runtime"
	"strings"
	"sync"
)

// Bulk transfers for the recovery and file-browser views: save many files to a
// PC folder the user picks, or copy many files into a device folder the user
// picks — both with the same live progress events as backup/restore.

// cleanPaths trims, drops empties and de-duplicates while keeping order.
func cleanPaths(paths []string) []string {
	result := make([]string, 0, len(paths))
	seen := map[string]bool{}
	for _, path := range paths {
		path = strings.TrimSpace(path)
		if path == "" || seen[path] {
			continue
		}
		seen[path] = true
		result = append(result, path)
	}
	return result
}

// uniqueDestName avoids silent overwrites when files from different folders
// share a name: the second IMG_0001.jpg becomes <parent>_IMG_0001.jpg, the third
// gets a numeric prefix.
func uniqueDestName(dir string, remotePath string, taken map[string]bool) string {
	name := remoteBaseName(remotePath)
	if name == "" {
		name = "file"
	}
	dest := filepath.Join(dir, name)
	if !taken[strings.ToLower(dest)] {
		taken[strings.ToLower(dest)] = true
		return dest
	}
	parent := sanitizeFileComponent(remoteBaseName(filepath.ToSlash(filepath.Dir(remotePath))))
	if parent != "" && parent != "item" {
		alt := filepath.Join(dir, parent+"_"+name)
		if !taken[strings.ToLower(alt)] {
			taken[strings.ToLower(alt)] = true
			return alt
		}
	}
	for i := 2; ; i++ {
		alt := filepath.Join(dir, fmt.Sprintf("%d_%s", i, name))
		if !taken[strings.ToLower(alt)] {
			taken[strings.ToLower(alt)] = true
			return alt
		}
	}
}

// SaveFilesToPC pulls the given remote files into localDir with live progress.
// Returns a summary with the destination folder and per-file failures.
func (a *App) SaveFilesToPC(paths []string, localDir string) (*TransferResult, error) {
	if err := a.requireAnyDevice(); err != nil {
		return nil, err
	}
	if strings.TrimSpace(localDir) == "" {
		localDir = "./device-files"
	}
	if err := os.MkdirAll(localDir, 0o755); err != nil {
		return nil, fmt.Errorf("failed to create the destination folder: %v", err)
	}

	clean := cleanPaths(paths)
	result := &TransferResult{Operation: "export", TargetFolder: localDir, TotalFiles: len(clean)}
	reporter := newProgressReporter(a, "export", len(clean))
	if len(clean) == 0 {
		reporter.finish("Nothing to save.")
		return result, nil
	}

	taken := map[string]bool{}
	destinations := make([]string, len(clean))
	for i, path := range clean {
		destinations[i] = uniqueDestName(localDir, path, taken)
	}

	workers := runtime.NumCPU()
	if workers < 2 {
		workers = 2
	}
	if workers > 6 {
		workers = 6
	}
	jobCh := make(chan int, workers)
	var mu sync.Mutex
	var wg sync.WaitGroup

	for w := 0; w < workers; w++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for i := range jobCh {
				path := clean[i]
				dest := destinations[i]
				if _, err := executeADB("pull", path, dest); err != nil {
					reporter.addFailed()
					mu.Lock()
					result.Failed++
					if len(result.Errors) < 40 {
						result.Errors = append(result.Errors, fmt.Sprintf("%s: %v", path, err))
					}
					mu.Unlock()
				} else {
					if size, err := remoteFileSize(path); err == nil {
						reporter.addBytes(size)
						mu.Lock()
						result.Bytes += size
					} else {
						mu.Lock()
					}
					result.Copied++
					mu.Unlock()
				}
				reporter.report("copying", "", remoteBaseName(path), false, "")
			}
		}()
	}

	for i := range clean {
		jobCh <- i
	}
	close(jobCh)
	wg.Wait()

	message := fmt.Sprintf("Saved %d of %d files to %s", result.Copied, result.TotalFiles, localDir)
	if result.Failed > 0 {
		message += fmt.Sprintf(" (%d failed)", result.Failed)
	}
	reporter.finish(message)
	return result, nil
}

// RestoreFilesToDevice copies the given remote files (device -> device) into
// targetFolder, which the user picks in the UI. Existing files are never
// overwritten; name clashes get a unique name.
func (a *App) RestoreFilesToDevice(paths []string, targetFolder string) (*TransferResult, error) {
	if err := a.requireAnyDevice(); err != nil {
		return nil, err
	}
	targetFolder = strings.TrimSpace(targetFolder)
	if targetFolder == "" {
		targetFolder = "/sdcard/Recovered"
	}
	targetFolder = strings.TrimRight(targetFolder, "/")
	if targetFolder == "" {
		targetFolder = "/sdcard/Recovered"
	}
	if _, err := executeADB("shell", "mkdir", "-p", deviceQuote(targetFolder)); err != nil {
		return nil, fmt.Errorf("failed to create %s on the device: %v", targetFolder, err)
	}

	clean := cleanPaths(paths)
	result := &TransferResult{Operation: "device-restore", TargetFolder: targetFolder, TotalFiles: len(clean)}
	reporter := newProgressReporter(a, "device-restore", len(clean))
	if len(clean) == 0 {
		reporter.finish("Nothing to restore.")
		return result, nil
	}

	// Resolve clashes up front so nothing is silently skipped: probe the device
	// for existing names, then pre-compute unique target names.
	existing := map[string]bool{}
	sem := make(chan struct{}, 8)
	var probeWG sync.WaitGroup
	for _, path := range clean {
		probeWG.Add(1)
		sem <- struct{}{}
		go func(p string) {
			defer probeWG.Done()
			defer func() { <-sem }()
			if ok, err := a.RemotePathExists(targetFolder + "/" + remoteBaseName(p)); err == nil && ok {
				existing[p] = true
			}
		}(path)
	}
	probeWG.Wait()

	targets := make([]string, len(clean))
	taken := map[string]bool{}
	for i, path := range clean {
		name := remoteBaseName(path)
		if existing[path] {
			parent := sanitizeFileComponent(remoteBaseName(filepath.ToSlash(filepath.Dir(path))))
			if parent != "" && parent != "item" {
				name = parent + "_" + name
			} else {
				name = "copy_" + name
			}
		}
		if taken[strings.ToLower(name)] {
			name = uniqueDestName("", filepath.ToSlash(filepath.Dir(path))+"/x_"+name, taken)
			name = filepath.Base(name)
		} else {
			taken[strings.ToLower(name)] = true
		}
		targets[i] = targetFolder + "/" + name
	}

	workers := runtime.NumCPU()
	if workers < 2 {
		workers = 2
	}
	if workers > 6 {
		workers = 6
	}
	jobCh := make(chan int, workers)
	var mu sync.Mutex
	var wg sync.WaitGroup

	for w := 0; w < workers; w++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for i := range jobCh {
				source := clean[i]
				target := targets[i]
				if _, err := executeADB("shell", "cp", "-n", deviceQuote(source), deviceQuote(target)); err != nil {
					reporter.addFailed()
					mu.Lock()
					result.Failed++
					if len(result.Errors) < 40 {
						result.Errors = append(result.Errors, fmt.Sprintf("%s: %v", source, err))
					}
					mu.Unlock()
				} else {
					if size, err := remoteFileSize(source); err == nil {
						reporter.addBytes(size)
						mu.Lock()
						result.Bytes += size
					} else {
						mu.Lock()
					}
					result.Copied++
					mu.Unlock()
				}
				reporter.report("copying", "", remoteBaseName(source), false, "")
			}
		}()
	}

	for i := range clean {
		jobCh <- i
	}
	close(jobCh)
	wg.Wait()

	message := fmt.Sprintf("Copied %d of %d files to %s", result.Copied, result.TotalFiles, targetFolder)
	if result.Failed > 0 {
		message += fmt.Sprintf(" (%d failed)", result.Failed)
	}
	reporter.finish(message)
	return result, nil
}
