package main

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"time"

	wruntime "github.com/wailsapp/wails/v2/pkg/runtime"
)

// sessionVersion invalidates cached sessions when the shape of the data changes.
const sessionVersion = "1"

// SessionIcon is one cached app icon. The data URL lets the UI render instantly
// without touching the device, and FilePath points at the saved image on disk.
type SessionIcon struct {
	PackageName string `json:"packageName"`
	DataURL     string `json:"dataUrl"`
	Source      string `json:"source"`
	FilePath    string `json:"filePath"`
}

// DeviceSession is everything the app needs for a fast start-up after the phone
// has been read once: the app list, the first file-browser listings and icons.
type DeviceSession struct {
	Version   string                        `json:"version"`
	Serial    string                        `json:"serial"`
	Model     string                        `json:"model"`
	Apps      []AppInfo                     `json:"apps"`
	FileRoot  string                        `json:"fileRoot"`
	FileRoots map[string][]AndroidFileEntry `json:"fileRoots"`
	Icons     []SessionIcon                 `json:"icons"`
	IconMode  string                        `json:"iconMode"`
	SavedAt   string                        `json:"savedAt"`
	FromCache bool                          `json:"fromCache"`
}

// PrepareRequest tells PrepareSession what to load and how to extract icons.
type PrepareRequest struct {
	IncludeApps   bool   `json:"includeApps"`
	IncludeFiles  bool   `json:"includeFiles"`
	IconMode      string `json:"iconMode"` // "fast" | "apk"
	APKFolder     string `json:"apkFolder"`
	Workers       int    `json:"workers"`
	GenericSystem bool   `json:"genericSystem"`
	ForceRefresh  bool   `json:"forceRefresh"`
	FileRoot      string `json:"fileRoot"`
}

// SessionProgress is streamed to the "getting data ready" waiting screen.
type SessionProgress struct {
	Stage     string `json:"stage"`
	Message   string `json:"message"`
	Completed int    `json:"completed"`
	Total     int    `json:"total"`
	Percent   int    `json:"percent"`
	Done      bool   `json:"done"`
}

// sessionCachePath is where a device's session lives. The file is keyed by the
// device model (falling back to the serial) so a phone that was plugged in before
// is recognised even when its ADB serial changes — which happens every time a
// device switches between USB and Wi-Fi debugging.
func sessionCachePath(serial, model string) string {
	key := strings.TrimSpace(model)
	if key == "" {
		key = strings.TrimSpace(serial)
	}
	if key == "" {
		key = "unknown-device"
	}
	return filepath.Join(appCacheDir("sessions"), sanitizeFileComponent(key)+".json")
}

// sessionMatches reports whether a cached session belongs to this device. The
// serial is exact; the model is a case-insensitive secondary identity, so a
// phone whose serial changed still finds the cache saved on an earlier visit.
func sessionMatches(session *DeviceSession, serial, model string) bool {
	if session == nil {
		return false
	}
	if strings.TrimSpace(serial) != "" && session.Serial == serial {
		return true
	}
	m := strings.TrimSpace(model)
	return m != "" && strings.EqualFold(session.Model, m)
}

func (a *App) emitSessionProgress(progress SessionProgress) {
	if a.ctx == nil {
		return
	}
	wruntime.EventsEmit(a.ctx, "session:progress", progress)
}

// reusableSessionIcon reports whether a previously saved icon can be trusted on
// a repeat launch. Real extractions ("fast", "apk", "cache") and the generic
// icon of a system app are conclusive. A "generic" fallback is only reusable
// when the per-package icon cache recorded the same verdict — otherwise it was
// a failure (timeout, unplugged cable) and that app deserves another attempt
// instead of being stuck on the generic icon forever.
func reusableSessionIcon(icon SessionIcon) bool {
	if strings.TrimSpace(icon.DataURL) == "" {
		return false
	}
	switch icon.Source {
	case "fast", "apk", "cache", "system":
		return true
	case "generic":
		_, ok := readIconCache(icon.PackageName)
		return ok
	}
	return false
}

// loadCachedSession reads a previously saved session for the given device.
// Lookup order: the model/serial keyed file first, then a scan of the session
// folder for any entry that identifies the same device (covers sessions written
// under an older key scheme or a serial that has since changed).
func (a *App) loadCachedSession(serial, model string) (*DeviceSession, bool) {
	read := func(path string) (*DeviceSession, bool) {
		bytes, err := os.ReadFile(path)
		if err != nil {
			return nil, false
		}
		var session DeviceSession
		if err := json.Unmarshal(bytes, &session); err != nil {
			return nil, false
		}
		if session.Version != sessionVersion {
			return nil, false
		}
		if !sessionMatches(&session, serial, model) {
			return nil, false
		}
		return &session, true
	}

	if strings.TrimSpace(serial) == "" && strings.TrimSpace(model) == "" {
		return nil, false
	}
	if session, ok := read(sessionCachePath(serial, model)); ok {
		return session, true
	}

	dir := appCacheDir("sessions")
	entries, err := os.ReadDir(dir)
	if err != nil {
		return nil, false
	}
	for _, entry := range entries {
		if entry.IsDir() || !strings.HasSuffix(entry.Name(), ".json") {
			continue
		}
		if session, ok := read(filepath.Join(dir, entry.Name())); ok {
			return session, true
		}
	}
	return nil, false
}

func (a *App) saveSession(session *DeviceSession) error {
	if session == nil || strings.TrimSpace(session.Serial) == "" {
		return fmt.Errorf("nothing to save")
	}
	session.Version = sessionVersion
	session.SavedAt = time.Now().Format(time.RFC3339)
	session.FromCache = false
	bytes, err := json.Marshal(session)
	if err != nil {
		return err
	}
	path := sessionCachePath(session.Serial, session.Model)
	if err := os.MkdirAll(filepath.Dir(path), 0o755); err != nil {
		return err
	}
	return os.WriteFile(path, bytes, 0o644)
}

// currentSerial returns the id of the best attached device, if any.
func (a *App) currentSerial() (serial, model string) {
	devices, err := a.GetConnectedDevices()
	if err != nil {
		return "", ""
	}
	for _, device := range devices {
		if device.Status == "device" {
			return device.ID, device.Model
		}
	}
	if len(devices) > 0 {
		return devices[0].ID, devices[0].Model
	}
	return "", ""
}

// GetCachedSession returns the cached data for the attached device so the UI can
// render instantly on start-up. A nil result simply means "nothing cached yet" —
// it is never an error, so start-up cannot fail because of a missing cache.
func (a *App) GetCachedSession() (*DeviceSession, error) {
	serial, model := a.currentSerial()
	if serial == "" && model == "" {
		return nil, nil
	}
	session, ok := a.loadCachedSession(serial, model)
	if !ok {
		return nil, nil
	}
	session.FromCache = true
	return session, nil
}

// ClearSessionCache removes every cached session so the next start reads the
// device from scratch.
func (a *App) ClearSessionCache() error {
	dir := appCacheDir("sessions")
	entries, err := os.ReadDir(dir)
	if err != nil {
		return err
	}
	for _, entry := range entries {
		_ = os.RemoveAll(filepath.Join(dir, entry.Name()))
	}
	return nil
}

// PrepareSession is the "getting data ready" step: it loads the app list, warms
// the file browser and extracts icons, then saves everything so the next launch
// is instant. Progress is streamed on the session:progress event.
func (a *App) PrepareSession(req PrepareRequest) (*DeviceSession, error) {
	if err := a.requireAnyDevice(); err != nil {
		return nil, err
	}

	serial, model := a.currentSerial()
	root := strings.TrimSpace(req.FileRoot)
	if root == "" {
		root = "/sdcard"
	}
	root = normalizeAndroidPath(root)

	iconMode := strings.ToLower(strings.TrimSpace(req.IconMode))
	if iconMode != "apk" {
		iconMode = "fast"
	}

	session := &DeviceSession{
		Version:   sessionVersion,
		Serial:    serial,
		Model:     model,
		FileRoot:  root,
		FileRoots: map[string][]AndroidFileEntry{},
		IconMode:  iconMode,
	}

	var cached *DeviceSession
	if !req.ForceRefresh {
		if found, ok := a.loadCachedSession(serial, model); ok {
			cached = found
		}
	}

	// --- apps ---------------------------------------------------------------
	// The app list and the file browser are always read from the device: they
	// are cheap and must reflect reality. Only icons are served from the cache
	// (see below), so a repeat launch never waits on icon extraction again.
	a.emitSessionProgress(SessionProgress{Stage: "apps", Message: "Reading installed apps", Percent: 5})
	if req.IncludeApps {
		apps, err := a.getInstalledApps(func(message string, percent int) {
			a.emitSessionProgress(SessionProgress{Stage: "apps", Message: message, Percent: percent})
		})
		if err != nil {
			return nil, fmt.Errorf("reading installed apps: %w", err)
		}
		session.Apps = apps
	} else if cached != nil {
		session.Apps = cached.Apps
	}
	a.emitSessionProgress(SessionProgress{
		Stage: "apps", Message: "Installed apps read", Percent: 20,
		Completed: len(session.Apps), Total: len(session.Apps),
	})

	// --- file browser -------------------------------------------------------
	// Cached listings seed the map first: a listing the device cannot answer
	// right now keeps its previous value instead of vanishing, while fresh reads
	// always win over the cache.
	if cached != nil {
		for path, list := range cached.FileRoots {
			session.FileRoots[path] = list
		}
	}
	if req.IncludeFiles {
		a.emitSessionProgress(SessionProgress{Stage: "files", Message: "Reading the file browser", Percent: 25})
		entries, err := remoteListDir(root)
		if err != nil {
			// Warming the file browser is not a hard dependency: report the
			// problem and keep whatever the cache already had.
			if _, cachedRoot := session.FileRoots[root]; !cachedRoot {
				a.emitSessionProgress(SessionProgress{Stage: "files", Message: "File browser unavailable: " + err.Error(), Percent: 30})
			}
		} else {
			list := make([]AndroidFileEntry, 0, len(entries))
			for _, entry := range entries {
				list = append(list, entryToAndroidFile(entry))
			}
			session.FileRoots[root] = list

			dirs := make([]string, 0, 8)
			for _, entry := range list {
				if entry.IsDir && len(dirs) < 8 {
					dirs = append(dirs, entry.Path)
				}
			}
			if len(dirs) > 0 {
				if prefetched, err := a.PrefetchAndroidFiles(dirs); err == nil {
					for path, prefetchedList := range prefetched {
						session.FileRoots[path] = prefetchedList
					}
				}
			}
		}
	}
	a.emitSessionProgress(SessionProgress{Stage: "files", Message: "File browser ready", Percent: 32})

	// --- icons --------------------------------------------------------------
	// Icons are the only data served from the cache: anything already read for
	// this device is reused and only packages that are new — or whose icon
	// could not be read last time — are extracted. A repeat launch therefore
	// never waits on re-extracting hundreds of icons.
	if len(session.Apps) > 0 {
		reused := map[string]SessionIcon{}
		if cached != nil && !req.ForceRefresh {
			for _, icon := range cached.Icons {
				if reusableSessionIcon(icon) {
					reused[icon.PackageName] = icon
				}
			}
		}
		missing := make([]AppInfo, 0, len(session.Apps))
		for _, app := range session.Apps {
			if _, ok := reused[app.PackageName]; !ok {
				missing = append(missing, app)
			}
		}

		if len(reused) > 0 {
			a.emitSessionProgress(SessionProgress{
				Stage:     "icons",
				Message:   fmt.Sprintf("%d of %d icons already cached", len(reused), len(session.Apps)),
				Percent:   35,
				Completed: len(reused),
				Total:     len(session.Apps),
			})
		} else {
			a.emitSessionProgress(SessionProgress{
				Stage:   "icons",
				Message: "Extracting app icons",
				Percent: 35,
				Total:   len(session.Apps),
			})
		}

		byPackage := map[string]IconExtractResult{}
		failed := 0
		if len(missing) > 0 {
			results := a.extractIcons(missing, IconExtractRequest{
				Mode:          iconMode,
				APKFolder:     req.APKFolder,
				Workers:       req.Workers,
				SkipCached:    !req.ForceRefresh,
				GenericSystem: req.GenericSystem,
			}, 35, 95)
			for _, result := range results {
				byPackage[result.PackageName] = result
				if result.Error != "" {
					failed++
				}
			}
		}

		icons := make([]SessionIcon, 0, len(session.Apps))
		for _, app := range session.Apps {
			if icon, ok := reused[app.PackageName]; ok {
				icons = append(icons, icon)
				continue
			}
			result, ok := byPackage[app.PackageName]
			if !ok {
				// Never leave a row without an icon, even when extraction was
				// skipped for this package.
				result = IconExtractResult{
					PackageName: app.PackageName,
					Source:      "generic",
					Error:       "icon was not extracted",
				}
				failed++
			}
			if result.DataURL == "" {
				result.DataURL = systemAppIconDataURL()
				result.FilePath = systemAppIconFile()
				if result.Source == "" {
					result.Source = "generic"
				}
			}
			icons = append(icons, SessionIcon{
				PackageName: result.PackageName,
				DataURL:     result.DataURL,
				Source:      result.Source,
				FilePath:    result.FilePath,
			})
		}
		session.Icons = icons

		if failed > 0 {
			a.emitSessionProgress(SessionProgress{
				Stage:     "icons",
				Message:   fmt.Sprintf("%d icons could not be read — the Android icon is used instead", failed),
				Percent:   95,
				Completed: len(session.Apps),
				Total:     len(session.Apps),
			})
		}
	}

	// --- persist ------------------------------------------------------------
	a.emitSessionProgress(SessionProgress{Stage: "saving", Message: "Saving cache for next time", Percent: 97})
	if err := a.saveSession(session); err != nil {
		// A cache write failure must not break the flow; the data is still usable.
		a.emitSessionProgress(SessionProgress{Stage: "saving", Message: "Cache could not be written: " + err.Error(), Percent: 98})
	}

	a.emitSessionProgress(SessionProgress{Stage: "done", Message: "Data ready", Percent: 100, Done: true})
	return session, nil
}
