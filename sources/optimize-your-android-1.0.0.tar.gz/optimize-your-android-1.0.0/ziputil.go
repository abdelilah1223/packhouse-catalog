package main

import (
	"archive/zip"
	"fmt"
	"io"
)

// localZipEntries lists entries of a zip/APK already on the host.
func localZipEntries(path string) ([]apkEntry, error) {
	reader, err := zip.OpenReader(path)
	if err != nil {
		return nil, err
	}
	defer reader.Close()

	entries := make([]apkEntry, 0, len(reader.File))
	for _, file := range reader.File {
		entries = append(entries, apkEntry{name: file.Name, size: int64(file.UncompressedSize64)})
	}
	return entries, nil
}

// readLocalZipEntry reads a single entry out of a zip/APK on the host.
func readLocalZipEntry(path, entryName string) ([]byte, error) {
	reader, err := zip.OpenReader(path)
	if err != nil {
		return nil, err
	}
	defer reader.Close()

	for _, file := range reader.File {
		if file.Name != entryName {
			continue
		}
		handle, err := file.Open()
		if err != nil {
			return nil, err
		}
		defer handle.Close()
		return io.ReadAll(handle)
	}
	return nil, fmt.Errorf("entry %q not found in %s", entryName, path)
}
