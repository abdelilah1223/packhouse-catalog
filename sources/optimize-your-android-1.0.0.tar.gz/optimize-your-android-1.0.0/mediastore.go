package main

import (
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"sync"
)

// Android's media scanner keeps ready-made thumbnails for every image and video
// it has indexed. Reading those costs one content-provider query and one tiny
// pull — no ffmpeg on the PC and no pull of the (possibly huge) media file, so
// this is the fastest thumbnail source on most devices.

type mediaStoreIndex struct {
	thumbByPath map[string]string // normalized media path -> thumbnail path on device
}

var (
	mediaStoreMu    sync.Mutex
	mediaStoreCache = map[string]*mediaStoreIndex{} // "images" | "videos"
)

// normalizeMediaPath makes MediaStore paths comparable with browser paths:
// /sdcard/... and /storage/emulated/0/... are the same folder.
func normalizeMediaPath(path string) string {
	path = filepath.ToSlash(strings.TrimSpace(path))
	lower := strings.ToLower(path)
	switch {
	case strings.HasPrefix(lower, "/sdcard/"):
		return "/storage/emulated/0" + path[len("/sdcard"):]
	case lower == "/sdcard":
		return "/storage/emulated/0"
	case strings.HasPrefix(lower, "/storage/self/primary/"):
		return "/storage/emulated/0" + path[len("/storage/self/primary"):]
	}
	return path
}

// parseContentRows turns `content query` output ("Row: 0 _id=12, _data=/x/y")
// into key/value maps, one per row.
func parseContentRows(out string) []map[string]string {
	rows := make([]map[string]string, 0, 32)
	for _, line := range strings.Split(out, "\n") {
		line = strings.TrimSpace(line)
		if line == "" {
			continue
		}
		if strings.HasPrefix(line, "Row:") {
			line = strings.TrimSpace(strings.TrimPrefix(line, "Row:"))
			// Drop the row number: "Row: 0 _id=12" -> "_id=12".
			if idx := strings.Index(line, " "); idx >= 0 {
				line = line[idx+1:]
			}
		}
		values := map[string]string{}
		for _, part := range strings.Split(line, ",") {
			part = strings.TrimSpace(part)
			if eq := strings.Index(part, "="); eq >= 0 {
				values[strings.TrimSpace(part[:eq])] = strings.TrimSpace(part[eq+1:])
			}
		}
		if len(values) > 0 {
			rows = append(rows, values)
		}
	}
	return rows
}

// queryMediaStoreMap runs one content query returning (id -> column) pairs.
func queryMediaStoreMap(uri string, projection string, idColumn string, valueColumn string) (map[string]string, bool) {
	out, err := executeADB("shell", "content", "query", "--uri", uri, "--projection", projection)
	if err != nil {
		return nil, false
	}
	result := map[string]string{}
	for _, row := range parseContentRows(out) {
		id := row[idColumn]
		value := row[valueColumn]
		if id != "" && value != "" {
			result[id] = value
		}
	}
	return result, true
}

// loadMediaStoreIndex joins a media table with its thumbnail table once:
// images:  content://media/external/images/media     (_id, _data)
//
//	content://media/external/images/thumbnails (image_id, _data)
//
// videos use the matching video tables. A failed query is remembered as empty so
// every later thumbnail call does not retry it.
func loadMediaStoreIndex(kind string) *mediaStoreIndex {
	mediaStoreMu.Lock()
	defer mediaStoreMu.Unlock()
	if index, ok := mediaStoreCache[kind]; ok {
		return index
	}

	index := &mediaStoreIndex{thumbByPath: map[string]string{}}
	mediaStoreCache[kind] = index

	baseURI := "content://media/external/" + kind + "/media"
	thumbURI := "content://media/external/" + kind + "/thumbnails"
	idColumn := "image_id"
	if kind == "video" {
		idColumn = "video_id"
	}

	media, mediaOK := queryMediaStoreMap(baseURI, "_id,_data", "_id", "_data")
	if !mediaOK {
		return index
	}
	thumbs, _ := queryMediaStoreMap(thumbURI, idColumn+",_data", idColumn, "_data")
	for id, thumbPath := range thumbs {
		if mediaPath, ok := media[id]; ok {
			index.thumbByPath[normalizeMediaPath(mediaPath)] = thumbPath
		}
	}
	return index
}

// mediaStoreThumbnailPath returns the on-device thumbnail file for a media path,
// or "" when MediaStore has none for it.
func mediaStoreThumbnailPath(remotePath string, video bool) string {
	kind := "images"
	if video {
		kind = "videos"
	}
	index := loadMediaStoreIndex(kind)
	if len(index.thumbByPath) == 0 {
		return ""
	}
	thumb := index.thumbByPath[normalizeMediaPath(remotePath)]
	if thumb == "" {
		return ""
	}
	// Only trust thumbnails that still exist on the device.
	if _, err := executeADB("shell", "test", "-e", deviceQuote(thumb)); err != nil {
		return ""
	}
	return thumb
}

// fetchMediaStoreThumbnail pulls a thumbnail into the local cache and returns
// its bytes, or nil when it cannot be produced.
func fetchMediaStoreThumbnail(remotePath string, video bool) []byte {
	thumbPath := mediaStoreThumbnailPath(remotePath, video)
	if thumbPath == "" {
		return nil
	}
	data, err := readRemoteBytes(thumbPath, maxGenericFile)
	if err != nil || len(data) == 0 {
		return nil
	}
	if detectImageMime(data) == "" {
		return nil
	}
	// Keep a copy next to the other thumbnails for instant repeat launches.
	key := sanitizeFileComponent(strings.ReplaceAll(strings.Trim(remotePath, "/"), "/", "_"))
	key = fmt.Sprintf("ms_%s", key)
	if len(key) > 180 {
		key = key[len(key)-180:]
	}
	_ = os.WriteFile(filepath.Join(appCacheDir("thumbs"), key+".jpg"), data, 0o644)
	return data
}
