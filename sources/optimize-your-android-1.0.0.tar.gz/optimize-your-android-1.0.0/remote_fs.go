package main

import (
	"fmt"
	"path"
	"strconv"
	"strings"
	"sync"
)

// AndroidFileEntry is one entry in the device file browser.
type AndroidFileEntry struct {
	Name      string `json:"name"`
	Path      string `json:"path"`
	IsDir     bool   `json:"isDir"`
	Size      int64  `json:"size"`
	Modified  string `json:"modified"`
	Kind      string `json:"kind"`
	MimeType  string `json:"mimeType"`
	IsSymlink bool   `json:"isSymlink"`
}

type remoteEntry struct {
	Name      string
	Path      string
	IsDir     bool
	Size      int64
	Modified  string
	IsSymlink bool
}

func normalizeAndroidPath(p string) string {
	trimmed := strings.TrimSpace(p)
	if trimmed == "" {
		return "/sdcard"
	}
	if trimmed == "/" {
		return "/"
	}
	trimmed = strings.TrimRight(trimmed, "/")
	if trimmed == "" {
		return "/"
	}
	return trimmed
}

func joinRemotePath(dir, name string) string {
	if dir == "/" {
		return "/" + name
	}
	return dir + "/" + name
}

// parseLsLine parses one `ls -la` row. Android prints:
//
//	drwxrwx---  2 root everybody  3488 2026-07-31 13:26 DCIM
//	lrwxrwxrwx  1 root root         21 2009-01-01 00:00 sdcard -> /storage/self/primary
func parseLsLine(line, dir string) (remoteEntry, bool) {
	trimmed := strings.TrimSpace(line)
	if trimmed == "" || strings.HasPrefix(trimmed, "total ") {
		return remoteEntry{}, false
	}
	fields := strings.Fields(trimmed)
	if len(fields) < 8 {
		return remoteEntry{}, false
	}

	perms := fields[0]
	if len(perms) < 10 {
		return remoteEntry{}, false
	}
	size, err := strconv.ParseInt(fields[4], 10, 64)
	if err != nil {
		return remoteEntry{}, false
	}

	name := strings.Join(fields[7:], " ")
	if idx := strings.Index(name, " -> "); idx >= 0 {
		name = name[:idx]
	}
	name = strings.TrimSpace(name)
	if name == "" || name == "." || name == ".." {
		return remoteEntry{}, false
	}

	entry := remoteEntry{
		Name:      name,
		Path:      joinRemotePath(dir, name),
		IsDir:     perms[0] == 'd',
		IsSymlink: perms[0] == 'l',
		Size:      size,
		Modified:  fields[5] + " " + fields[6],
	}
	return entry, true
}

// parseLsLineAbsolute parses a `ls -l /absolute/path` row as produced by
// `find ... -exec ls -l {} +`, where the name column is the full path.
func parseLsLineAbsolute(line string) (remoteEntry, bool) {
	trimmed := strings.TrimSpace(line)
	if trimmed == "" {
		return remoteEntry{}, false
	}
	fields := strings.Fields(trimmed)
	if len(fields) < 8 || len(fields[0]) < 10 || fields[0][0] == 'd' {
		return remoteEntry{}, false
	}
	size, err := strconv.ParseInt(fields[4], 10, 64)
	if err != nil {
		return remoteEntry{}, false
	}
	full := strings.Join(fields[7:], " ")
	if idx := strings.Index(full, " -> "); idx >= 0 {
		full = full[:idx]
	}
	full = strings.TrimSpace(full)
	if !strings.HasPrefix(full, "/") {
		return remoteEntry{}, false
	}
	return remoteEntry{
		Name:     path.Base(full),
		Path:     full,
		Size:     size,
		Modified: fields[5] + " " + fields[6],
	}, true
}

// remoteListDir lists a single directory (one adb round trip, no per-entry stat).
func remoteListDir(dir string) ([]remoteEntry, error) {
	dir = normalizeAndroidPath(dir)
	lsPath := dir
	if dir != "/" {
		lsPath += "/"
	}
	out, err := executeADB("shell", "ls", "-la", deviceQuote(lsPath))
	if err != nil {
		return nil, fmt.Errorf("failed to list %s: %w", dir, err)
	}

	entries := make([]remoteEntry, 0, 32)
	for _, line := range strings.Split(out, "\n") {
		entry, ok := parseLsLine(line, dir)
		if !ok {
			continue
		}
		entries = append(entries, entry)
	}

	resolveSymlinkDirs(entries)
	return entries, nil
}

// resolveSymlinkDirs marks symlinked entries that point at directories so the
// browser navigates into them (e.g. /sdcard -> /storage/self/primary) instead
// of trying to preview them as files. Symlinks are rare, so the extra adb calls
// are cheap and run in parallel.
func resolveSymlinkDirs(entries []remoteEntry) {
	var wg sync.WaitGroup
	sem := make(chan struct{}, 6)
	for i := range entries {
		if !entries[i].IsSymlink {
			continue
		}
		wg.Add(1)
		sem <- struct{}{}
		go func(idx int) {
			defer wg.Done()
			defer func() { <-sem }()
			if _, err := executeADB("shell", "test", "-d", deviceQuote(entries[idx].Path)); err == nil {
				entries[idx].IsDir = true
			}
		}(i)
	}
	wg.Wait()
}

func entryToAndroidFile(entry remoteEntry) AndroidFileEntry {
	kind := KindOther
	mime := ""
	if entry.IsDir {
		kind = KindDir
	} else {
		kind = fileKind(entry.Name)
		mime = fileMime(entry.Name)
	}
	return AndroidFileEntry{
		Name:      entry.Name,
		Path:      entry.Path,
		IsDir:     entry.IsDir,
		Size:      entry.Size,
		Modified:  entry.Modified,
		Kind:      kind,
		MimeType:  mime,
		IsSymlink: entry.IsSymlink,
	}
}

// parseLsLineAbsoluteAny parses a `ls -ld /absolute/path` row for any entry
// type (file, directory or symlink). Used by the fallback listing where the
// device's `ls` output cannot be trusted to contain files.
func parseLsLineAbsoluteAny(line string) (remoteEntry, bool) {
	trimmed := strings.TrimSpace(line)
	if trimmed == "" {
		return remoteEntry{}, false
	}
	fields := strings.Fields(trimmed)
	if len(fields) < 8 || len(fields[0]) < 10 {
		return remoteEntry{}, false
	}
	switch fields[0][0] {
	case 'd', '-', 'l':
	default:
		return remoteEntry{}, false
	}
	size, err := strconv.ParseInt(fields[4], 10, 64)
	if err != nil {
		return remoteEntry{}, false
	}
	full := strings.Join(fields[7:], " ")
	if idx := strings.Index(full, " -> "); idx >= 0 {
		full = full[:idx]
	}
	full = strings.TrimSpace(full)
	if !strings.HasPrefix(full, "/") {
		return remoteEntry{}, false
	}
	return remoteEntry{
		Name:     path.Base(full),
		Path:     full,
		IsDir:    fields[0][0] == 'd',
		Size:     size,
		Modified: fields[5] + " " + fields[6],
	}, true
}

// findDirEntriesOnce lists the direct children of a directory (files AND folders)
// in a single adb call via `find -maxdepth 1 -exec ls -ld`. This is the fallback
// that guarantees files appear even when the device's `ls` output only yields
// folders (unusual date formats, locale columns, busybox builds).
func findDirEntriesOnce(dir string) ([]remoteEntry, error) {
	dir = normalizeAndroidPath(dir)
	out, err := executeADB("shell", "find", deviceQuote(dir), "-maxdepth", "1", "!", "-path", deviceQuote(dir), "-exec", "ls", "-ld", "{}", "+", "2>/dev/null")
	if err != nil {
		return nil, err
	}
	entries := make([]remoteEntry, 0, 32)
	for _, line := range strings.Split(out, "\n") {
		entry, ok := parseLsLineAbsoluteAny(line)
		if !ok {
			continue
		}
		entries = append(entries, entry)
	}
	return entries, nil
}

// ListAndroidFiles returns a directory listing for the file browser. When the
// device's `ls` output yields folders but no files (or fails outright), a
// find-based pass is merged in so files always show up next to their folders.
func (a *App) ListAndroidFiles(remotePath string) ([]AndroidFileEntry, error) {
	if err := a.requireAnyDevice(); err != nil {
		return nil, err
	}
	dir := normalizeAndroidPath(remotePath)
	entries, err := remoteListDir(dir)
	if err != nil {
		if fallback, ferr := findDirEntriesOnce(dir); ferr == nil && len(fallback) > 0 {
			entries = fallback
		} else {
			return nil, err
		}
	}

	dirs, files := 0, 0
	for _, entry := range entries {
		if entry.IsDir {
			dirs++
		} else {
			files++
		}
	}
	if dirs > 0 && files == 0 {
		if extra, ferr := findDirEntriesOnce(dir); ferr == nil && len(extra) > 0 {
			seen := make(map[string]bool, len(entries))
			for _, entry := range entries {
				seen[entry.Path] = true
			}
			for _, entry := range extra {
				if !seen[entry.Path] {
					entries = append(entries, entry)
					seen[entry.Path] = true
				}
			}
		}
	}

	result := make([]AndroidFileEntry, 0, len(entries))
	for _, entry := range entries {
		result = append(result, entryToAndroidFile(entry))
	}
	return result, nil
}

// PrefetchAndroidFiles lists several directories concurrently so navigation feels
// instant. Keys are the requested (normalized) paths.
func (a *App) PrefetchAndroidFiles(paths []string) (map[string][]AndroidFileEntry, error) {
	if err := a.requireAnyDevice(); err != nil {
		return nil, err
	}

	result := make(map[string][]AndroidFileEntry, len(paths))
	var mu sync.Mutex
	sem := make(chan struct{}, 4)
	var wg sync.WaitGroup

	for _, raw := range paths {
		dir := normalizeAndroidPath(raw)
		if dir == "" {
			continue
		}
		mu.Lock()
		_, exists := result[dir]
		mu.Unlock()
		if exists {
			continue
		}

		wg.Add(1)
		sem <- struct{}{}
		go func(target string) {
			defer wg.Done()
			defer func() { <-sem }()
			entries, err := remoteListDir(target)
			if err != nil {
				return
			}
			list := make([]AndroidFileEntry, 0, len(entries))
			for _, entry := range entries {
				list = append(list, entryToAndroidFile(entry))
			}
			mu.Lock()
			result[target] = list
			mu.Unlock()
		}(dir)
	}
	wg.Wait()
	return result, nil
}

// maxWalkDirs bounds the number of directories a recursive walk visits, so
// reviewing a backup of a huge tree (or /sdcard itself) can't run for minutes.
const maxWalkDirs = 600

// walkRemoteTree recursively collects files under root (bounded by both the
// number of directories visited and the number of files collected).
func walkRemoteTree(root string, recursive bool, maxEntries int) ([]remoteEntry, error) {
	root = normalizeAndroidPath(root)
	queue := []string{root}
	collected := make([]remoteEntry, 0, 128)
	visitedDirs := 0

	for len(queue) > 0 {
		if visitedDirs >= maxWalkDirs {
			break
		}
		visitedDirs++

		dir := queue[0]
		queue = queue[1:]

		entries, err := remoteListDir(dir)
		if err != nil {
			if dir == root {
				return nil, err
			}
			continue
		}
		for _, entry := range entries {
			if entry.IsDir {
				if recursive {
					queue = append(queue, entry.Path)
				}
				continue
			}
			collected = append(collected, entry)
			if len(collected) >= maxEntries {
				return collected, nil
			}
		}
	}
	return collected, nil
}

// findFilesOnce lists every file under root with sizes in a SINGLE adb round
// trip. Walking directory-by-directory costs one `ls` per folder, which made
// reviewing a backup of a large tree take tens of seconds.
func findFilesOnce(root string, maxEntries int) ([]remoteEntry, error) {
	out, err := executeADB("shell", "find", deviceQuote(root), "-type", "f", "-exec", "ls", "-l", "{}", "+", "2>/dev/null")
	if err != nil {
		return nil, err
	}
	entries := make([]remoteEntry, 0, 128)
	for _, line := range strings.Split(out, "\n") {
		entry, ok := parseLsLineAbsolute(line)
		if !ok {
			continue
		}
		entries = append(entries, entry)
		if len(entries) >= maxEntries {
			break
		}
	}
	return entries, nil
}

// walkRemoteTreeFast tries the single-call tree listing and falls back to the
// directory-by-directory walk on devices whose find lacks `-exec ... +`.
func walkRemoteTreeFast(root string, recursive bool, maxEntries int) ([]remoteEntry, error) {
	if recursive {
		if entries, err := findFilesOnce(root, maxEntries); err == nil && len(entries) > 0 {
			return entries, nil
		}
	}
	return walkRemoteTree(root, recursive, maxEntries)
}

// relativeRemotePath returns the path of a file relative to a root directory.
func relativeRemotePath(root, full string) string {
	root = strings.TrimRight(normalizeAndroidPath(root), "/")
	relative := strings.TrimPrefix(full, root)
	relative = strings.TrimPrefix(relative, "/")
	if relative == "" {
		return path.Base(full)
	}
	return relative
}
