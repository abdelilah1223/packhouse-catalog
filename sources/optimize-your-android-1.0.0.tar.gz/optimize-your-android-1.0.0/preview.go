package main

import (
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"strings"
	"sync"
)

// humanBytes renders a byte count for user-facing messages.
func humanBytes(size int64) string {
	const unit = 1024
	if size < unit {
		return fmt.Sprintf("%d B", size)
	}
	units := []string{"KB", "MB", "GB", "TB"}
	value := float64(size)
	for _, suffix := range units {
		value /= unit
		if value < unit {
			return fmt.Sprintf("%.1f %s", value, suffix)
		}
	}
	return fmt.Sprintf("%.1f PB", value/unit)
}

// Preview and thumbnail limits. Video/PDF payloads are base64-encoded when they
// cross the Wails bridge, so the caps keep the UI responsive while still covering
// ordinary phone media.
const (
	maxInlineImage = 24 * 1024 * 1024
	maxInlineVideo = 48 * 1024 * 1024
	maxInlineAudio = 24 * 1024 * 1024
	maxInlinePDF   = 32 * 1024 * 1024
	maxInlineText  = 2 * 1024 * 1024
	maxGenericFile = 4 * 1024 * 1024

	thumbnailEdge      = 360
	maxThumbnailSource = 80 * 1024 * 1024
)

// FilePreview is everything the frontend needs to render a file inline.
type FilePreview struct {
	Path          string `json:"path"`
	Name          string `json:"name"`
	Kind          string `json:"kind"`
	MimeType      string `json:"mimeType"`
	DataURL       string `json:"dataUrl"`
	Text          string `json:"text"`
	Size          int64  `json:"size"`
	TooLarge      bool   `json:"tooLarge"`
	DownloadLimit int64  `json:"downloadLimit"`
	Message       string `json:"message"`
}

func remoteBaseName(path string) string {
	return filepath.Base(strings.TrimRight(path, "/"))
}

func looksLikeTextData(data []byte) bool {
	if len(data) == 0 {
		return true
	}
	sample := data
	if len(sample) > 4096 {
		sample = sample[:4096]
	}
	for _, b := range sample {
		if b == 0 {
			return false
		}
	}
	return true
}

// GetFilePreview pulls a file's bytes (or text body) for inline rendering.
func (a *App) GetFilePreview(path string) (*FilePreview, error) {
	path = strings.TrimSpace(path)
	if path == "" {
		return nil, fmt.Errorf("missing file path")
	}
	if err := a.requireAnyDevice(); err != nil {
		return nil, err
	}

	name := remoteBaseName(path)
	kind := fileKind(name)
	mime := fileMime(name)
	result := &FilePreview{Path: path, Name: name, Kind: kind, MimeType: mime}

	size, sizeErr := remoteFileSize(path)
	if sizeErr == nil {
		result.Size = size
	}

	limitFor := func() int64 {
		switch kind {
		case KindImage:
			return maxInlineImage
		case KindVideo:
			return maxInlineVideo
		case KindAudio:
			return maxInlineAudio
		case KindPDF:
			return maxInlinePDF
		case KindText:
			return maxInlineText
		}
		return maxGenericFile
	}
	result.DownloadLimit = limitFor()

	if sizeErr == nil && size > result.DownloadLimit {
		result.TooLarge = true
		result.Message = fmt.Sprintf("File is %s — too large to preview inline. Use \"Save to PC\" or \"Open externally\".", humanBytes(size))
		return result, nil
	}

	data, err := readRemoteBytes(path, result.DownloadLimit)
	if err != nil {
		result.Message = err.Error()
		return result, nil
	}
	if sizeErr == nil && int64(len(data)) < size {
		result.TooLarge = true
		result.Message = "Only part of the file could be read from the device."
	}

	switch kind {
	case KindImage:
		if detected := detectImageMime(data); detected != "" {
			result.MimeType = detected
		}
		result.DataURL = dataURL(result.MimeType, data)
	case KindVideo, KindAudio, KindPDF:
		result.DataURL = dataURL(result.MimeType, data)
	case KindText:
		if looksLikeTextData(data) {
			result.Text = string(data)
		} else {
			result.Message = "This file looks binary and cannot be shown as text."
		}
	default:
		if strings.HasPrefix(mime, "text/") && looksLikeTextData(data) {
			result.Text = string(data)
		} else {
			result.Message = "No inline preview available for this file type."
		}
	}
	return result, nil
}

// GetFileThumbnail returns a small data URL for an image or video, or "" when no
// thumbnail can be produced (missing ffmpeg, file too large, unsupported format).
func (a *App) GetFileThumbnail(path string) (string, error) {
	path = strings.TrimSpace(path)
	if path == "" {
		return "", fmt.Errorf("missing file path")
	}

	name := remoteBaseName(path)
	kind := fileKind(name)
	if kind != KindImage && kind != KindVideo {
		return "", nil
	}
	if err := a.requireAnyDevice(); err != nil {
		return "", err
	}

	size, err := remoteFileSize(path)
	if err != nil {
		return "", nil
	}
	if kind == KindVideo && size > maxThumbnailSource {
		return "", nil
	}

	cachePath := thumbnailCachePath(path, size)
	if data, err := os.ReadFile(cachePath); err == nil && len(data) > 0 {
		return dataURL("image/jpeg", data), nil
	}

	// Android's MediaStore keeps ready-made thumbnails for indexed media. Using
	// them costs one tiny pull and works even when ffmpeg is not installed on
	// the PC, so it is tried before anything heavier.
	if data := fetchMediaStoreThumbnail(path, kind == KindVideo); len(data) > 0 {
		_ = os.WriteFile(cachePath, data, 0o644)
		return dataURL("image/jpeg", data), nil
	}

	ffmpeg := ffmpegPath()
	if ffmpeg == "" {
		// Without ffmpeg we can still show small images by shipping them directly.
		if kind == KindImage && size <= maxGenericFile {
			if data, err := readRemoteBytes(path, maxGenericFile); err == nil && len(data) > 0 {
				mime := detectImageMime(data)
				if mime == "" {
					mime = "image/png"
				}
				return dataURL(mime, data), nil
			}
		}
		return "", nil
	}

	tmpDir, err := os.MkdirTemp("", "thumb-*")
	if err != nil {
		return "", err
	}
	defer os.RemoveAll(tmpDir)

	localFile := filepath.Join(tmpDir, "source"+fileExtension(name))
	if _, err := executeADB("pull", path, localFile); err != nil {
		return "", nil
	}

	outFile := filepath.Join(tmpDir, "thumb.jpg")
	args := []string{"-y", "-hide_banner", "-loglevel", "error"}
	if kind == KindVideo {
		args = append(args, "-ss", "0.5")
	}
	args = append(args,
		"-i", localFile,
		"-frames:v", "1",
		"-vf", fmt.Sprintf("scale=%d:-1:force_original_aspect_ratio=decrease", thumbnailEdge),
		outFile,
	)
	if err := exec.Command(ffmpeg, args...).Run(); err != nil {
		return "", nil
	}

	data, err := os.ReadFile(outFile)
	if err != nil || len(data) == 0 {
		return "", nil
	}
	_ = os.WriteFile(cachePath, data, 0o644)
	return dataURL("image/jpeg", data), nil
}

func thumbnailCachePath(remotePath string, size int64) string {
	key := sanitizeFileComponent(strings.ReplaceAll(strings.Trim(remotePath, "/"), "/", "_"))
	key = fmt.Sprintf("%s_%d", key, size)
	if len(key) > 180 {
		key = key[len(key)-180:]
	}
	return filepath.Join(appCacheDir("thumbs"), key+".jpg")
}

func ffmpegPath() string {
	if path, err := exec.LookPath("ffmpeg"); err == nil {
		return path
	}
	return ""
}

// SaveFileToPC pulls a remote file into a local directory and returns its path.
func (a *App) SaveFileToPC(remotePath, localDir string) (string, error) {
	remotePath = strings.TrimSpace(remotePath)
	if remotePath == "" {
		return "", fmt.Errorf("missing file path")
	}
	if strings.TrimSpace(localDir) == "" {
		localDir = filepath.Join(".", "device-files")
	}
	if err := os.MkdirAll(localDir, 0o755); err != nil {
		return "", err
	}
	dest := filepath.Join(localDir, remoteBaseName(remotePath))
	if _, err := executeADB("pull", remotePath, dest); err != nil {
		return "", err
	}
	abs, err := filepath.Abs(dest)
	if err != nil {
		return dest, nil
	}
	return abs, nil
}

// OpenFileExternally pulls the file to a temp location and hands it to the OS.
func (a *App) OpenFileExternally(remotePath string) error {
	remotePath = strings.TrimSpace(remotePath)
	if remotePath == "" {
		return fmt.Errorf("missing file path")
	}
	dir := appCacheDir("open")
	dest := filepath.Join(dir, sanitizeFileComponent(remoteBaseName(remotePath)))
	if _, err := executeADB("pull", remotePath, dest); err != nil {
		return err
	}

	switch runtime.GOOS {
	case "darwin":
		return exec.Command("open", dest).Start()
	case "windows":
		return exec.Command("cmd", "/c", "start", "", dest).Start()
	default:
		return exec.Command("xdg-open", dest).Start()
	}
}

// GetFileSizes resolves remote file sizes in parallel (bounded concurrency).
func (a *App) GetFileSizes(paths []string) (map[string]int64, error) {
	result := make(map[string]int64, len(paths))
	if len(paths) == 0 {
		return result, nil
	}

	sem := make(chan struct{}, 6)
	var wg sync.WaitGroup
	var mu sync.Mutex

	for _, path := range paths {
		path = strings.TrimSpace(path)
		if path == "" {
			continue
		}
		wg.Add(1)
		sem <- struct{}{}
		go func(p string) {
			defer wg.Done()
			defer func() { <-sem }()
			size, err := remoteFileSize(p)
			if err != nil {
				return
			}
			mu.Lock()
			result[p] = size
			mu.Unlock()
		}(path)
	}
	wg.Wait()
	return result, nil
}
