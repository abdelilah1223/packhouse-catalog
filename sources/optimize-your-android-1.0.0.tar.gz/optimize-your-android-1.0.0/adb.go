package main

import (
	"bytes"
	"context"
	"fmt"
	"io"
	"os/exec"
	"path/filepath"
	"sort"
	"strings"
	"sync"
	"time"
)

// Every adb call is bounded in time. A dropped cable, a wedged adbd or a device
// that never answers a shell command used to block the calling goroutine
// forever, which left the UI stuck on whatever stage it was showing ("Reading
// installed apps 5%", "Extracting icons…"). Timeouts turn those hangs into
// error messages the frontend can show with a Retry button.
const (
	// adbQuickTimeout bounds ordinary queries (pm, ls, unzip, getprop …).
	adbQuickTimeout = 30 * time.Second
	// adbDeviceTimeout bounds device enumeration so onboarding polls stay snappy.
	adbDeviceTimeout = 10 * time.Second
	// adbTransferTimeout bounds pull/push/install, which are legitimately slow.
	adbTransferTimeout = 15 * time.Minute
	// adbWalkTimeout bounds recursive `find` walks (backup plans, deep scans).
	adbWalkTimeout = 5 * time.Minute
	// adbRemoteReadTimeout bounds streamed reads (previews, thumbnails).
	adbRemoteReadTimeout = 60 * time.Second
)

// adbTimeoutFor picks the deadline that fits the command being run.
func adbTimeoutFor(args []string) time.Duration {
	if len(args) == 0 {
		return adbQuickTimeout
	}
	switch args[0] {
	case "devices", "version", "kill-server", "start-server":
		return adbDeviceTimeout
	case "pull", "push", "sync", "install", "install-multiple":
		return adbTransferTimeout
	}
	if args[0] == "shell" {
		for _, arg := range args[1:] {
			if arg == "find" {
				return adbWalkTimeout
			}
		}
	}
	return adbQuickTimeout
}

func timeoutErr(args []string, timeout time.Duration) error {
	cmdLine := "adb"
	for _, arg := range args {
		cmdLine += " " + arg
	}
	return fmt.Errorf("%s did not respond within %s — the device looks stuck (unplug/replug the cable, then retry)", cmdLine, timeout.Round(time.Second))
}

type Device struct {
	ID     string `json:"id"`
	Status string `json:"status"`
	Model  string `json:"model"`
}

type ProcessStat struct {
	PID     string `json:"pid"`
	Name    string `json:"name"`
	CPU     string `json:"cpu"`
	Memory  string `json:"memory"`
	Status  string `json:"status"`
	Package string `json:"package"`
}

type AppInfo struct {
	PackageName   string `json:"packageName"`
	Name          string `json:"name"`
	Icon          string `json:"icon"`
	Path          string `json:"path"`
	IsSystem      bool   `json:"isSystem"`
	IsThirdParty  bool   `json:"isThirdParty"`
	IsLaunchable  bool   `json:"isLaunchable"`
	IsServiceLike bool   `json:"isServiceLike"`
	IsDisabled    bool   `json:"isDisabled"`
	Recommended   string `json:"recommended"`
	IsSafe        bool   `json:"isSafe"`
}

type MessageItem struct {
	Address string `json:"address"`
	Body    string `json:"body"`
	Date    string `json:"date"`
	Type    string `json:"type"`
}

type CallLogItem struct {
	Name   string `json:"name"`
	Number string `json:"number"`
	Type   string `json:"type"`
	Date   string `json:"date"`
}

type RecoveryItem struct {
	Path       string `json:"path"`
	Name       string `json:"name"`
	Type       string `json:"type"`
	Kind       string `json:"kind"`
	Size       string `json:"size"`
	SizeBytes  int64  `json:"sizeBytes"`
	Hidden     bool   `json:"hidden"`
	Notes      string `json:"notes"`
	SourcePath string `json:"sourcePath"`
}

// RecoveryRequest describes an interactive recovery scan.
type RecoveryRequest struct {
	Mode  string `json:"mode"`
	Query string `json:"query"`
	Deep  bool   `json:"deep"`
}

// executeADB runs an adb command and returns the trimmed stdout as a string.
// The deadline is derived from the command (see adbTimeoutFor).
func executeADB(args ...string) (string, error) {
	return executeADBWithin(adbTimeoutFor(args), args...)
}

// executeADBWithin runs an adb command with an explicit deadline.
func executeADBWithin(timeout time.Duration, args ...string) (string, error) {
	if timeout <= 0 {
		timeout = adbQuickTimeout
	}
	ctx, cancel := context.WithTimeout(context.Background(), timeout)
	defer cancel()
	cmd := exec.CommandContext(ctx, "adb", args...)
	var out bytes.Buffer
	var stderr bytes.Buffer
	cmd.Stdout = &out
	cmd.Stderr = &stderr
	if err := cmd.Run(); err != nil {
		if ctx.Err() == context.DeadlineExceeded {
			return "", timeoutErr(args, timeout)
		}
		return "", fmt.Errorf("adb error: %v (stderr: %s)", err, strings.TrimSpace(stderr.String()))
	}
	return out.String(), nil
}

// executeADBRaw is like executeADB but returns untrimmed binary stdout.
func executeADBRaw(args ...string) ([]byte, error) {
	timeout := adbTimeoutFor(args)
	ctx, cancel := context.WithTimeout(context.Background(), timeout)
	defer cancel()
	cmd := exec.CommandContext(ctx, "adb", args...)
	var out bytes.Buffer
	var stderr bytes.Buffer
	cmd.Stdout = &out
	cmd.Stderr = &stderr
	if err := cmd.Run(); err != nil {
		if ctx.Err() == context.DeadlineExceeded {
			return nil, timeoutErr(args, timeout)
		}
		return nil, fmt.Errorf("adb error: %v (stderr: %s)", err, strings.TrimSpace(stderr.String()))
	}
	return out.Bytes(), nil
}

// deviceQuote single-quotes a path so the device shell treats it literally.
func deviceQuote(value string) string {
	return "'" + strings.ReplaceAll(value, "'", `'\''`) + "'"
}

// remoteFileSize returns a remote file's size in bytes.
func remoteFileSize(path string) (int64, error) {
	out, err := executeADB("shell", "stat", "-c", "%s", deviceQuote(path))
	if err != nil {
		return 0, err
	}
	fields := strings.Fields(out)
	if len(fields) == 0 {
		return 0, fmt.Errorf("empty stat output for %s", path)
	}
	var size int64
	for _, field := range fields {
		if _, err := fmt.Sscanf(field, "%d", &size); err == nil {
			return size, nil
		}
	}
	return 0, fmt.Errorf("unparsable stat output for %s", path)
}

// readRemoteBytes streams up to limit+1 bytes from a remote file.
func readRemoteBytes(path string, limit int64) ([]byte, error) {
	ctx, cancel := context.WithTimeout(context.Background(), adbRemoteReadTimeout)
	defer cancel()
	cmd := exec.CommandContext(ctx, "adb", "exec-out", "cat", path)
	stdout, err := cmd.StdoutPipe()
	if err != nil {
		return nil, err
	}
	if err := cmd.Start(); err != nil {
		return nil, err
	}
	data, readErr := io.ReadAll(io.LimitReader(stdout, limit+1))
	_ = cmd.Wait()
	if ctx.Err() == context.DeadlineExceeded && len(data) == 0 {
		return nil, timeoutErr([]string{"exec-out", "cat", path}, adbRemoteReadTimeout)
	}
	if readErr != nil && len(data) == 0 {
		return nil, readErr
	}
	if int64(len(data)) > limit {
		data = data[:limit]
	}
	return data, nil
}

// requireAnyDevice fails with a human-readable message when no phone is attached.
// `adb devices` exits 0 with an empty list when nothing is connected, so a nil
// error alone is not enough to know the device is usable.
func (a *App) requireAnyDevice() error {
	devices, err := a.GetConnectedDevices()
	if err != nil {
		return err
	}
	for _, device := range devices {
		if device.Status == "device" {
			return nil
		}
	}
	if len(devices) > 0 {
		return fmt.Errorf("device is %s — approve the USB debugging prompt on the phone", devices[0].Status)
	}
	return fmt.Errorf("no Android device connected — enable USB debugging and accept the ADB prompt")
}

// GetConnectedDevices returns a list of connected ADB devices.
func (a *App) GetConnectedDevices() ([]Device, error) {
	out, err := executeADB("devices", "-l")
	if err != nil {
		return nil, err
	}

	devices := make([]Device, 0)
	for i, line := range strings.Split(strings.TrimSpace(out), "\n") {
		if i == 0 {
			continue
		}
		fields := strings.Fields(line)
		if len(fields) >= 2 {
			device := Device{ID: fields[0], Status: fields[1]}
			for _, field := range fields[2:] {
				if strings.HasPrefix(field, "model:") {
					device.Model = strings.TrimPrefix(field, "model:")
				}
			}
			devices = append(devices, device)
		}
	}
	return devices, nil
}

func (a *App) GetProcessStats() ([]ProcessStat, error) {
	out, err := executeADB("shell", "ps", "-A", "-o", "PID,NAME,%CPU,%MEM")
	if err != nil {
		return nil, err
	}

	stats := make([]ProcessStat, 0)
	for i, line := range strings.Split(strings.TrimSpace(out), "\n") {
		if i == 0 || strings.TrimSpace(line) == "" {
			continue
		}
		fields := strings.Fields(line)
		if len(fields) < 4 {
			continue
		}
		stats = append(stats, ProcessStat{
			PID:     fields[0],
			Name:    fields[1],
			CPU:     fields[2],
			Memory:  fields[3],
			Package: fields[1],
		})
	}
	return stats, nil
}

func (a *App) StopProcess(pid string) error {
	_, err := executeADB("shell", "kill", "-STOP", pid)
	return err
}

func (a *App) ResumeProcess(pid string) error {
	_, err := executeADB("shell", "kill", "-CONT", pid)
	return err
}

// ignoredPackageParts are TLDs and vendor boilerplate that never identify an app.
var ignoredPackageParts = map[string]bool{
	"com": true, "org": true, "net": true, "io": true, "gov": true, "edu": true,
	"co": true, "me": true, "app": true, "xyz": true, "info": true, "dev": true,
	"android": true, "application": true, "applications": true, "client": true,
	"mobile": true, "release": true, "enc": true, "free": true, "pro": true,
	"oss": true, "main": true, "base": true, "core": true, "lite": true,
	"beta": true, "debug": true, "internal": true, "apk": true,
}

// formatAppLabel derives a readable label from a package name by skipping the
// TLD and boilerplate segments (com.busuu.android.enc -> "Busuu").
func formatAppLabel(pkg string) string {
	parts := strings.Split(pkg, ".")
	label := ""
	for i := len(parts) - 1; i >= 0; i-- {
		part := strings.TrimSpace(parts[i])
		if part == "" {
			continue
		}
		if !ignoredPackageParts[strings.ToLower(part)] {
			label = part
			break
		}
	}
	if label == "" {
		for i := len(parts) - 1; i >= 0; i-- {
			if part := strings.TrimSpace(parts[i]); part != "" {
				label = part
				break
			}
		}
	}
	if label == "" {
		label = pkg
	}
	label = strings.NewReplacer("_", " ", "-", " ", ".", " ").Replace(label)
	return titleCaseWords(label)
}

func titleCaseWords(value string) string {
	words := strings.Fields(value)
	for i, word := range words {
		runes := []rune(word)
		if len(runes) == 0 {
			continue
		}
		words[i] = strings.ToUpper(string(runes[0])) + string(runes[1:])
	}
	return strings.Join(words, " ")
}

func isSystemPackagePath(path string) bool {
	prefixes := []string{"/system", "/system_ext", "/product", "/vendor", "/apex", "/data/apex", "/vendor_dlkm", "/odm"}
	for _, prefix := range prefixes {
		if strings.HasPrefix(path, prefix) {
			return true
		}
	}
	return false
}

// listPackagesFlag asks the device for package names matching a pm filter flag
// (-3: user-installed, -s: preinstalled/system). Returns nil when the call
// itself failed, so callers can tell "the device says none" apart from "the
// device did not answer".
func listPackagesFlag(flag string) map[string]bool {
	out, err := executeADB("shell", "pm", "list", "packages", flag)
	if err != nil {
		return nil
	}
	result := map[string]bool{}
	for _, line := range strings.Split(out, "\n") {
		line = strings.TrimSpace(line)
		if strings.HasPrefix(line, "package:") {
			result[strings.TrimPrefix(line, "package:")] = true
		}
	}
	return result
}

// thirdPartyPackages asks the device which packages are user-installed. This is
// the only reliable signal: preinstalled apps that received an update also live
// under /data/app, so a path check alone misclassifies them as user apps.
func thirdPartyPackages() map[string]bool {
	return listPackagesFlag("-3")
}

// systemPackages asks the device which packages carry the system flag.
func systemPackages() map[string]bool {
	return listPackagesFlag("-s")
}

func isPackageName(value string) bool {
	value = strings.TrimSpace(value)
	if value == "" || !strings.Contains(value, ".") {
		return false
	}
	for _, r := range value {
		if (r >= 'a' && r <= 'z') || (r >= 'A' && r <= 'Z') || (r >= '0' && r <= '9') || r == '_' || r == '.' {
			continue
		}
		return false
	}
	return true
}

// classifyIsThirdParty decides whether a package is user-installed.
//
// Priority: the device's own user-app list (-3), then its system-app list (-s)
// when -3 could not be read, and only then the APK-path heuristic. The path
// check is the weakest signal — a preinstalled app that received an update keeps
// the system flag but lives under /data/app, so a bare path check would show it
// as a user-installed app.
func classifyIsThirdParty(pkg, apkPath string, thirdParty, systemPkgs map[string]bool) bool {
	inThird := thirdParty != nil && thirdParty[pkg]
	inSystem := systemPkgs != nil && systemPkgs[pkg]
	switch {
	case inThird:
		return true
	case inSystem:
		return false
	case thirdParty != nil && systemPkgs != nil:
		// Both lists answered but the package is in neither (possible only for a
		// package belonging to another user): fall back to the path check.
		return apkPath != "" && !isSystemPackagePath(apkPath)
	case thirdParty != nil:
		// -3 answered and does not list it → the device does not consider it user-installed.
		return false
	case systemPkgs != nil:
		// -s answered and does not list it → not a system app.
		return true
	default:
		return apkPath != "" && !isSystemPackagePath(apkPath)
	}
}

func parsePackagePathLine(line string) (string, string, bool) {
	line = strings.TrimSpace(line)
	if line == "" || !strings.HasPrefix(line, "package:") {
		return "", "", false
	}
	line = strings.TrimPrefix(line, "package:")
	// Android package directories can contain base64-ish suffixes ending in "==".
	// The package name is after the final '=', not the first one.
	idx := strings.LastIndex(line, "=")
	if idx < 0 {
		return "", "", false
	}
	pathPart := strings.TrimSpace(line[:idx])
	pkg := strings.TrimSpace(line[idx+1:])
	if pathPart == "" || !isPackageName(pkg) {
		return "", "", false
	}
	return pkg, pathPart, true
}

func parsePackagePathsOutput(out string) map[string]string {
	paths := map[string]string{}
	for _, line := range strings.Split(out, "\n") {
		pkg, pathPart, ok := parsePackagePathLine(line)
		if ok {
			paths[pkg] = pathPart
		}
	}
	return paths
}

func apkPathFromPMLine(line string) (string, bool) {
	line = strings.TrimSpace(line)
	if line == "" {
		return "", false
	}
	line = strings.TrimPrefix(line, "package:")
	line = strings.TrimPrefix(line, "path:")
	line = strings.TrimSpace(line)
	if line == "" || strings.HasPrefix(line, "package:") || strings.HasPrefix(line, "path:") {
		return "", false
	}
	return line, true
}

// packagePathsFromPM asks for every package together with its APK path in one
// call (`pm list packages -f`). Returns nil when the call itself failed.
func packagePathsFromPM() map[string]string {
	out, err := executeADB("shell", "pm", "list", "packages", "-f")
	if err != nil {
		return nil
	}
	return parsePackagePathsOutput(out)
}

// listAllPackageNames asks for every installed package name (system + user +
// updated system apps). Returns nil when the call itself failed.
func listAllPackageNames() []string {
	out, err := executeADB("shell", "pm", "list", "packages")
	if err != nil {
		return nil
	}
	names := make([]string, 0, 128)
	for _, line := range strings.Split(out, "\n") {
		name := strings.TrimSpace(strings.TrimPrefix(strings.TrimSpace(line), "package:"))
		if name != "" {
			names = append(names, name)
		}
	}
	return names
}

func launcherPackageFromLine(line string) (string, bool) {
	line = strings.TrimSpace(line)
	if line == "" || strings.Contains(line, "android.intent") || strings.HasPrefix(line, "priority=") {
		return "", false
	}
	if strings.Contains(line, "ActivityInfo{") {
		for _, field := range strings.Fields(line) {
			if strings.Contains(field, "/") {
				line = field
				break
			}
		}
	}
	slash := strings.Index(line, "/")
	if slash < 0 {
		return "", false
	}
	pkg := strings.Trim(line[:slash], " \t{}")
	if !isPackageName(pkg) {
		return "", false
	}
	return pkg, true
}

func launchablePackages() map[string]bool {
	out, err := executeADB("shell", "cmd", "package", "query-intent-activities", "--brief", "-a", "android.intent.action.MAIN", "-c", "android.intent.category.LAUNCHER")
	if err != nil {
		out, err = executeADB("shell", "cmd", "package", "query-intent-activities", "-a", "android.intent.action.MAIN", "-c", "android.intent.category.LAUNCHER")
		if err != nil {
			return nil
		}
	}
	result := map[string]bool{}
	for _, line := range strings.Split(out, "\n") {
		if pkg, ok := launcherPackageFromLine(line); ok {
			result[pkg] = true
		}
	}
	return result
}

func isServiceLikePackage(pkg string, launchable bool) bool {
	lower := strings.ToLower(strings.TrimSpace(pkg))
	if lower == "" {
		return true
	}
	if strings.HasPrefix(lower, "org.chromium.webapk.") {
		return true
	}
	serviceMarkers := []string{
		".adservices", ".analytics", ".api", ".apis", ".extension", ".extensions",
		".framework", ".module", ".plugin", ".provider", ".service", ".services",
	}
	for _, marker := range serviceMarkers {
		if strings.Contains(lower, marker) || strings.HasSuffix(lower, marker) {
			return true
		}
	}
	return !launchable
}

// resolvePackagePaths fills missing APK paths with one `pm path` call per app
// (bounded parallelism). This is the safety net that makes EVERY app appear —
// with its icon — even on devices where `pm list packages -f` comes back empty
// or truncated.
func resolvePackagePaths(pkgs []string) map[string]string {
	result := make(map[string]string, len(pkgs))
	sem := make(chan struct{}, 8)
	var wg sync.WaitGroup
	var mu sync.Mutex
	for _, pkg := range pkgs {
		wg.Add(1)
		sem <- struct{}{}
		go func(name string) {
			defer wg.Done()
			defer func() { <-sem }()
			out, err := executeADB("shell", "pm", "path", name)
			if err != nil {
				return
			}
			base := ""
			for _, line := range strings.Split(out, "\n") {
				line, ok := apkPathFromPMLine(line)
				if !ok {
					continue
				}
				if base == "" || strings.Contains(strings.ToLower(line), "base.apk") {
					base = line
				}
				if strings.Contains(strings.ToLower(base), "base.apk") {
					break
				}
			}
			if base != "" {
				mu.Lock()
				result[name] = base
				mu.Unlock()
			}
		}(pkg)
	}
	wg.Wait()
	return result
}

// getAPKPaths returns every APK path for a package by calling `pm path`.
// It returns an error if the adb call itself failed.
func getAPKPaths(pkg string) ([]string, error) {
	out, err := executeADB("shell", "pm", "path", pkg)
	if err != nil {
		return nil, err
	}
	paths := make([]string, 0, 4)
	for _, line := range strings.Split(out, "\n") {
		if path, ok := apkPathFromPMLine(line); ok {
			paths = append(paths, path)
		}
	}
	return paths, nil
}

// GetInstalledApps lists ALL installed packages — user and system apps — with
// metadata. Icons are fetched lazily via GetAppIcon so this call stays fast even
// with hundreds of apps.
func (a *App) GetInstalledApps() ([]AppInfo, error) {
	return a.getInstalledApps(nil)
}

// getInstalledApps is the implementation behind GetInstalledApps. When progress
// is set it receives (message, percent) updates, so the expensive first run —
// where every APK is opened once to resolve its display name — never looks
// frozen on a single percentage while it works.
func (a *App) getInstalledApps(progress func(message string, percent int)) ([]AppInfo, error) {
	report := func(message string, percent int) {
		if progress != nil {
			progress(message, percent)
		}
	}
	if err := a.requireAnyDevice(); err != nil {
		return nil, err
	}

	report("Reading installed packages", 7)
	paths := packagePathsFromPM()
	pathsFailed := paths == nil
	if paths == nil {
		paths = map[string]string{}
	}
	names := listAllPackageNames()
	if names == nil && pathsFailed {
		return nil, fmt.Errorf("could not list installed packages — the device did not answer 'pm list packages'")
	}

	// Union of both sources so no app is ever missed.
	nameSet := map[string]bool{}
	for _, name := range names {
		nameSet[name] = true
	}
	for pkg := range paths {
		if !nameSet[pkg] {
			nameSet[pkg] = true
			names = append(names, pkg)
		}
	}

	// Resolve any package whose APK path is still unknown so its icon can be read.
	missing := make([]string, 0, len(names))
	for _, name := range names {
		if _, ok := paths[name]; !ok {
			missing = append(missing, name)
		}
	}
	if len(missing) > 0 {
		for pkg, path := range resolvePackagePaths(missing) {
			paths[pkg] = path
		}
	}
	report("Resolving app names", 10)
	warmAppLabels(paths, func(done, total int) {
		if total <= 0 {
			return
		}
		percent := 10 + 8*done/total
		report(fmt.Sprintf("Resolving app names (%d/%d)", done, total), percent)
	})
	report("App list ready", 18)

	thirdParty := thirdPartyPackages()
	systemPkgs := systemPackages()
	disabledPkgs := listPackagesFlag("-d")
	launchablePkgs := launchablePackages()

	recommendations, err := loadAppRecommendations()
	if err != nil {
		recommendations = map[string]AppData{}
	}

	apps := make([]AppInfo, 0, len(names))
	for _, pkg := range names {
		pkg = strings.TrimSpace(pkg)
		if pkg == "" {
			continue
		}
		apkPath := paths[pkg]

		isThirdParty := classifyIsThirdParty(pkg, apkPath, thirdParty, systemPkgs)
		isLaunchable := launchablePkgs == nil || launchablePkgs[pkg]

		info := AppInfo{
			PackageName:   pkg,
			Name:          formatAppLabel(pkg),
			Path:          apkPath,
			IsThirdParty:  isThirdParty,
			IsSystem:      !isThirdParty,
			IsLaunchable:  isLaunchable,
			IsServiceLike: isServiceLikePackage(pkg, isLaunchable),
			IsDisabled:    disabledPkgs != nil && disabledPkgs[pkg],
		}
		// The name the user sees on the phone, resolved from the APK's android:label
		// and cached by package name. The package-name guess stays as the fallback.
		if label := cachedAppLabel(pkg); label != "" {
			info.Name = label
		}
		if data, ok := recommendations[pkg]; ok {
			info.Recommended = data.Removal
			info.IsSafe = !strings.Contains(strings.ToLower(data.Removal), "unsafe")
		} else {
			info.Recommended = "No recommendation in local database"
			info.IsSafe = true
		}
		apps = append(apps, info)
	}

	sort.Slice(apps, func(i, j int) bool {
		return strings.ToLower(apps[i].Name) < strings.ToLower(apps[j].Name)
	})
	return apps, nil
}

func (a *App) GetSMSLogs() ([]MessageItem, error) {
	out, err := executeADB("shell", "content", "query", "--uri", "content://sms", "--projection", "address:body:date:type")
	if err != nil {
		return nil, err
	}
	items := make([]MessageItem, 0)
	for _, line := range strings.Split(strings.TrimSpace(out), "\n") {
		line = strings.TrimSpace(line)
		if line == "" || !strings.Contains(line, "address=") {
			continue
		}
		parsed := parseKeyValuePairs(line)
		items = append(items, MessageItem{
			Address: parsed["address"],
			Body:    parsed["body"],
			Date:    parsed["date"],
			Type:    parsed["type"],
		})
	}
	return items, nil
}

func (a *App) GetPhoneLogs() ([]CallLogItem, error) {
	out, err := executeADB("shell", "content", "query", "--uri", "content://call_log/calls", "--projection", "name:number:type:date")
	if err != nil {
		return nil, err
	}
	items := make([]CallLogItem, 0)
	for _, line := range strings.Split(strings.TrimSpace(out), "\n") {
		line = strings.TrimSpace(line)
		if line == "" || !strings.Contains(line, "number=") {
			continue
		}
		parsed := parseKeyValuePairs(line)
		items = append(items, CallLogItem{
			Name:   parsed["name"],
			Number: parsed["number"],
			Type:   parsed["type"],
			Date:   parsed["date"],
		})
	}
	return items, nil
}

func parseKeyValuePairs(line string) map[string]string {
	result := map[string]string{}
	parts := strings.Split(line[strings.Index(line+"=", "=")+0:], ",")
	// Android `content query` prints "Row: 0 address=..., body=..." — body may
	// contain spaces, so parse key=value pairs separated by ", " when possible,
	// falling back to whitespace splitting.
	if len(parts) > 1 {
		for _, part := range parts {
			if idx := strings.Index(part, "="); idx >= 0 {
				result[strings.TrimSpace(part[:idx])] = strings.TrimSpace(part[idx+1:])
			}
		}
		if len(result) > 0 {
			return result
		}
	}
	for _, part := range strings.Fields(line) {
		if idx := strings.Index(part, "="); idx >= 0 {
			result[part[:idx]] = part[idx+1:]
		}
	}
	return result
}

// residualMarker describes a location where deleted/residual data commonly lingers.
type residualMarker struct {
	needle string
	note   string
}

var residualMarkers = []residualMarker{
	{"trash", "Android trash / recycle bin"},
	{".deleted", "Deleted-items folder"},
	{".recycle", "Recycle folder"},
	{"/cache", "Application cache"},
	{"cache/", "Application cache"},
	{"tmp", "Temporary folder"},
	{"temp/", "Temporary folder"},
	{"lost+found", "Filesystem lost+found"},
	{"thumbnail", "Thumbnail cache (often holds deleted media previews)"},
	{"allbackup", "System/app backup store"},
	{"/backup", "Backup folder"},
	{"/backups", "Backup folder"},
	{"/databases/", "Databases folder"},
	{"/logs/", "Log folder"},
	{"/recents/", "Recent items"},
	{"/recovered", "Previously recovered files"},
}

// residualReason returns a human note when a path looks like residual data.
func residualReason(path string) (string, bool) {
	lower := strings.ToLower(path)
	if strings.HasPrefix(filepath.Base(path), ".") {
		return "Hidden file", true
	}
	for _, marker := range residualMarkers {
		if strings.Contains(lower, marker.needle) {
			return marker.note, true
		}
	}
	return "", false
}

func phoneDataReason(path string) (string, bool) {
	lower := strings.ToLower(path)
	markers := []string{"/sms", "/call", "/contact", "/phone", "telephony", "voicemail", "mmssms", "calllog"}
	for _, marker := range markers {
		if strings.Contains(lower, marker) {
			return "Phone data store (messages / call logs / contacts)", true
		}
	}
	return "", false
}

func recoveryRoots(deep bool) []string {
	roots := []string{
		"/sdcard/.trash-storage",
		"/sdcard/.thumbnails",
		"/sdcard/Android/data",
		"/sdcard/Android/media",
		"/sdcard/LOST.DIR",
	}
	if deep {
		roots = append(roots,
			"/sdcard",
			"/storage/emulated/0",
			"/data/media/0",
			"/mnt/media_rw",
		)
	}
	return roots
}

type findResult struct {
	root   string
	lines  []string
	failed bool
}

// runFind lists files under a root. It reports whether the adb call itself failed
// so the caller can tell "nothing found" apart from "device unreachable".
func runFind(root string, deep bool) findResult {
	args := []string{"shell", "find", deviceQuote(root)}
	if !deep {
		args = append(args, "-maxdepth", "6")
	}
	args = append(args, "-type", "f", "2>/dev/null")
	out, err := executeADB(args...)
	if err != nil {
		return findResult{root: root, failed: true}
	}
	lines := make([]string, 0, 256)
	for _, line := range strings.Split(out, "\n") {
		path := strings.TrimSpace(line)
		if path != "" {
			lines = append(lines, path)
		}
	}
	return findResult{root: root, lines: lines}
}

// deviceReachable is a cheap liveness probe used to explain empty results.
func deviceReachable() bool {
	out, err := executeADB("shell", "echo", "ok")
	return err == nil && strings.Contains(out, "ok")
}

// ScanRecoverableFiles performs an interactive, type-aware residual data scan.
//
// Quick scan only reports files in known residual locations (trash, caches,
// thumbnails, backup stores). Deep scan additionally reports every matching file
// anywhere in shared storage, with residual hits sorted first.
func (a *App) ScanRecoverableFiles(req RecoveryRequest) ([]RecoveryItem, error) {
	if err := a.requireAnyDevice(); err != nil {
		return nil, err
	}

	mode := strings.ToLower(strings.TrimSpace(req.Mode))
	if mode == "" {
		mode = "all"
	}
	query := strings.ToLower(strings.TrimSpace(req.Query))
	phoneMode := mode == "phone" || mode == "phone_data" || mode == "messages" || mode == "calls"

	roots := recoveryRoots(req.Deep)
	if phoneMode {
		roots = append(roots,
			"/sdcard/MIUI/backup/AllBackup",
			"/sdcard/MIUI/backup",
			"/sdcard/backups",
			"/sdcard/SMSBackupRestore",
		)
	}

	const maxResults = 4000

	sem := make(chan struct{}, 3)
	found := make(chan findResult, len(roots))
	var wg sync.WaitGroup
	for _, root := range roots {
		wg.Add(1)
		sem <- struct{}{}
		go func(r string) {
			defer wg.Done()
			defer func() { <-sem }()
			found <- runFind(r, req.Deep)
		}(root)
	}
	go func() {
		wg.Wait()
		close(found)
	}()

	seen := map[string]bool{}
	results := make([]RecoveryItem, 0, 256)
	anyLines := false
	anyFailure := false
	allFailed := true

	for batch := range found {
		if batch.failed {
			anyFailure = true
		} else {
			allFailed = false
		}
		if len(batch.lines) > 0 {
			anyLines = true
			allFailed = false
		}

		for _, path := range batch.lines {
			if len(results) >= maxResults {
				break
			}
			if seen[path] {
				continue
			}
			seen[path] = true

			name := filepath.Base(path)
			if name == "" || name == "/" || name == "." {
				continue
			}

			kind := fileKind(name)
			if !phoneMode && !kindMatchesMode(kind, mode) {
				continue
			}
			if query != "" && !strings.Contains(strings.ToLower(path), query) {
				continue
			}

			note := ""
			residual := false
			if reason, ok := residualReason(path); ok {
				note = reason
				residual = true
			}
			if phoneMode {
				if reason, ok := phoneDataReason(path); ok {
					note = reason
					residual = true
				}
			}

			// Quick scan is residual-only; deep scan accepts everything matching the
			// selected type and simply ranks residual hits first.
			if !residual && !req.Deep {
				continue
			}

			results = append(results, RecoveryItem{
				Path:       path,
				Name:       name,
				Type:       kind,
				Kind:       kind,
				Size:       "unknown",
				Hidden:     strings.HasPrefix(name, "."),
				Notes:      note,
				SourcePath: path,
			})
		}
	}

	// Every root failed and nothing came back: the device went away mid-scan.
	if allFailed || (anyFailure && !anyLines && !deviceReachable()) {
		return nil, fmt.Errorf("device not reachable over ADB — reconnect the phone and try again")
	}

	sort.Slice(results, func(i, j int) bool {
		left, right := results[i], results[j]
		leftResidual := left.Notes != ""
		rightResidual := right.Notes != ""
		if leftResidual != rightResidual {
			return leftResidual
		}
		if left.Hidden != right.Hidden {
			return left.Hidden
		}
		return left.Path < right.Path
	})
	return results, nil
}

// SearchDeletedFiles is kept for backwards compatibility with older frontends.
func (a *App) SearchDeletedFiles(query string, filter string) ([]RecoveryItem, error) {
	return a.ScanRecoverableFiles(RecoveryRequest{Mode: filter, Query: query, Deep: false})
}

// RestoreRecoveredFile copies a residual file into a visible device folder.
func (a *App) RestoreRecoveredFile(remotePath string) error {
	return a.RestoreRecoveredFileTo(remotePath, "/sdcard/Recovered")
}

// RestoreRecoveredFileTo copies a residual file into a chosen device folder.
func (a *App) RestoreRecoveredFileTo(remotePath string, targetFolder string) error {
	remotePath = strings.TrimSpace(remotePath)
	if remotePath == "" {
		return fmt.Errorf("empty recovery path")
	}
	targetFolder = strings.TrimSpace(targetFolder)
	if targetFolder == "" {
		targetFolder = "/sdcard/Recovered"
	}

	if _, err := executeADB("shell", "mkdir", "-p", deviceQuote(targetFolder)); err != nil {
		return err
	}

	filename := filepath.Base(remotePath)
	filename = strings.TrimLeft(filename, ".")
	if filename == "" || filename == "/" {
		filename = "recovered_file"
	}
	target := strings.TrimRight(targetFolder, "/") + "/" + filename
	_, err := executeADB("shell", "cp", "-n", deviceQuote(remotePath), deviceQuote(target))
	if err != nil {
		return err
	}
	return nil
}

// RecoverFileToPC copies a residual file from the device to the host.
func (a *App) RecoverFileToPC(remotePath, localDir string) (string, error) {
	return a.SaveFileToPC(remotePath, localDir)
}

// removableRemotePath bounds where the recovery "Remove" action may delete.
// Only shared storage is allowed, so no crafted path can take out the system or
// app data.
func removableRemotePath(path string) bool {
	path = strings.TrimSpace(path)
	if path == "" || !strings.HasPrefix(path, "/") {
		return false
	}
	for _, prefix := range []string{"/sdcard/", "/storage/", "/data/media/", "/mnt/"} {
		if strings.HasPrefix(path, prefix) && len(path) > len(prefix) {
			return true
		}
	}
	return false
}

// DeleteRecoveredFile removes one residual file found by the recovery scanner.
func (a *App) DeleteRecoveredFile(remotePath string) error {
	if err := a.requireAnyDevice(); err != nil {
		return err
	}
	remotePath = strings.TrimSpace(remotePath)
	if !removableRemotePath(remotePath) {
		return fmt.Errorf("refusing to delete %q: only files under shared storage (/sdcard, /storage, /mnt) can be removed", remotePath)
	}
	_, err := executeADB("shell", "rm", "-f", deviceQuote(remotePath))
	return err
}

// DeleteRecoveredFiles removes several recovery results at once with progress.
func (a *App) DeleteRecoveredFiles(paths []string) (*TransferResult, error) {
	if err := a.requireAnyDevice(); err != nil {
		return nil, err
	}
	clean := cleanPaths(paths)
	result := &TransferResult{Operation: "delete", TotalFiles: len(clean)}
	reporter := newProgressReporter(a, "delete", len(clean))
	if len(clean) == 0 {
		reporter.finish("Nothing to delete.")
		return result, nil
	}

	for _, path := range clean {
		if !removableRemotePath(path) {
			result.Failed++
			reporter.addFailed()
			if len(result.Errors) < 40 {
				result.Errors = append(result.Errors, fmt.Sprintf("refused (outside shared storage): %s", path))
			}
			reporter.report("deleting", "", remoteBaseName(path), false, "")
			continue
		}
		if _, err := executeADB("shell", "rm", "-f", deviceQuote(path)); err != nil {
			result.Failed++
			reporter.addFailed()
			if len(result.Errors) < 40 {
				result.Errors = append(result.Errors, fmt.Sprintf("%s: %v", path, err))
			}
		} else {
			result.Copied++
		}
		reporter.report("deleting", "", remoteBaseName(path), false, "")
	}

	message := fmt.Sprintf("Removed %d of %d files", result.Copied, result.TotalFiles)
	if result.Failed > 0 {
		message += fmt.Sprintf(" (%d failed)", result.Failed)
	}
	reporter.finish(message)
	return result, nil
}

func (a *App) ConnectWiFiDevice(ip string) (string, error) {
	out, err := executeADB("connect", ip)
	if err != nil {
		return "", err
	}
	return out, nil
}
