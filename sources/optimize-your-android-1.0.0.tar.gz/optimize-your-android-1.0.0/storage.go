package main

import (
	"fmt"
	"sort"
	"strconv"
	"strings"

	wruntime "github.com/wailsapp/wails/v2/pkg/runtime"
)

// StorageVolume is one user-facing storage entry point on the device: the
// internal shared storage and any mounted SD card / USB-OTG volume, with its
// capacity so the file browser can show where the user's files live.
type StorageVolume struct {
	Label       string `json:"label"`
	Path        string `json:"path"`      // browsable path for the file browser
	MountPath   string `json:"mountPath"` // kernel mount used for the size probe
	TotalBytes  int64  `json:"totalBytes"`
	UsedBytes   int64  `json:"usedBytes"`
	FreeBytes   int64  `json:"freeBytes"`
	IsRemovable bool   `json:"isRemovable"`
}

// remoteDirExists is a cheap probe: `test -d` exits 0 only for directories.
func remoteDirExists(path string) bool {
	if strings.TrimSpace(path) == "" {
		return false
	}
	_, err := executeADB("shell", "test", "-d", deviceQuote(path))
	return err == nil
}

// RemotePathExists reports whether a device path exists at all (file or folder).
func (a *App) RemotePathExists(path string) (bool, error) {
	path = strings.TrimSpace(path)
	if path == "" {
		return false, nil
	}
	_, err := executeADB("shell", "test", "-e", deviceQuote(path))
	return err == nil, nil
}

// dfStats reads total/used/free bytes for a mounted path via the device's `df`.
// toybox df prints 1K blocks, e.g.:
//
//	Filesystem     1K-blocks     Used Available Use% Mounted on
//	/dev/fuse    114901032 64044356  50856676  56% /storage/emulated
func dfStats(remotePath string) (total, used, free int64, err error) {
	out, dfErr := executeADB("shell", "df", "-k", deviceQuote(remotePath))
	if dfErr != nil {
		return 0, 0, 0, dfErr
	}
	parse := func(field string) int64 {
		value, parseErr := strconv.ParseInt(field, 10, 64)
		if parseErr != nil {
			return 0
		}
		return value
	}
	for _, line := range strings.Split(out, "\n") {
		fields := strings.Fields(line)
		if len(fields) < 4 {
			continue
		}
		blocks := parse(fields[1]) * 1024
		if blocks <= 0 {
			continue // header row or an unexpected format
		}
		return blocks, parse(fields[2]) * 1024, parse(fields[3]) * 1024, nil
	}
	return 0, 0, 0, fmt.Errorf("could not read the storage size of %s", remotePath)
}

// listStorageNames enumerates /storage so removable cards and OTG drives show up
// (they appear as XXXX-XXXX volume UUIDs once mounted).
func listStorageNames() []string {
	out, err := executeADB("shell", "ls", "-1", "/storage", "2>/dev/null")
	if err != nil {
		return nil
	}
	names := make([]string, 0, 4)
	for _, line := range strings.Split(out, "\n") {
		name := strings.TrimSpace(line)
		if name == "" || name == "emulated" || name == "self" || name == "enc_emulated" {
			continue
		}
		names = append(names, name)
	}
	return names
}

// GetStorageVolumes returns the browsable storage entry points with their sizes:
// internal shared storage first, then every mounted SD card / USB volume.
func (a *App) GetStorageVolumes() ([]StorageVolume, error) {
	if err := a.requireAnyDevice(); err != nil {
		return nil, err
	}

	volumes := make([]StorageVolume, 0, 3)

	// Internal shared storage. /sdcard is the stable user-facing alias of
	// /storage/emulated/0; probe the size on the emulated mount.
	internal := StorageVolume{
		Label:       "Internal storage",
		Path:        "/sdcard",
		MountPath:   "/storage/emulated/0",
		IsRemovable: false,
	}
	if !remoteDirExists(internal.MountPath) {
		if remoteDirExists("/sdcard") {
			internal.MountPath = "/sdcard"
		}
	}
	if total, used, free, err := dfStats(internal.MountPath); err == nil && total > 0 {
		internal.TotalBytes, internal.UsedBytes, internal.FreeBytes = total, used, free
	} else if remoteDirExists("/sdcard") {
		// Size unknown but the volume is browsable — still worth showing.
		internal.MountPath = "/sdcard"
	} else {
		internal.MountPath = ""
	}
	if internal.MountPath != "" {
		volumes = append(volumes, internal)
	}

	// Removable volumes (SD cards, USB-OTG drives).
	names := listStorageNames()
	sort.Strings(names)
	for _, name := range names {
		mount := "/storage/" + name
		if !remoteDirExists(mount) {
			continue
		}
		volume := StorageVolume{
			Label:       "SD card",
			Path:        mount,
			MountPath:   mount,
			IsRemovable: true,
		}
		if total, used, free, err := dfStats(mount); err == nil && total > 0 {
			volume.TotalBytes, volume.UsedBytes, volume.FreeBytes = total, used, free
		}
		volumes = append(volumes, volume)
	}

	return volumes, nil
}

// ChooseFolder opens a native "pick a folder" dialog and returns the chosen
// path, or "" when the user cancels. Used for backup targets, restore sources
// and bulk saves so the user always decides where files go.
func (a *App) ChooseFolder(title string) (string, error) {
	if a.ctx == nil {
		return "", fmt.Errorf("folder dialog is unavailable")
	}
	return wruntime.OpenDirectoryDialog(a.ctx, wruntime.OpenDialogOptions{
		Title:                strings.TrimSpace(title),
		CanCreateDirectories: true,
	})
}
