package main

import (
	"sort"
	"testing"
)

func TestTmpProbeAppBackups(t *testing.T) {
	folder := "/home/abdelilah/device-backup/2201117TY"
	app := NewApp()
	backups, err := app.ListLocalAppBackups(folder)
	if err != nil {
		t.Fatalf("ListLocalAppBackups: %v", err)
	}
	t.Logf("local app backups: %d", len(backups))
	sort.Slice(backups, func(i, j int) bool { return backups[i].TotalBytes < backups[j].TotalBytes })
	for i, b := range backups {
		if i >= 5 {
			break
		}
		t.Logf("  smallest #%d: pkg=%s name=%q files=%d bytes=%d", i, b.Package, b.Name, len(b.Files), b.TotalBytes)
		for _, f := range b.Files {
			t.Logf("      %s", f)
		}
	}
	installed := listAllPackageNames()
	t.Logf("device installed packages: %d", len(installed))
	withBase, withName := 0, 0
	for _, b := range backups {
		if b.Name != "" {
			withName++
		}
		for _, f := range b.Files {
			if remoteBaseName(f) == "base.apk" {
				withBase++
				break
			}
		}
		if len(b.Files) > 1 {
			t.Logf("  multi-apk: %s (%d files)", b.Package, len(b.Files))
		}
	}
	missing := 0
	for _, b := range backups {
		if !containsPackage(installed, b.Package) {
			missing++
		}
	}
	t.Logf("apps with a display name: %d; apps with base.apk: %d; not installed on device: %d", withName, withBase, missing)
}
