package main

import (
	"archive/zip"
	"bytes"
	"encoding/base64"
	"encoding/json"
	"fmt"
	"image"
	"image/color"
	"image/png"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

func TestParseLsLine(t *testing.T) {
	line := "drwxrwx---  5 root everybody  3488 2026-08-16 08:03 Android"
	entry, ok := parseLsLine(line, "/sdcard")
	if !ok {
		t.Fatalf("expected line to parse")
	}
	if entry.Name != "Android" || !entry.IsDir || entry.Size != 3488 {
		t.Fatalf("unexpected entry: %+v", entry)
	}
	if entry.Path != "/sdcard/Android" {
		t.Fatalf("unexpected path: %s", entry.Path)
	}

	fileLine := "-rw-rw----  1 root everybody 73140 2025-10-27 22:16 Z_portofilio.html"
	fileEntry, ok := parseLsLine(fileLine, "/sdcard")
	if !ok || fileEntry.IsDir || fileEntry.Size != 73140 {
		t.Fatalf("unexpected file entry: %+v ok=%v", fileEntry, ok)
	}

	linkLine := "lrwxrwxrwx  1 root root 21 2009-01-01 00:00 sdcard -> /storage/self/primary"
	linkEntry, ok := parseLsLine(linkLine, "/")
	if !ok || !linkEntry.IsSymlink || linkEntry.Name != "sdcard" {
		t.Fatalf("unexpected link entry: %+v ok=%v", linkEntry, ok)
	}

	if _, ok := parseLsLine("total 656", "/sdcard"); ok {
		t.Fatalf("total line should be ignored")
	}
	if _, ok := parseLsLine("garbage", "/sdcard"); ok {
		t.Fatalf("garbage line should be ignored")
	}
}

func TestParseLsLineKeepsSpacesInNames(t *testing.T) {
	line := "-rw-rw----  1 root everybody 1024 2026-01-02 03:04 my holiday photo.jpg"
	entry, ok := parseLsLine(line, "/sdcard/DCIM")
	if !ok {
		t.Fatalf("expected line to parse")
	}
	if entry.Name != "my holiday photo.jpg" {
		t.Fatalf("unexpected name %q", entry.Name)
	}
}

func TestParseLsLineAbsolute(t *testing.T) {
	line := "-rw-rw---- 1 root everybody 1731123 2026-09-29 12:49 /sdcard/DCIM/Camera/IMG_20260929.jpg"
	entry, ok := parseLsLineAbsolute(line)
	if !ok {
		t.Fatalf("expected absolute line to parse")
	}
	if entry.Path != "/sdcard/DCIM/Camera/IMG_20260929.jpg" {
		t.Fatalf("unexpected path %q", entry.Path)
	}
	if entry.Name != "IMG_20260929.jpg" || entry.Size != 1731123 {
		t.Fatalf("unexpected entry %+v", entry)
	}

	spaced := "-rw-rw---- 1 root everybody 1024 2026-01-02 03:04 /sdcard/DCIM/my holiday photo.jpg"
	spacedEntry, ok := parseLsLineAbsolute(spaced)
	if !ok || spacedEntry.Path != "/sdcard/DCIM/my holiday photo.jpg" {
		t.Fatalf("space handling broken: %+v ok=%v", spacedEntry, ok)
	}

	if _, ok := parseLsLineAbsolute("drwxrwx--- 2 root everybody 3488 2026-07-31 13:26 /sdcard/DCIM"); ok {
		t.Fatalf("directories should be ignored by the file-only parser")
	}
}

func TestFileKindAndMime(t *testing.T) {
	cases := []struct {
		name string
		kind string
	}{
		{"a.JPG", KindImage},
		{"clip.mp4", KindVideo},
		{"song.mp3", KindAudio},
		{"doc.pdf", KindPDF},
		{"notes.txt", KindText},
		{"sheet.xlsx", KindDocument},
		{"bundle.zip", KindArchive},
		{"app.apk", KindAPK},
		{"mystery.bin", KindOther},
	}
	for _, testCase := range cases {
		if got := fileKind(testCase.name); got != testCase.kind {
			t.Errorf("fileKind(%s) = %s, want %s", testCase.name, got, testCase.kind)
		}
	}
	if fileMime("a.png") != "image/png" {
		t.Fatalf("unexpected mime")
	}
}

func TestKindMatchesMode(t *testing.T) {
	if !kindMatchesMode(KindImage, "photos") {
		t.Fatalf("photos should match images")
	}
	if kindMatchesMode(KindVideo, "photos") {
		t.Fatalf("photos should not match videos")
	}
	if !kindMatchesMode(KindOther, "all") {
		t.Fatalf("all should match anything")
	}
	if !kindMatchesMode(KindText, "documents") {
		t.Fatalf("documents should match text")
	}
	if kindMatchesMode(KindImage, "apk") {
		t.Fatalf("apk should not match images")
	}
}

func TestPickIconEntry(t *testing.T) {
	entries := []apkEntry{
		{name: "res/layout/intercom_default_launcher.xml", size: 1696},
		{name: "res/mipmap-anydpi-v26/ic_launcher.xml", size: 448},
		{name: "res/mipmap-hdpi-v4/ic_launcher.png", size: 1032},
		{name: "res/mipmap-xxxhdpi-v4/ic_launcher.png", size: 2336},
		{name: "res/mipmap-mdpi-v4/ic_launcher.png", size: 951},
	}
	best, ok := pickIconEntry(entries)
	if !ok {
		t.Fatalf("expected an icon entry")
	}
	if !strings.Contains(best.name, "xxxhdpi") {
		t.Fatalf("expected highest density icon, got %s", best.name)
	}
}

func TestPickIconEntryRejectsNonImages(t *testing.T) {
	entries := []apkEntry{{name: "res/mipmap-anydpi-v26/ic_launcher.xml", size: 448}}
	if _, ok := pickIconEntry(entries); ok {
		t.Fatalf("xml-only archives should yield no raster icon")
	}
}

func TestDetectImageMime(t *testing.T) {
	png := append([]byte{0x89, 'P', 'N', 'G', '\r', '\n', 0x1a, '\n'}, make([]byte, 8)...)
	if mime := detectImageMime(png); mime != "image/png" {
		t.Fatalf("png detection failed: %s", mime)
	}
	webp := []byte("RIFF\x00\x00\x00\x00WEBPVP8 ")
	if mime := detectImageMime(webp); mime != "image/webp" {
		t.Fatalf("webp detection failed: %s", mime)
	}
	jpeg := []byte{0xFF, 0xD8, 0xFF, 0xE0}
	if mime := detectImageMime(jpeg); mime != "image/jpeg" {
		t.Fatalf("jpeg detection failed: %s", mime)
	}
	if detectImageMime([]byte("hello")) != "" {
		t.Fatalf("non-image should not detect")
	}
}

func TestFormatAppLabel(t *testing.T) {
	if got := formatAppLabel("com.busuu.android.enc"); got != "Busuu" {
		t.Fatalf("unexpected label %q", got)
	}
	if got := formatAppLabel("com.android.settings"); got != "Settings" {
		t.Fatalf("unexpected label %q", got)
	}
	if got := formatAppLabel("com.example.my_app"); got != "My App" {
		t.Fatalf("unexpected label %q", got)
	}
}

// TestClassifyIsThirdParty pins the classification priority: the device's own
// -3 list, then its -s list, then the path heuristic. The regression this guards
// against: a preinstalled app that received an update lives under /data/app, so
// the path check alone would show it as a user-installed app.
func TestClassifyIsThirdParty(t *testing.T) {
	thirdPartyOK := map[string]bool{"com.user.app": true}
	systemOK := map[string]bool{"com.android.chrome": true}

	// 1. -3 answered: it is authoritative, even for a /data/app path.
	if !classifyIsThirdParty("com.user.app", "/data/app/x/base.apk", thirdPartyOK, nil) {
		t.Errorf("-3 must win: package listed as user app classified as system")
	}
	if classifyIsThirdParty("com.android.chrome", "/data/app/y/base.apk", thirdPartyOK, nil) {
		t.Errorf("-3 must win: updated system app in /data/app must classify as system")
	}

	// 2. -3 failed, -s answered: inverted -s still catches updated system apps.
	if classifyIsThirdParty("com.android.chrome", "/data/app/y/base.apk", nil, systemOK) {
		t.Errorf("-s inversion must catch updated system apps under /data/app")
	}
	if !classifyIsThirdParty("com.user.app", "/data/app/x/base.apk", nil, systemOK) {
		t.Errorf("-s inversion must keep non-system packages as user apps")
	}

	// 3. In neither answered list (other-user package): path heuristic.
	if !classifyIsThirdParty("com.other.user", "/data/app/z/base.apk", thirdPartyOK, systemOK) {
		t.Errorf("unlisted /data/app package should fall back to the path check as user app")
	}
	if classifyIsThirdParty("com.other.sys", "/system/app/A/base.apk", thirdPartyOK, systemOK) {
		t.Errorf("unlisted /system package should fall back to the path check as system")
	}

	// 4. Both lists failed: pure path heuristic.
	if !classifyIsThirdParty("p", "/data/app/p/base.apk", nil, nil) {
		t.Errorf("path heuristic: /data/app is a user app")
	}
	if classifyIsThirdParty("p", "/system/app/p/base.apk", nil, nil) {
		t.Errorf("path heuristic: /system is a system app")
	}
	if classifyIsThirdParty("p", "", nil, nil) {
		t.Errorf("path heuristic: an app without a path must not be a user app")
	}
}

func TestParsePackagePathLineKeepsBase64EqualsOutOfPackageName(t *testing.T) {
	line := "package:/data/app/~~abc/org.chromium.webapk.a10857d87eb9dbbf4_v2-HxJDrjND9-vlhKb1b-Ndew==/base.apk=org.chromium.webapk.a10857d87eb9dbbf4_v2"
	pkg, path, ok := parsePackagePathLine(line)
	if !ok {
		t.Fatalf("expected package path line to parse")
	}
	if pkg != "org.chromium.webapk.a10857d87eb9dbbf4_v2" {
		t.Fatalf("unexpected package %q", pkg)
	}
	if strings.Contains(pkg, "=") || strings.Contains(pkg, "/base.apk") {
		t.Fatalf("package name contains path data: %q", pkg)
	}
	if !strings.HasSuffix(path, "==/base.apk") {
		t.Fatalf("path lost base64 suffix: %q", path)
	}
}

func TestParsePackagePathsOutputDeduplicatesRealPackageNames(t *testing.T) {
	out := strings.Join([]string{
		"package:/data/app/~~one/com.dv.adm-BtnAakNWxBcyCtAFTzn5oQ==/base.apk=com.dv.adm",
		"package:/data/app/~~two/com.google.android.apps.adm-yL5YItNRB52U5hojngB63w==/base.apk=com.google.android.apps.adm",
	}, "\n")
	paths := parsePackagePathsOutput(out)
	if len(paths) != 2 {
		t.Fatalf("expected 2 packages, got %d: %#v", len(paths), paths)
	}
	if _, exists := paths["=/com.dv.adm-BtnAakNWxBcyCtAFTzn5oQ==/base.apk=com.dv.adm"]; exists {
		t.Fatalf("fake path-derived package leaked into paths: %#v", paths)
	}
	if paths["com.dv.adm"] == "" || paths["com.google.android.apps.adm"] == "" {
		t.Fatalf("real packages missing: %#v", paths)
	}
}

func TestAPKPathFromPMLine(t *testing.T) {
	cases := map[string]string{
		"package:/product/priv-app/MIUIAod/MIUIAod.apk":                                                                                  "/product/priv-app/MIUIAod/MIUIAod.apk",
		"package:/data/app/~~qINZ1btm8vm8A2FzvKveSw==/com.pradhyu.alltoolseveryutility-4BUANzOHdstGYwvcNRbk3g==/base.apk":                "/data/app/~~qINZ1btm8vm8A2FzvKveSw==/com.pradhyu.alltoolseveryutility-4BUANzOHdstGYwvcNRbk3g==/base.apk",
		"package:/data/app/~~qINZ1btm8vm8A2FzvKveSw==/com.pradhyu.alltoolseveryutility-4BUANzOHdstGYwvcNRbk3g==/split_config.xxhdpi.apk": "/data/app/~~qINZ1btm8vm8A2FzvKveSw==/com.pradhyu.alltoolseveryutility-4BUANzOHdstGYwvcNRbk3g==/split_config.xxhdpi.apk",
		"path:/data/app/example/base.apk": "/data/app/example/base.apk",
	}
	for input, want := range cases {
		got, ok := apkPathFromPMLine(input)
		if !ok || got != want {
			t.Fatalf("apkPathFromPMLine(%q) = %q, %v; want %q, true", input, got, ok, want)
		}
	}
	if _, ok := apkPathFromPMLine("package:"); ok {
		t.Fatalf("empty package path should not parse")
	}
}

func TestLauncherPackageFromLine(t *testing.T) {
	cases := []string{
		"com.example.app/.MainActivity",
		"  ActivityInfo{23f com.example.two/com.example.two.Main}  ",
	}
	for _, line := range cases {
		pkg, ok := launcherPackageFromLine(line)
		if !ok || !strings.HasPrefix(pkg, "com.example.") {
			t.Fatalf("launcherPackageFromLine(%q) = %q, %v", line, pkg, ok)
		}
	}
	if _, ok := launcherPackageFromLine("priority=0 preferredOrder=0"); ok {
		t.Fatalf("metadata line should not parse as a launcher package")
	}
}

func TestIsServiceLikePackage(t *testing.T) {
	if !isServiceLikePackage("org.chromium.webapk.a10857d87eb9dbbf4_v2", true) {
		t.Fatalf("WebAPK packages should be hidden from the normal installed-app view")
	}
	if !isServiceLikePackage("moe.shizuku.privileged.api", false) {
		t.Fatalf("API/helper packages should be service-like")
	}
	if isServiceLikePackage("com.pradhyu.alltoolseveryutility", true) {
		t.Fatalf("launchable user apps should not be service-like")
	}
}

func TestManifestLabelPlainText(t *testing.T) {
	// Literal label: the name is inline in the manifest.
	literal := []byte(`<manifest android:label="WhatsApp"><application/></manifest>`)
	value, resID, ok := manifestLabel(literal)
	if !ok || value != "WhatsApp" || resID != 0 {
		t.Fatalf("unexpected literal label: value=%q resID=%#x ok=%v", value, resID, ok)
	}

	// Resource reference: resolved later through resources.arsc.
	ref := []byte(`<manifest><application android:label="@0x7f0f0012"/></manifest>`)
	value, resID, ok = manifestLabel(ref)
	if !ok || value != "" || resID != 0x7f0f0012 {
		t.Fatalf("unexpected reference label: value=%q resID=%#x ok=%v", value, resID, ok)
	}

	// @string/… cannot be resolved from the text manifest; it must not return a
	// bogus name.
	if _, _, ok := manifestLabel([]byte(`<manifest android:label="@string/app_name"/>`)); ok {
		t.Fatalf("@string references must not resolve without the resource table")
	}
}

func TestCleanAppLabel(t *testing.T) {
	cases := map[string]string{
		"  WhatsApp  ":   "WhatsApp",
		"@string/app":    "",
		"?attr/whatever": "",
		"res/mipmap.png": "",
		"":               "",
	}
	for input, want := range cases {
		if got := cleanAppLabel(input); got != want {
			t.Errorf("cleanAppLabel(%q) = %q, want %q", input, got, want)
		}
	}
}

func TestLabelIndexRoundTrip(t *testing.T) {
	t.Setenv("XDG_CACHE_HOME", t.TempDir())

	if got := cachedAppLabel("com.example.app"); got != "" {
		t.Fatalf("expected no cached label, got %q", got)
	}
	if err := rememberAppLabel("com.example.app", "My App"); err != nil {
		t.Fatalf("rememberAppLabel failed: %v", err)
	}
	if got := cachedAppLabel("com.example.app"); got != "My App" {
		t.Fatalf("cached label not applied: %q", got)
	}
	// Unresolved labels are never stored, so failures are retried next run.
	if err := rememberAppLabel("com.example.other", "@string/nope"); err != nil {
		t.Fatalf("rememberAppLabel failed: %v", err)
	}
	if got := cachedAppLabel("com.example.other"); got != "" {
		t.Fatalf("unresolved label must not be stored, got %q", got)
	}

	// The index must survive a restart (new process = fresh memory cache).
	labelIndexCache = nil
	if got := cachedAppLabel("com.example.app"); got != "My App" {
		t.Fatalf("label index not persisted: %q", got)
	}
}

func TestRemovableRemotePath(t *testing.T) {
	allowed := []string{
		"/sdcard/DCIM/deleted.jpg",
		"/storage/emulated/0/Download/x.zip",
		"/data/media/0/file.txt",
		"/mnt/media_rw/ABCD-1234/photo.png",
	}
	for _, path := range allowed {
		if !removableRemotePath(path) {
			t.Errorf("%s should be removable", path)
		}
	}
	blocked := []string{
		"", "/", "/sdcard", "/storage", "/system/bin/sh",
		"/data/data/com.android.providers.settings/databases/settings.db",
		"relative/path.txt", "/apex/com.android.runtime/bin/art",
	}
	for _, path := range blocked {
		if removableRemotePath(path) {
			t.Errorf("%s must NOT be removable", path)
		}
	}
}

func TestCheckPMOutput(t *testing.T) {
	if err := checkPMOutput("Package com.foo new state: disabled-user", nil, "disable", "com.foo"); err != nil {
		t.Fatalf("success output treated as failure: %v", err)
	}
	// A package name containing "error" must not trip the failure detection.
	if err := checkPMOutput("Package com.error.app new state: enabled", nil, "enable", "com.error.app"); err != nil {
		t.Fatalf("package name containing 'error' false positive: %v", err)
	}
	if err := checkPMOutput("Error: requires permission android:something", nil, "disable", "com.foo"); err == nil {
		t.Fatalf("'Error:' output must be a failure")
	}
	if err := checkPMOutput("", fmt.Errorf("exit status 1"), "disable", "com.foo"); err == nil {
		t.Fatalf("command error must be reported")
	}
}

func TestParseLsLineAbsoluteAny(t *testing.T) {
	fileLine := "-rw-rw---- 1 root everybody 1731123 2026-09-29 12:49 /sdcard/DCIM/Camera/IMG_20260929.jpg"
	entry, ok := parseLsLineAbsoluteAny(fileLine)
	if !ok || entry.IsDir || entry.Path != "/sdcard/DCIM/Camera/IMG_20260929.jpg" || entry.Size != 1731123 {
		t.Fatalf("file entry mishandled: %+v ok=%v", entry, ok)
	}

	dirLine := "drwxrwx--- 2 root everybody 3488 2026-07-31 13:26 /sdcard/DCIM"
	dirEntry, ok := parseLsLineAbsoluteAny(dirLine)
	if !ok || !dirEntry.IsDir || dirEntry.Path != "/sdcard/DCIM" {
		t.Fatalf("directory entry mishandled: %+v ok=%v", dirEntry, ok)
	}

	linkLine := "lrwxrwxrwx 1 root root 21 2009-01-01 00:00 /sdcard/linked -> /storage/emulated/0/target"
	linkEntry, ok := parseLsLineAbsoluteAny(linkLine)
	if !ok || linkEntry.IsSymlink != false || linkEntry.Path != "/sdcard/linked" {
		// The absolute parser flattens symlinks to their listed path; the arrow
		// target must never leak into the path.
		t.Fatalf("symlink entry mishandled: %+v ok=%v", linkEntry, ok)
	}

	spaced := "-rw-rw---- 1 root everybody 1024 2026-01-02 03:04 /sdcard/my holiday photo.jpg"
	spacedEntry, ok := parseLsLineAbsoluteAny(spaced)
	if !ok || spacedEntry.Path != "/sdcard/my holiday photo.jpg" {
		t.Fatalf("space handling broken: %+v ok=%v", spacedEntry, ok)
	}

	if _, ok := parseLsLineAbsoluteAny("total 656"); ok {
		t.Fatalf("total line should be ignored")
	}
	if _, ok := parseLsLineAbsoluteAny("garbage"); ok {
		t.Fatalf("garbage line should be ignored")
	}
}

func TestParseContentRows(t *testing.T) {
	out := "Row: 0 _id=12, _data=/storage/emulated/0/DCIM/x.jpg\n" +
		"Row: 1 _id=13, _data=/storage/emulated/0/DCIM/y.jpg\n"
	rows := parseContentRows(out)
	if len(rows) != 2 {
		t.Fatalf("expected 2 rows, got %d", len(rows))
	}
	if rows[0]["_id"] != "12" || rows[0]["_data"] != "/storage/emulated/0/DCIM/x.jpg" {
		t.Fatalf("first row mishandled: %+v", rows[0])
	}
	if rows[1]["_id"] != "13" {
		t.Fatalf("second row mishandled: %+v", rows[1])
	}
}

func TestNormalizeMediaPath(t *testing.T) {
	cases := map[string]string{
		"/sdcard/DCIM/a.jpg":                   "/storage/emulated/0/DCIM/a.jpg",
		"/sdcard":                              "/storage/emulated/0",
		"/storage/self/primary/Download/b.mp4": "/storage/emulated/0/Download/b.mp4",
		"/storage/emulated/0/Pictures/c.png":   "/storage/emulated/0/Pictures/c.png",
	}
	for input, want := range cases {
		if got := normalizeMediaPath(input); got != want {
			t.Errorf("normalizeMediaPath(%s) = %s, want %s", input, got, want)
		}
	}
}

func TestCleanPaths(t *testing.T) {
	got := cleanPaths([]string{" /a/b", "", "/a/b", "/c"})
	if len(got) != 2 || got[0] != "/a/b" || got[1] != "/c" {
		t.Fatalf("unexpected cleaned paths: %v", got)
	}
}

func TestPreviewFromBytes(t *testing.T) {
	png := append([]byte{0x89, 'P', 'N', 'G', '\r', '\n', 0x1a, '\n'}, make([]byte, 16)...)
	imagePreview := previewFromBytes("inside.png", png)
	if imagePreview.Kind != KindImage || imagePreview.DataURL == "" || imagePreview.TooLarge {
		t.Fatalf("unexpected image preview: %+v", imagePreview)
	}

	textPreview := previewFromBytes("notes.txt", []byte("hello world"))
	if textPreview.Kind != KindText || textPreview.Text != "hello world" {
		t.Fatalf("unexpected text preview: %+v", textPreview)
	}

	big := previewFromBytes("huge.bin", make([]byte, maxGenericFile+1))
	if !big.TooLarge || big.Message == "" {
		t.Fatalf("oversized entry should be flagged: %+v", big)
	}
}

func TestRelativeRemotePath(t *testing.T) {
	if got := relativeRemotePath("/sdcard/DCIM", "/sdcard/DCIM/Camera/IMG.jpg"); got != "Camera/IMG.jpg" {
		t.Fatalf("unexpected relative path %q", got)
	}
	if got := relativeRemotePath("/sdcard", "/sdcard/a.txt"); got != "a.txt" {
		t.Fatalf("unexpected relative path %q", got)
	}
}

func TestHumanBytes(t *testing.T) {
	if got := humanBytes(0); got != "0 B" {
		t.Fatalf("unexpected %q", got)
	}
	if got := humanBytes(2048); got != "2.0 KB" {
		t.Fatalf("unexpected %q", got)
	}
}

/* ---------------- device-gated integration checks ---------------- */

func connectedApp(t *testing.T) *App {
	t.Helper()
	app := NewApp()
	devices, err := app.GetConnectedDevices()
	if err != nil || len(devices) == 0 {
		t.Skip("no adb device connected")
	}
	return app
}

func TestListAndroidFilesIntegration(t *testing.T) {
	app := connectedApp(t)
	entries, err := app.ListAndroidFiles("/sdcard")
	if err != nil {
		t.Fatalf("ListAndroidFiles failed: %v", err)
	}
	if len(entries) == 0 {
		t.Skip("device returned an empty /sdcard listing")
	}
	for _, entry := range entries {
		if entry.Name == "" || entry.Path == "" {
			t.Fatalf("incomplete entry: %+v", entry)
		}
		if entry.IsDir && entry.Kind != KindDir {
			t.Fatalf("directory should have dir kind: %+v", entry)
		}
	}
}

func TestInstalledAppsAndIconIntegration(t *testing.T) {
	app := connectedApp(t)
	apps, err := app.GetInstalledApps()
	if err != nil {
		t.Fatalf("GetInstalledApps failed: %v", err)
	}
	if len(apps) == 0 {
		t.Skip("no packages reported by device")
	}

	// Find a user app with an APK path to exercise icon extraction.
	for _, info := range apps {
		if info.IsSystem || info.Path == "" {
			continue
		}
		url, err := app.GetAppIcon(info.PackageName, info.Path)
		if err != nil {
			t.Fatalf("GetAppIcon(%s) failed: %v", info.PackageName, err)
		}
		if url != "" && !strings.HasPrefix(url, "data:image/") {
			t.Fatalf("icon should be a data URL, got %.40s", url)
		}
		return
	}
	t.Log("no user app with an apk path found; icon extraction not exercised")
}

func TestIconRulesRejectRandomDrawables(t *testing.T) {
	// Regression guard: a notification/flag/menu drawable must never be used as
	// the app icon just because its name contains "icon".
	for _, name := range []string{
		"res/drawable/ic_notification.png",
		"res/drawable/ic_flag_xx.png",
		"res/drawable/icon_menu.png",
		"res/drawable/splash_logo.png",
	} {
		if score := scoreIconEntry(name); score >= 0 {
			t.Errorf("%s should not be an icon candidate (score %d)", name, score)
		}
	}
	for _, name := range []string{
		"res/mipmap-xxxhdpi-v4/ic_launcher.png",
		"res/mipmap-anydpi-v26/ic_launcher_foreground.png",
		"res/drawable/app_icon.png",
	} {
		if score := scoreIconEntry(name); score < 0 {
			t.Errorf("%s should be an icon candidate", name)
		}
	}
}

// The backup plan used to report "0 B" for non-empty folders when the category
// availability probe failed. Guard the invariant: files found => bytes > 0.
func TestBackupPlanBytesIntegration(t *testing.T) {
	app := connectedApp(t)

	plan, err := app.PreviewBackupPlan(
		[]string{"Photos", "Pictures", "Downloads", "Music"},
		"./tmp-plan",
		[]string{"/sdcard/DCIM"},
	)
	if err != nil {
		t.Fatalf("PreviewBackupPlan failed: %v", err)
	}
	if len(plan.Items) == 0 {
		t.Skip("device returned no plan items")
	}

	for _, item := range plan.Items {
		if item.FileCount > 0 && item.TotalBytes <= 0 {
			t.Errorf("category %s reported %d files but %d bytes", item.Category, item.FileCount, item.TotalBytes)
		}
	}
	if plan.TotalFiles > 0 && plan.TotalBytes <= 0 {
		t.Fatalf("plan reported %d files but %d total bytes", plan.TotalFiles, plan.TotalBytes)
	}
}

func TestRemoteFileSizeIntegration(t *testing.T) {
	connectedApp(t)
	size, err := remoteFileSize("/sdcard")
	if err != nil {
		t.Skipf("stat unavailable: %v", err)
	}
	if size < 0 {
		t.Fatalf("unexpected size %d", size)
	}
}

/* ---------------- onboarding + icon pipeline ---------------- */

func TestDeviceStage(t *testing.T) {
	cases := []struct {
		name  string
		state DeviceState
		want  string
	}{
		{"adb missing", DeviceState{AdbInstalled: false}, StageNoADB},
		{"nothing", DeviceState{AdbInstalled: true}, StageNoUSB},
		{"usb only", DeviceState{AdbInstalled: true, AndroidUSB: true}, StageUSBOnly},
		{"unauthorized", DeviceState{AdbInstalled: true, ADBStatus: "unauthorized"}, StageUnauthorized},
		{"offline", DeviceState{AdbInstalled: true, ADBStatus: "offline"}, StageOffline},
		{"ready", DeviceState{AdbInstalled: true, ADBStatus: "device"}, StageReady},
	}
	for _, testCase := range cases {
		if got := deviceStage(&testCase.state); got != testCase.want {
			t.Errorf("%s: deviceStage = %s, want %s", testCase.name, got, testCase.want)
		}
	}

	// A device that is authorized must win over one still on the prompt.
	state := &DeviceState{AdbInstalled: true}
	applyADBDevices(state, []Device{
		{ID: "waiting", Status: "unauthorized"},
		{ID: "ready", Status: "device"},
	})
	if state.ADBDeviceID != "ready" || !(deviceStage(state) == StageReady) {
		t.Fatalf("authorized device should win: %+v", state)
	}
}

func TestPercentBetween(t *testing.T) {
	if got := percentBetween(35, 95, 0, 10); got != 35 {
		t.Fatalf("unexpected start percent %d", got)
	}
	if got := percentBetween(35, 95, 10, 10); got != 95 {
		t.Fatalf("unexpected end percent %d", got)
	}
	if got := percentBetween(0, 100, 5, 10); got != 50 {
		t.Fatalf("unexpected mid percent %d", got)
	}
	if got := percentBetween(0, 100, 1, 0); got != 100 {
		t.Fatalf("empty batch should report completion, got %d", got)
	}
}

func TestFindAndroidUSBDevicePrefersADBCapable(t *testing.T) {
	devices := []USBDevice{
		{VendorID: "1d6b", ProductID: "0002"}, // root hub
		{VendorID: "2717", ProductID: "ff40", VendorName: "Xiaomi", Android: true, MTP: true},
		{VendorID: "18d1", ProductID: "4ee7", VendorName: "Google", Android: true, ADB: true, MTP: true},
	}
	best, ok := findAndroidUSBDevice(devices)
	if !ok {
		t.Fatalf("expected an android device")
	}
	if best.ProductID != "4ee7" {
		t.Fatalf("adb-capable device should win, got %+v", best)
	}

	if _, ok := findAndroidUSBDevice([]USBDevice{{VendorID: "1d6b", ProductID: "0002"}}); ok {
		t.Fatalf("root hubs are not android devices")
	}
}

func TestSystemAppIconIsUsableDataURL(t *testing.T) {
	url := systemAppIconDataURL()
	if !strings.HasPrefix(url, "data:image/svg+xml;base64,") {
		t.Fatalf("unexpected system icon URL: %.40s", url)
	}
	if decoded, err := base64.StdEncoding.DecodeString(strings.TrimPrefix(url, "data:image/svg+xml;base64,")); err != nil {
		t.Fatalf("system icon is not valid base64: %v", err)
	} else if !strings.Contains(string(decoded), "<svg") {
		t.Fatalf("system icon is not an svg")
	}
}

func TestIconImagePathExtensions(t *testing.T) {
	cases := map[string]string{
		"image/jpeg": ".jpg",
		"image/webp": ".webp",
		"image/png":  ".png",
		"image/gif":  ".gif",
		"image/bmp":  ".bmp",
		"image/heic": ".heic",
		"image/heif": ".heif",
	}
	for mime, want := range cases {
		if got := filepath.Ext(iconImagePath("com.example", mime)); got != want {
			t.Fatalf("mime %s -> %q, want %q", mime, got, want)
		}
	}
	// Package names are flattened so they can be used as a file name.
	if strings.Contains(filepath.Base(iconImagePath("com.example/a:b", "image/png")), "/") {
		t.Fatalf("package name was not sanitized")
	}
}

// System apps must resolve to the generic Android icon without touching the
// device, and APK-mode extraction must never be attempted for them.
func TestExtractOneIconUsesGenericForSystemApps(t *testing.T) {
	system := AppInfo{PackageName: "com.android.settings", Path: "/system/priv-app/Settings/base.apk", IsSystem: true}
	result := extractOneIcon(system, "apk", t.TempDir(), false, true)
	if result.Source != "system" {
		t.Fatalf("system app should use the generic icon, got source %q", result.Source)
	}
	if !strings.HasPrefix(result.DataURL, "data:image/svg+xml;base64,") {
		t.Fatalf("unexpected system icon %q", result.DataURL)
	}
}

func TestSessionCacheRoundTrip(t *testing.T) {
	t.Setenv("XDG_CACHE_HOME", t.TempDir())

	app := NewApp()
	session := &DeviceSession{
		Serial: "test-serial",
		Model:  "unit-test",
		Apps:   []AppInfo{{PackageName: "com.example.app", Name: "Example", IsThirdParty: true}},
		Icons:  []SessionIcon{{PackageName: "com.example.app", DataURL: "data:image/png;base64,AAAA", Source: "fast"}},
	}
	if err := app.saveSession(session); err != nil {
		t.Fatalf("saveSession failed: %v", err)
	}

	loaded, ok := app.loadCachedSession("test-serial", "unit-test")
	if !ok {
		t.Fatalf("expected a cached session")
	}
	if loaded.Version != sessionVersion || loaded.Model != "unit-test" || len(loaded.Apps) != 1 || len(loaded.Icons) != 1 {
		t.Fatalf("unexpected round-trip result: %+v", loaded)
	}

	// A device we never wrote must not resolve to somebody else's cache.
	if _, ok := app.loadCachedSession("other-serial", "another-model"); ok {
		t.Fatalf("unexpected cache hit for another device")
	}
}

// The cache is keyed by the device model, so a phone that was plugged in before
// is recognised even when its ADB serial changes (USB <-> Wi-Fi debugging).
func TestSessionCacheIdentifiesDeviceByModel(t *testing.T) {
	t.Setenv("XDG_CACHE_HOME", t.TempDir())

	app := NewApp()
	session := &DeviceSession{
		Serial: "usb-serial-1",
		Model:  "Pixel8",
		Apps:   []AppInfo{{PackageName: "com.example.app"}},
	}
	if err := app.saveSession(session); err != nil {
		t.Fatalf("saveSession failed: %v", err)
	}

	// Same model, new serial: the cache must still be found.
	if _, ok := app.loadCachedSession("192.168.1.7:5555", "Pixel8"); !ok {
		t.Fatalf("expected the model-keyed cache to be found after a serial change")
	}
	// Same serial, model unknown: found through the serial fallback.
	if _, ok := app.loadCachedSession("usb-serial-1", ""); !ok {
		t.Fatalf("expected the cache to be found by serial")
	}
	// A different phone must never resolve to it.
	if _, ok := app.loadCachedSession("other-serial", "GalaxyS24"); ok {
		t.Fatalf("unexpected cache hit for a different device")
	}
}

func TestSaveSessionRejectsEmptySerial(t *testing.T) {
	t.Setenv("XDG_CACHE_HOME", t.TempDir())
	if err := NewApp().saveSession(&DeviceSession{}); err == nil {
		t.Fatalf("expected an error for a session without a serial")
	}
}

// A missing backup folder must explain itself instead of handing the UI a
// blank plan, and Items must never serialize as null.
func TestPreviewRestorePlanExplainsMissingFolder(t *testing.T) {
	plan, err := NewApp().PreviewRestorePlan(filepath.Join(t.TempDir(), "does-not-exist"))
	if err != nil {
		t.Fatalf("PreviewRestorePlan failed: %v", err)
	}
	if plan.Error == "" {
		t.Fatalf("expected an explanatory error for a missing folder")
	}
	if plan.Items == nil {
		t.Fatalf("items must be an empty slice, not nil, so the UI never renders null")
	}
	if len(plan.Items) != 0 || plan.TotalFiles != 0 {
		t.Fatalf("expected an empty plan, got %d items / %d files", len(plan.Items), plan.TotalFiles)
	}
}

// writeBackupFile creates a file (and its parents) inside a backup folder.
func writeBackupFile(t *testing.T, folder, rel, body string) {
	t.Helper()
	path := filepath.Join(folder, rel)
	if err := os.MkdirAll(filepath.Dir(path), 0o755); err != nil {
		t.Fatalf("mkdir %s: %v", rel, err)
	}
	if err := os.WriteFile(path, []byte(body), 0o644); err != nil {
		t.Fatalf("write %s: %v", rel, err)
	}
}

// The restore plan used to be built from manifest.json alone. Because every
// backup run overwrites that manifest with just its own categories, a folder
// that held nine backed-up folders offered only the two categories of the last
// run. Everything in the folder must be restorable, in the same request that
// gets pushed back to the phone.
func TestRestoreListsFoldersMissingFromManifest(t *testing.T) {
	folder := t.TempDir()
	writeBackupFile(t, folder, filepath.Join("Photos", "camera.jpg"), "photo")
	writeBackupFile(t, folder, filepath.Join("Pictures", "shot.png"), "shot")
	writeBackupFile(t, folder, filepath.Join("Downloads", "archive.zip"), "zip")
	writeBackupFile(t, folder, filepath.Join("Custom", "snaptube", "clip.mp4"), "video")
	writeBackupFile(t, folder, filepath.Join("Apps", "com.example", "base.apk"), "apk")

	// The manifest of the last run only knows about Photos.
	manifest := BackupManifest{
		CreatedAt:  time.Now().Format(time.RFC3339),
		Categories: []string{"Photos"},
		Files: []ManifestFile{{
			Category:   "Photos",
			RemotePath: "/sdcard/DCIM/camera.jpg",
			LocalPath:  filepath.Join("Photos", "camera.jpg"),
			Size:       5,
		}},
	}
	data, err := json.Marshal(manifest)
	if err != nil {
		t.Fatalf("marshal manifest: %v", err)
	}
	if err := os.WriteFile(filepath.Join(folder, manifestName), data, 0o644); err != nil {
		t.Fatalf("write manifest: %v", err)
	}

	plan, err := NewApp().PreviewRestorePlan(folder)
	if err != nil {
		t.Fatalf("PreviewRestorePlan failed: %v", err)
	}
	if !plan.HasManifest {
		t.Fatalf("expected the plan to report the manifest it used")
	}

	items := map[string]RestorePlanItem{}
	for _, item := range plan.Items {
		items[item.Category] = item
	}
	for _, category := range []string{"Photos", "Pictures", "Downloads", "/sdcard/snaptube"} {
		if _, ok := items[category]; !ok {
			t.Errorf("restore plan is missing %q: %+v", category, plan.Items)
		}
	}
	if _, ok := items["Apps"]; ok {
		t.Errorf("app backups are reinstalled, not pushed as files: %+v", items["Apps"])
	}
	if plan.TotalFiles != 4 || len(plan.Items) != 4 {
		t.Fatalf("expected 4 files in 4 categories, got %d files in %d categories", plan.TotalFiles, len(plan.Items))
	}

	// The push list must match the plan: every listed file has a device path.
	remotes := map[string]string{}
	for _, job := range buildRestoreJobs(folder) {
		remotes[job.localPath] = job.remotePath
	}
	if got := remotes[filepath.Join(folder, "Photos", "camera.jpg")]; got != "/sdcard/DCIM/camera.jpg" {
		t.Errorf("manifest path for Photos not kept: %q", got)
	}
	if got := remotes[filepath.Join(folder, "Downloads", "archive.zip")]; got != "/sdcard/Download/archive.zip" {
		t.Errorf("unexpected Downloads path: %q", got)
	}
	if got := remotes[filepath.Join(folder, "Custom", "snaptube", "clip.mp4")]; got != "/sdcard/snaptube/clip.mp4" {
		t.Errorf("unexpected custom folder path: %q", got)
	}
}

// A backup run must not erase the manifest entries of earlier runs: those files
// are still in the folder, but their device paths only survive if the manifest
// is merged. Entries whose file disappeared are dropped.
func TestMergeManifestFilesKeepsEarlierBackups(t *testing.T) {
	folder := t.TempDir()
	kept := filepath.Join("Downloads", "a.zip")
	writeBackupFile(t, folder, kept, "a")
	gone := filepath.Join("Music", "b.mp3")

	previous := &BackupManifest{Files: []ManifestFile{
		{Category: "Downloads", RemotePath: "/sdcard/Download/a.zip", LocalPath: kept, Size: 1},
		{Category: "Music", RemotePath: "/sdcard/Music/b.mp3", LocalPath: gone, Size: 2},
	}}
	jobs := []backupJob{{
		category:   "Photos",
		remotePath: "/sdcard/DCIM/c.jpg",
		localPath:  filepath.Join("Photos", "c.jpg"),
		size:       3,
	}}

	files := mergeManifestFiles(folder, previous, jobs)
	if len(files) != 2 {
		t.Fatalf("expected this run's file plus the surviving earlier one, got %+v", files)
	}
	if files[0].Category != "Photos" || files[1].Category != "Downloads" {
		t.Fatalf("unexpected merge result: %+v", files)
	}
	for _, file := range files {
		if file.LocalPath == gone {
			t.Fatalf("a manifest entry whose file is gone must be dropped: %+v", file)
		}
	}

	categories := manifestCategories(files)
	if len(categories) != 2 || categories[0] != "Photos" || categories[1] != "Downloads" {
		t.Fatalf("unexpected manifest categories: %v", categories)
	}
}

// `pm list packages <pkg>` also matches substrings, so the confirmation step
// after an uninstall must compare exact package names.
func TestContainsPackage(t *testing.T) {
	installed := []string{"com.example.app", "com.example.app.pro"}
	if !containsPackage(installed, "com.example.app") {
		t.Fatalf("exact package should be found")
	}
	if containsPackage(installed, "com.example") {
		t.Fatalf("a prefix must not count as installed")
	}
	if containsPackage(nil, "com.example.app") {
		t.Fatalf("an empty list has no packages")
	}
}

// Every adb call is bounded: quick queries, device enumeration, file transfers
// and deep walks each get a deadline instead of hanging forever.
func TestADBTimeoutClassification(t *testing.T) {
	cases := []struct {
		args []string
		want time.Duration
	}{
		{[]string{"devices", "-l"}, adbDeviceTimeout},
		{[]string{"pull", "/sdcard/a", "b"}, adbTransferTimeout},
		{[]string{"push", "a", "/sdcard/b"}, adbTransferTimeout},
		{[]string{"install-multiple", "-r", "x.apk"}, adbTransferTimeout},
		{[]string{"shell", "find", "/sdcard", "-type", "f"}, adbWalkTimeout},
		{[]string{"shell", "pm", "list", "packages"}, adbQuickTimeout},
		{[]string{"exec-out", "unzip", "-p", "base.apk", "AndroidManifest.xml"}, adbQuickTimeout},
	}
	for _, tc := range cases {
		if got := adbTimeoutFor(tc.args); got != tc.want {
			t.Errorf("adbTimeoutFor(%q) = %s, want %s", tc.args, got, tc.want)
		}
	}
}

// A session icon is only reused when it is trustworthy: real extractions and
// conclusive system-app decisions yes, a generic fallback from a failed run no
// (it must be retried), unless the icon cache recorded the same verdict.
func TestReusableSessionIcon(t *testing.T) {
	t.Setenv("XDG_CACHE_HOME", t.TempDir())

	if !reusableSessionIcon(SessionIcon{PackageName: "com.a", DataURL: "data:image/png;base64,AAAA", Source: "fast"}) {
		t.Fatalf("an extracted icon must be reusable")
	}
	if !reusableSessionIcon(SessionIcon{PackageName: "com.sys", DataURL: "data:image/svg+xml;base64,AAAA", Source: "system"}) {
		t.Fatalf("a system app's generic icon must be reusable")
	}
	if reusableSessionIcon(SessionIcon{PackageName: "", DataURL: ""}) {
		t.Fatalf("an empty icon must never be reused")
	}
	if reusableSessionIcon(SessionIcon{PackageName: "com.b", DataURL: "data:image/svg+xml;base64,AAAA", Source: "generic"}) {
		t.Fatalf("a generic fallback from a failed run must be retried")
	}
	if _, err := writeIconCache("com.b", nil); err != nil {
		t.Fatalf("writeIconCache failed: %v", err)
	}
	if !reusableSessionIcon(SessionIcon{PackageName: "com.b", DataURL: "data:image/svg+xml;base64,AAAA", Source: "generic"}) {
		t.Fatalf("a recorded 'no icon' verdict must be reusable")
	}
}

// userAppsWithPaths returns installed third-party apps that expose an APK path.
func userAppsWithPaths(app *App, t *testing.T, limit int) []AppInfo {
	t.Helper()
	apps, err := app.GetInstalledApps()
	if err != nil {
		t.Fatalf("GetInstalledApps failed: %v", err)
	}
	result := make([]AppInfo, 0, limit)
	for _, info := range apps {
		if info.IsThirdParty && info.Path != "" {
			result = append(result, info)
			if len(result) >= limit {
				break
			}
		}
	}
	return result
}

func TestPrepareSessionIntegration(t *testing.T) {
	app := connectedApp(t)

	session, err := app.PrepareSession(PrepareRequest{
		IncludeApps:   true,
		IncludeFiles:  true,
		IconMode:      "fast",
		Workers:       6,
		GenericSystem: true,
	})
	if err != nil {
		t.Fatalf("PrepareSession failed: %v", err)
	}
	if session.Serial == "" {
		t.Fatalf("session has no device serial")
	}
	if len(session.Apps) == 0 {
		t.Skip("device reported no installed apps")
	}
	if len(session.FileRoots) == 0 {
		t.Fatalf("session did not warm any file-browser listings")
	}
	if len(session.Icons) != len(session.Apps) {
		t.Fatalf("expected one icon result per app: %d icons for %d apps", len(session.Icons), len(session.Apps))
	}

	// The UI must never render an empty slot: every app resolves to a data URL.
	// System (and unreadable) apps fall back to the generic Android icon.
	rasterIcons, genericIcons := 0, 0
	for _, icon := range session.Icons {
		if !strings.HasPrefix(icon.DataURL, "data:image/") {
			t.Errorf("app %s has no usable icon (source %q): %.32s", icon.PackageName, icon.Source, icon.DataURL)
			continue
		}
		switch icon.Source {
		case "system":
			if !strings.HasPrefix(icon.DataURL, "data:image/svg+xml;base64,") {
				t.Errorf("system app %s should use the generic icon", icon.PackageName)
			}
			genericIcons++
		case "generic":
			genericIcons++
		default:
			if strings.HasPrefix(icon.DataURL, "data:image/svg+xml") {
				t.Errorf("extracted icon for %s should be a raster image, not an svg", icon.PackageName)
			}
			rasterIcons++
		}
	}
	thirdPartyCount := 0
	for _, app := range session.Apps {
		if app.IsThirdParty {
			thirdPartyCount++
		}
	}
	t.Logf("icons: %d extracted, %d generic, %d total (%d user apps)",
		rasterIcons, genericIcons, len(session.Icons), thirdPartyCount)

	// Icons must be resolved through the manifest/resource table, not guessed from
	// file names: several real APKs rename every drawable, and name matching alone
	// yields nothing for them.
	if thirdPartyCount >= 3 && rasterIcons == 0 {
		t.Fatalf("no user app icon could be extracted although %d user apps are installed", thirdPartyCount)
	}

	// The session must be reusable next launch.
	cached, ok := app.loadCachedSession(session.Serial, session.Model)
	if !ok {
		t.Fatalf("session for %s was not written to the cache", session.Serial)
	}
	if len(cached.Apps) != len(session.Apps) || len(cached.Icons) != len(session.Icons) {
		t.Fatalf("cached session lost data: %d/%d apps, %d/%d icons",
			len(cached.Apps), len(session.Apps), len(cached.Icons), len(session.Icons))
	}

	// The generic icon must exist on disk for the user to see alongside the rest.
	if _, err := os.Stat(filepath.Join(app.GetIconFolder(), "android-default.svg")); err != nil {
		t.Fatalf("generic system icon was not written: %v", err)
	}
}

// TestPullAPKIconIntegration exercises the opt-in "pull APKs for user apps" path
// end to end on a single, small app.
func TestPullAPKIconIntegration(t *testing.T) {
	app := connectedApp(t)

	var chosen AppInfo
	var size int64
	for _, candidate := range userAppsWithPaths(app, t, 12) {
		if apkBytes, err := remoteFileSize(candidate.Path); err == nil && apkBytes > 0 && apkBytes <= 25*1024*1024 {
			chosen, size = candidate, apkBytes
			break
		}
	}
	if chosen.PackageName == "" {
		t.Skip("no small user app available to pull")
	}
	t.Logf("pulling %s (%.1f MB)", chosen.PackageName, float64(size)/(1024*1024))

	apkFolder := t.TempDir()
	results := app.extractIcons([]AppInfo{chosen}, IconExtractRequest{
		Mode:          "apk",
		APKFolder:     apkFolder,
		Workers:       1,
		GenericSystem: true,
	}, 0, 100)
	if len(results) != 1 {
		t.Fatalf("expected one result, got %d", len(results))
	}
	// The APK must actually have been pulled to the folder — that is the feature.
	if results[0].APKPath == "" {
		t.Fatalf("no APK was pulled (error: %s)", results[0].Error)
	}
	if info, err := os.Stat(results[0].APKPath); err != nil || info.Size() == 0 {
		t.Fatalf("pulled APK is missing or empty: %v (%s)", err, results[0].APKPath)
	}
	// Some APKs are resource-obfuscated, so a raster icon is not guaranteed, but
	// the UI must still get something renderable.
	switch results[0].Source {
	case "apk":
		if !strings.HasPrefix(results[0].DataURL, "data:image/") || strings.HasPrefix(results[0].DataURL, "data:image/svg+xml") {
			t.Fatalf("apk source should yield a raster image, got %.32s", results[0].DataURL)
		}
	case "generic":
		t.Logf("%s is resource-obfuscated; fell back to the generic icon", chosen.PackageName)
	default:
		t.Fatalf("unexpected source %q", results[0].Source)
	}
}

// TestIconFromLocalAPK is the deterministic check of the local APK reader: no
// device needed, and it must prefer the highest-density launcher icon.
func TestIconFromLocalAPK(t *testing.T) {
	t.Setenv("XDG_CACHE_HOME", t.TempDir())

	makePNG := func(size int) []byte {
		img := image.NewRGBA(image.Rect(0, 0, size, size))
		for y := 0; y < size; y++ {
			for x := 0; x < size; x++ {
				img.Set(x, y, color.RGBA{R: uint8(x * 7), G: uint8(y * 7), B: 180, A: 255})
			}
		}
		var buf bytes.Buffer
		if err := png.Encode(&buf, img); err != nil {
			t.Fatalf("encode png: %v", err)
		}
		return buf.Bytes()
	}

	writeAPK := func(name string, files map[string][]byte) string {
		path := filepath.Join(t.TempDir(), name)
		file, err := os.Create(path)
		if err != nil {
			t.Fatalf("create apk: %v", err)
		}
		defer file.Close()
		zw := zip.NewWriter(file)
		for entry, data := range files {
			w, err := zw.Create(entry)
			if err != nil {
				t.Fatalf("zip entry: %v", err)
			}
			if _, err := w.Write(data); err != nil {
				t.Fatalf("write entry: %v", err)
			}
		}
		if err := zw.Close(); err != nil {
			t.Fatalf("close zip: %v", err)
		}
		return path
	}

	normal := writeAPK("normal.apk", map[string][]byte{
		"AndroidManifest.xml":                   []byte("binary-manifest"),
		"res/mipmap-mdpi-v4/ic_launcher.png":    makePNG(4),
		"res/mipmap-xxxhdpi-v4/ic_launcher.png": makePNG(16),
		"res/drawable/ic_notification.png":      makePNG(4),
		"res/layout/activity_main.xml":          []byte("<x/>"),
	})
	icon := iconFromLocalAPK(normal)
	if len(icon) == 0 {
		t.Fatalf("expected an icon from a normally-named apk")
	}
	decoded, err := png.Decode(bytes.NewReader(icon))
	if err != nil {
		t.Fatalf("extracted icon is not a png: %v", err)
	}
	if bounds := decoded.Bounds(); bounds.Dx() != 16 || bounds.Dy() != 16 {
		t.Fatalf("expected the xxxhdpi icon, got %dx%d", bounds.Dx(), bounds.Dy())
	}

	// A resource-obfuscated APK (AndResGuard style) has no discoverable name.
	obfuscated := writeAPK("obfuscated.apk", map[string][]byte{
		"AndroidManifest.xml": []byte("binary-manifest"),
		"res/0H.png":          makePNG(16),
		"res/2x1.9.png":       makePNG(4),
	})
	if icon := iconFromLocalAPK(obfuscated); icon != nil {
		t.Fatalf("obfuscated apk should not yield a named icon match")
	}
}

// When nothing can be extracted, the pipeline must still hand the UI the generic
// Android icon instead of an empty slot.
func TestExtractOneIconFallsBackToGeneric(t *testing.T) {
	t.Setenv("XDG_CACHE_HOME", t.TempDir())

	app := AppInfo{PackageName: "com.example.definitely.not.cached.xyz", IsThirdParty: true}
	result := extractOneIcon(app, "fast", "", true, true)
	if result.Source != "generic" {
		t.Fatalf("expected the generic fallback, got %q", result.Source)
	}
	if !strings.HasPrefix(result.DataURL, "data:image/svg+xml;base64,") {
		t.Fatalf("unexpected fallback icon: %.32s", result.DataURL)
	}
}

// The onboarding gate is only as good as the state it reads, so check the real
// probe end to end. It is deliberately tolerant: any machine may have no phone.
func TestCheckDeviceStateIntegration(t *testing.T) {
	deviceState, err := NewApp().CheckDeviceState()
	if err != nil {
		t.Fatalf("CheckDeviceState failed: %v", err)
	}
	t.Logf("stage=%s usb=%d androidUsb=%v adbStatus=%q device=%q",
		deviceState.Stage, deviceState.USBDeviceCount, deviceState.AndroidUSB, deviceState.ADBStatus, deviceState.ADBDeviceID)

	if deviceState.CanProceed != (deviceState.Stage == StageReady) {
		t.Fatalf("canProceed must mirror the ready stage: %+v", deviceState)
	}
	if deviceState.Stage == StageReady && deviceState.ADBStatus != "device" {
		t.Fatalf("ready stage requires an authorized device: %q", deviceState.ADBStatus)
	}
	if deviceState.Stage == StageUSBOnly && !deviceState.AndroidUSB {
		t.Fatalf("usb_only stage requires an android-looking usb device")
	}
	if deviceState.USBDevices == nil {
		t.Fatalf("usbDevices should be a list, not nil")
	}
}

// libusb enumeration must never hard-fail the app: a missing subsystem is
// reported as an error, not a panic.
func TestListUSBDevicesDoesNotPanic(t *testing.T) {
	devices, err := NewApp().ListUSBDevices()
	if err != nil {
		t.Skipf("USB subsystem unavailable: %v", err)
	}
	for _, device := range devices {
		if len(device.VendorID) != 4 || len(device.ProductID) != 4 {
			t.Errorf("vendor/product ids should be 4 hex digits: %+v", device)
		}
	}
	t.Logf("USB devices detected: %d", len(devices))
	for _, device := range devices {
		t.Logf("  %s:%s %s android=%v adb=%v mtp=%v", device.VendorID, device.ProductID, device.VendorName, device.Android, device.ADB, device.MTP)
	}
}
