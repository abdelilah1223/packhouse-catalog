package main

import (
	"encoding/binary"
	"strings"
)

// Android APKs store AndroidManifest.xml and resources.arsc in a binary format.
// Reading them is what lets us find the real launcher icon even when the APK has
// been resource-obfuscated (AndResGuard style) and every drawable is renamed to
// something like "res/0H.png", which no name-based rule can recognise.
//
// The formats are documented in AOSP's ResourceTypes.h.

const (
	chunkXMLType       = 0x0003 // RES_XML_TYPE
	chunkStringPool    = 0x0001 // RES_STRING_POOL_TYPE
	chunkStartElement  = 0x0102 // RES_XML_START_ELEMENT_TYPE
	chunkTableType     = 0x0002 // RES_TABLE_TYPE
	chunkTablePackage  = 0x0200 // RES_TABLE_PACKAGE_TYPE
	chunkTableTypeSpec = 0x0202 // RES_TABLE_TYPE_SPEC_TYPE
	chunkTableTypeType = 0x0201 // RES_TABLE_TYPE_TYPE

	valueTypeReference = 0x01 // Res_value.dataType
	valueTypeString    = 0x03
)

// stringPool is a parsed RES_STRING_POOL chunk.
type stringPool struct {
	strings []string
}

func (p *stringPool) at(index uint32) string {
	if p == nil || int(index) >= len(p.strings) {
		return ""
	}
	return p.strings[index]
}

func (p *stringPool) count() int {
	if p == nil {
		return 0
	}
	return len(p.strings)
}

// parseStringPool parses the RES_STRING_POOL chunk starting at off.
func parseStringPool(data []byte, off int) (*stringPool, bool) {
	if off+28 > len(data) {
		return nil, false
	}
	headerSize := int(binary.LittleEndian.Uint16(data[off+2:]))
	count := int(binary.LittleEndian.Uint32(data[off+8:]))
	flags := binary.LittleEndian.Uint32(data[off+16:])
	stringsStart := int(binary.LittleEndian.Uint32(data[off+20:]))
	if count < 0 || count > 1<<20 || headerSize < 28 {
		return nil, false
	}
	utf8 := flags&0x100 != 0

	pool := &stringPool{strings: make([]string, 0, count)}
	offsetsStart := off + headerSize
	stringBase := off + stringsStart

	for i := 0; i < count; i++ {
		offsetPos := offsetsStart + i*4
		if offsetPos+4 > len(data) {
			break
		}
		start := stringBase + int(binary.LittleEndian.Uint32(data[offsetPos:]))
		pool.strings = append(pool.strings, readPoolString(data, start, utf8))
	}
	return pool, true
}

func readPoolString(data []byte, start int, utf8 bool) string {
	if start < 0 || start >= len(data) {
		return ""
	}
	if utf8 {
		// A UTF-8 pool entry carries two varint lengths: the byte length of the
		// string and then its length in UTF-16 code units. Both must be consumed
		// before the bytes themselves — reading only the first shifts every string
		// by one byte and silently drops its last character.
		byteLength, afterLength, ok := readUTF8Length(data, start)
		if !ok {
			return ""
		}
		_, dataStart, ok := readUTF8Length(data, afterLength)
		if !ok {
			return ""
		}
		end := dataStart + byteLength
		if end > len(data) || end < dataStart {
			end = len(data)
		}
		return string(data[dataStart:end])
	}
	length, dataStart, ok := readUTF16Length(data, start)
	if !ok {
		return ""
	}
	end := dataStart + length*2
	if end > len(data) || end < dataStart {
		end = len(data)
	}
	return decodeUTF16(data[dataStart:end])
}

func readUTF8Length(data []byte, pos int) (length, dataStart int, ok bool) {
	if pos >= len(data) {
		return 0, 0, false
	}
	first := int(data[pos])
	if first&0x80 != 0 {
		if pos+1 >= len(data) {
			return 0, 0, false
		}
		return ((first & 0x7F) << 8) | int(data[pos+1]), pos + 2, true
	}
	return first, pos + 1, true
}

func readUTF16Length(data []byte, pos int) (length, dataStart int, ok bool) {
	if pos+2 > len(data) {
		return 0, 0, false
	}
	value := int(binary.LittleEndian.Uint16(data[pos:]))
	if value&0x8000 != 0 {
		if pos+4 > len(data) {
			return 0, 0, false
		}
		return ((value & 0x7FFF) << 16) | int(binary.LittleEndian.Uint16(data[pos+2:])), pos + 4, true
	}
	return value, pos + 2, true
}

func decodeUTF16(data []byte) string {
	var builder strings.Builder
	for i := 0; i+1 < len(data); i += 2 {
		unit := binary.LittleEndian.Uint16(data[i:])
		if unit >= 0xD800 && unit <= 0xDBFF && i+3 < len(data) {
			low := binary.LittleEndian.Uint16(data[i+2:])
			if low >= 0xDC00 && low <= 0xDFFF {
				builder.WriteRune((rune(unit-0xD800) << 10) | rune(low-0xDC00) + 0x10000)
				i += 2
				continue
			}
		}
		builder.WriteRune(rune(unit))
	}
	return builder.String()
}

// axmlAttribute is one attribute of a start-element tag in a binary document.
type axmlAttribute struct {
	name     string
	dataType byte
	value    uint32
}

// forEachStartElement walks a binary XML document and calls fn for every element
// tag together with its attributes. The string pool is passed along so callers
// can resolve string-typed attribute values (attr.value is a pool index then).
func forEachStartElement(doc []byte, fn func(element string, attrs []axmlAttribute, pool *stringPool)) {
	if len(doc) < 8 || doc[0] == '<' || binary.LittleEndian.Uint16(doc) != chunkXMLType {
		return
	}
	headerSize := int(binary.LittleEndian.Uint16(doc[2:]))
	var pool *stringPool

	for pos := headerSize; pos+8 <= len(doc); {
		chunkType := binary.LittleEndian.Uint16(doc[pos:])
		chunkSize := int(binary.LittleEndian.Uint32(doc[pos+4:]))
		if chunkSize <= 0 {
			break
		}
		switch chunkType {
		case chunkStringPool:
			if pool == nil {
				if parsed, ok := parseStringPool(doc, pos); ok {
					pool = parsed
				}
			}
		case chunkStartElement:
			if pool != nil {
				element, attrs := parseStartElement(doc, pos, pool)
				fn(element, attrs, pool)
			}
		}
		pos += chunkSize
	}
}

// parseStartElement reads one RES_XML_START_ELEMENT chunk.
func parseStartElement(data []byte, off int, pool *stringPool) (string, []axmlAttribute) {
	if off+36 > len(data) {
		return "", nil
	}
	nameIndex := binary.LittleEndian.Uint32(data[off+20:])
	attrStart := int(binary.LittleEndian.Uint16(data[off+24:]))
	attrSize := int(binary.LittleEndian.Uint16(data[off+26:]))
	attrCount := int(binary.LittleEndian.Uint16(data[off+28:]))
	if attrSize < 20 || attrCount < 0 || attrCount > 1<<14 {
		return pool.at(nameIndex), nil
	}

	// attributeStart is relative to the start of the ResXMLTree_attrExt struct,
	// which follows the 16-byte ResXMLTree_node (8-byte chunk header plus
	// lineNumber and comment).
	attrBase := off + 16 + attrStart
	attrs := make([]axmlAttribute, 0, attrCount)
	for i := 0; i < attrCount; i++ {
		base := attrBase + i*attrSize
		if base+20 > len(data) {
			break
		}
		name := pool.at(binary.LittleEndian.Uint32(data[base+4:]))
		if name == "" {
			name = pool.at(binary.LittleEndian.Uint32(data[base+8:]))
		}
		attrs = append(attrs, axmlAttribute{
			name:     name,
			dataType: data[base+15],
			value:    binary.LittleEndian.Uint32(data[base+16:]),
		})
	}
	return pool.at(nameIndex), attrs
}

// xmlResourceLayerReferences returns the resource IDs referenced by a binary
// document, with the ones belonging to a foreground/monochrome layer first. For
// an adaptive icon that ordering is what matters: the foreground is the part that
// actually looks like the app, while the background is usually a flat colour.
func xmlResourceLayerReferences(doc []byte) []uint32 {
	foreground := make([]uint32, 0, 4)
	other := make([]uint32, 0, 8)
	forEachStartElement(doc, func(element string, attrs []axmlAttribute, _ *stringPool) {
		target := &other
		if element == "foreground" || element == "monochrome" {
			target = &foreground
		}
		for _, attr := range attrs {
			if attr.dataType == valueTypeReference && attr.value != 0 {
				*target = append(*target, attr.value)
			}
		}
	})
	return append(foreground, other...)
}

// manifestIconResource returns the resource ID referenced by android:icon in a
// binary AndroidManifest.xml. The <application> element's icon is preferred, but
// any android:icon reference is accepted as a fallback.
func manifestIconResource(manifest []byte) (uint32, bool) {
	// Some APKs ship the manifest uncompressed as plain text; and the pull-based
	// fallback may hand us something unexpected.
	if len(manifest) > 0 && manifest[0] == '<' {
		return plainTextManifestIcon(manifest)
	}

	var fallback uint32
	hasFallback := false
	forEachStartElement(manifest, func(element string, attrs []axmlAttribute, _ *stringPool) {
		for _, attr := range attrs {
			if attr.name != "icon" || attr.dataType != valueTypeReference || attr.value == 0 {
				continue
			}
			if element == "application" {
				fallback, hasFallback = attr.value, true
				return
			}
			if !hasFallback {
				fallback, hasFallback = attr.value, true
			}
		}
	})
	// forEachStartElement has no early exit, so prefer the application icon when
	// one was seen by re-scanning for it explicitly.
	var applicationIcon uint32
	forEachStartElement(manifest, func(element string, attrs []axmlAttribute, _ *stringPool) {
		if element != "application" || applicationIcon != 0 {
			return
		}
		for _, attr := range attrs {
			if attr.name == "icon" && attr.dataType == valueTypeReference && attr.value != 0 {
				applicationIcon = attr.value
				return
			}
		}
	})
	if applicationIcon != 0 {
		return applicationIcon, true
	}
	return fallback, hasFallback
}

// manifestLabel reads android:label from the <application> element of a binary
// AndroidManifest.xml — the name the user actually sees on the phone. The label
// is either a literal string or a reference into resources.arsc; both forms are
// returned so the caller can resolve the reference when needed.
func manifestLabel(manifest []byte) (literal string, resID uint32, ok bool) {
	if len(manifest) > 0 && manifest[0] == '<' {
		return plainTextManifestLabel(manifest)
	}

	var appLiteral string
	var appRef uint32
	seen := false
	forEachStartElement(manifest, func(element string, attrs []axmlAttribute, pool *stringPool) {
		if element != "application" || seen {
			return
		}
		for _, attr := range attrs {
			if attr.name != "label" {
				continue
			}
			seen = true
			switch attr.dataType {
			case valueTypeString:
				if pool != nil {
					appLiteral = pool.at(attr.value)
				}
			case valueTypeReference:
				if attr.value != 0 {
					appRef = attr.value
				}
			}
			return
		}
	})
	if seen && (appLiteral != "" || appRef != 0) {
		return appLiteral, appRef, true
	}
	return "", 0, false
}

// plainTextManifestLabel handles an uncompressed manifest: android:label is
// either a literal string or "@0x……" resource reference.
func plainTextManifestLabel(manifest []byte) (string, uint32, bool) {
	text := string(manifest)
	const marker = "android:label=\""
	index := strings.Index(text, marker)
	if index < 0 {
		return "", 0, false
	}
	value := text[index+len(marker):]
	if end := strings.IndexByte(value, '"'); end >= 0 {
		value = value[:end]
	}
	value = strings.TrimSpace(value)
	if value == "" {
		return "", 0, false
	}
	if strings.HasPrefix(value, "@0x") || strings.HasPrefix(value, "@0X") {
		if parsed, ok := parseHexResourceRef(value); ok {
			return "", parsed, true
		}
		return "", 0, false
	}
	if strings.HasPrefix(value, "@") {
		// @string/… cannot be resolved by name without the table; skip.
		return "", 0, false
	}
	return value, 0, true
}

// parseHexResourceRef parses "@0x7f0e0001" into the resource ID.
func parseHexResourceRef(value string) (uint32, bool) {
	var parsed uint64
	for _, char := range value[3:] {
		digit := hexDigit(char)
		if digit < 0 {
			return 0, false
		}
		parsed = parsed<<4 | uint64(digit)
		if parsed > 0xFFFFFFFF {
			return 0, false
		}
	}
	if parsed == 0 {
		return 0, false
	}
	return uint32(parsed), true
}

// plainTextManifestIcon handles an uncompressed manifest where android:icon may
// reference either a resource id ("@0x7f0e0001") or a named resource.
func plainTextManifestIcon(manifest []byte) (uint32, bool) {
	text := string(manifest)
	const marker = "android:icon=\""
	for start := 0; ; {
		index := strings.Index(text[start:], marker)
		if index < 0 {
			return 0, false
		}
		index += start
		value := text[index+len(marker):]
		if end := strings.IndexByte(value, '"'); end >= 0 {
			value = value[:end]
		}
		if strings.HasPrefix(value, "@0x") || strings.HasPrefix(value, "@0X") {
			var parsed uint64
			for _, char := range value[3:] {
				digit := hexDigit(char)
				if digit < 0 {
					parsed = 0
					break
				}
				parsed = parsed<<4 | uint64(digit)
			}
			if parsed != 0 && parsed <= 0xFFFFFFFF {
				return uint32(parsed), true
			}
		}
		start = index + len(marker)
	}
}

func hexDigit(char rune) int {
	switch {
	case char >= '0' && char <= '9':
		return int(char - '0')
	case char >= 'a' && char <= 'f':
		return int(char-'a') + 10
	case char >= 'A' && char <= 'F':
		return int(char-'A') + 10
	}
	return -1
}
