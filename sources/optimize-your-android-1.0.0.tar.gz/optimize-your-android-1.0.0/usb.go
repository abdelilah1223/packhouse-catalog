package main

import (
	"fmt"
	"sort"
	"sync"

	"github.com/google/gousb"
)

// USBDevice is one USB device attached to the host. It is discovered with libusb
// (github.com/google/gousb) instead of ADB, which is what lets us notice a phone
// that is physically plugged in but still has USB debugging turned off — a case
// where `adb devices` reports nothing at all.
type USBDevice struct {
	Bus        int    `json:"bus"`
	Address    int    `json:"address"`
	VendorID   string `json:"vendorId"`
	ProductID  string `json:"productId"`
	VendorName string `json:"vendorName"`
	Class      int    `json:"class"`
	MTP        bool   `json:"mtp"`
	ADB        bool   `json:"adbInterface"`
	Android    bool   `json:"android"`
}

// USB interface descriptors that identify an Android device.
const (
	usbClassStillImage     = 0x06 // MTP / PTP
	usbClassVendorSpecific = 0xff

	adbSubClass = 0x42 // ADB interface subclass
	adbProtocol = 0x01 // ADB interface protocol
)

// androidVendorNames maps USB vendor IDs to a display name. It is intentionally
// broad (it includes chipset and peripheral vendors) and is only used for labels.
var androidVendorNames = map[uint16]string{
	0x18d1: "Google",
	0x2717: "Xiaomi",
	0x2719: "Xiaomi",
	0x2b4c: "Xiaomi",
	0x04e8: "Samsung",
	0x22b8: "Motorola",
	0x0bb4: "HTC",
	0x12d1: "Huawei",
	0x1004: "LG",
	0x0fce: "Sony",
	0x1949: "Amazon",
	0x2931: "Amazon",
	0x0b05: "Asus",
	0x2a70: "OnePlus",
	0x2a47: "OnePlus",
	0x2916: "OnePlus",
	0x22d9: "Oppo",
	0x2d95: "Vivo",
	0x05c6: "Qualcomm",
	0x1782: "Spreadtrum",
	0x2207: "Rockchip",
	0x0e8d: "MediaTek",
	0x17ef: "Lenovo",
	0x19d2: "ZTE",
	0x1bbb: "Alcatel",
	0x0502: "Acer",
	0x0489: "Foxconn",
	0x0e79: "Archos",
	0x1ebf: "Wiko",
	0x2e04: "HMD / Nokia",
	0x1f3a: "Allwinner",
	0x0955: "NVIDIA",
}

// phoneVendorIDs are vendors whose USB products are effectively always phones or
// tablets. Unlike the name table this is deliberately narrow: a phone sitting in
// "charging only" mode exposes no recognisable interface class at all, so the
// vendor ID is the only signal left — and a false positive (claiming a mouse is a
// phone) is worse than asking the user to plug the cable back in.
var phoneVendorIDs = map[uint16]bool{
	0x18d1: true, // Google
	0x2717: true, // Xiaomi
	0x2719: true, // Xiaomi
	0x2b4c: true, // Xiaomi
	0x04e8: true, // Samsung
	0x22b8: true, // Motorola
	0x0bb4: true, // HTC
	0x12d1: true, // Huawei
	0x1004: true, // LG
	0x0fce: true, // Sony
	0x1949: true, // Amazon
	0x2931: true, // Amazon
	0x2a70: true, // OnePlus
	0x2a47: true, // OnePlus
	0x2916: true, // OnePlus
	0x22d9: true, // Oppo / Realme
	0x2d95: true, // Vivo
	0x19d2: true, // ZTE
	0x2e04: true, // HMD / Nokia
	0x1bbb: true, // Alcatel
	0x1ebf: true, // Wiko
}

// describeUSBDevice turns a libusb descriptor into our JSON-friendly shape. Only
// descriptor data is used — nothing is opened, so no permissions are required.
func describeUSBDevice(desc *gousb.DeviceDesc) USBDevice {
	device := USBDevice{
		Bus:       desc.Bus,
		Address:   desc.Address,
		VendorID:  fmt.Sprintf("%04x", uint16(desc.Vendor)),
		ProductID: fmt.Sprintf("%04x", uint16(desc.Product)),
		Class:     int(desc.Class),
	}
	if name, ok := androidVendorNames[uint16(desc.Vendor)]; ok {
		device.VendorName = name
	}
	if phoneVendorIDs[uint16(desc.Vendor)] {
		device.Android = true
	}

	// Interface descriptors are stronger evidence than the vendor table and work
	// for any vendor: an ADB interface only appears once USB debugging is on, and
	// the MTP/PTP interface is how a phone appears before that.
	for _, config := range desc.Configs {
		for _, intf := range config.Interfaces {
			for _, alt := range intf.AltSettings {
				switch {
				case alt.Class == usbClassVendorSpecific && alt.SubClass == adbSubClass:
					device.ADB = true
					device.Android = true
				case alt.Class == usbClassStillImage:
					device.MTP = true
					device.Android = true
				}
			}
		}
	}
	return device
}

// listUSBDevices enumerates every USB device on the host via libusb.
//
// The callback deliberately returns false for every device: gousb only exposes
// enumeration through OpenDevices, and returning false records the descriptor
// without opening the device. Opening a phone's interfaces needs root and can
// interfere with a concurrent adb/MTP session, and we do not need it here.
func listUSBDevices() (devices []USBDevice, err error) {
	// gousb.Context creation panics (rather than returning an error) when libusb
	// cannot be initialised, e.g. a headless container without udev.
	defer func() {
		if recovered := recover(); recovered != nil {
			devices = nil
			err = fmt.Errorf("USB subsystem unavailable: %v", recovered)
		}
	}()

	ctx := gousb.NewContext()
	defer ctx.Close()

	var mu sync.Mutex
	found := make([]USBDevice, 0, 16)
	// Errors here only mean "some device could not be described"; descriptors we
	// did collect are still useful, so the error is intentionally discarded.
	_, _ = ctx.OpenDevices(func(desc *gousb.DeviceDesc) bool {
		mu.Lock()
		found = append(found, describeUSBDevice(desc))
		mu.Unlock()
		return false
	})

	sort.Slice(found, func(i, j int) bool {
		if found[i].Bus != found[j].Bus {
			return found[i].Bus < found[j].Bus
		}
		return found[i].Address < found[j].Address
	})
	return found, nil
}

// ListUSBDevices returns every USB device currently attached to the host.
func (a *App) ListUSBDevices() ([]USBDevice, error) {
	devices, err := listUSBDevices()
	if err != nil {
		return nil, err
	}
	return devices, nil
}

// findAndroidUSBDevice returns the most phone-like USB device, if any. ADB-capable
// devices win over MTP-only ones, then known Android vendors.
func findAndroidUSBDevice(devices []USBDevice) (USBDevice, bool) {
	best := USBDevice{}
	found := false
	bestScore := -1
	for _, device := range devices {
		if !device.Android {
			continue
		}
		score := 0
		if device.ADB {
			score += 4
		}
		if device.MTP {
			score += 2
		}
		if device.VendorName != "" {
			score += 1
		}
		if score > bestScore {
			bestScore = score
			best = device
			found = true
		}
	}
	return best, found
}
