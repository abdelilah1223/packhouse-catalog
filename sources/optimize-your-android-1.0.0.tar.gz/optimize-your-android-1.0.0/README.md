# Optimize Your Android

Optimize Your Android is a desktop app for managing and recovering Android data through ADB. It connects to a phone, inspects installed apps, explores storage, backs up folders or APKs, restores files, and helps recover residual data that is no longer clearly visible through normal app storage.

The app is built with Go and Wails, with a browser-based UI and a Go backend that communicates with Android devices over ADB.

## Features

- Device detection and onboarding flow for USB debugging
- ADB authorization flow for Android devices
- App listing and app metadata inspection
- Real app icon extraction and caching
- File browser for Android storage
- Backup of selected device folders and custom folders
- App backup as installable APK packages
- Restore of backed-up data to the device
- Install selected APK backups directly onto the phone
- Recovery scanning for residual files and hidden media/data leftovers
- Cached sessions and cached icons for faster repeat loads

## Why it exists

The project aims to make Android data management easier on a desktop:

- inspect what is installed on a device
- back up important folders without manually copying files from the phone
- restore backups later without losing the original structure
- recover leftover files from deleted or residual data locations
- avoid repeated full scans by caching device session data

## Main components

### Backend (Go)

The Go backend handles the low-level work:

- ADB execution and timeout control
- device detection and status checks
- Android file walking and tree scanning
- backup and restore job generation
- app APK backup and reinstall logic
- icon extraction and cache writing
- residual data discovery and file recovery flow

Core files:

- `main.go`
- `app.go`
- `backup.go`
- `session.go`
- `icons.go`
- `iconpipeline.go`
- `adb.go`
- `bulk.go`

### Frontend (JavaScript)

The frontend is a Wails-managed web UI with a single-page app structure. It handles:

- onboarding and device states
- app list rendering
- backup and restore plan screens
- file browsing and previews
- recovery scanning and result actions

Main frontend file:

- `frontend/src/main.js`

## Data and cache behavior

The app keeps local cache directories for performance and repeat access.

- icons are cached locally as reusable extracted images
- sessions are cached per device so a phone can reload faster
- backups are stored under a per-device folder, keyed by device model with serial fallback
- restore source defaults match the same per-device backup folder, so a device restores to the location it originally backed up from

This avoids the common bug where packaged builds use a relative path like `./device-backup`, which breaks because the working directory is not the user’s home folder.

## Backup and restore flow

### Backup

The app lets the user:

- choose standard Android folders such as DCIM, Pictures, Downloads, Documents, etc.
- add custom Android folders
- select apps to back up as APK files
- choose a target backup folder
- review the backup plan before running it

### Restore

The restore flow:

- reads the backup manifest and backup folder structure
- shows available data folders and app backups
- allows the user to select which folders to restore
- can reinstall selected app APK backups automatically
- restores data back to the correct Android paths

## Recovery flow

The app includes a recovery section for residual file discovery. It scans common Android leftovers and stores results for review, preview, restore, or deletion.

This is for recovering data that may remain in:

- caches
- deleted media locations
- vendor or MIUI backup folders
- residual app storage

## Requirements

- Go
- Wails
- Android device with USB debugging enabled
- ADB available in the environment
- libusb support for device detection

### Fedora / Linux note

If building on Fedora, libusb development files may be required.

Example:

```bash
dnf install libusb1-devel
```

## Development

From the project directory:

```bash
wails dev
```

This starts the local frontend and Go app in dev mode.

## Build

To create a packaged app:

```bash
wails build
```

## Verification

The project was verified with:

```bash
go test ./...
```

This passes successfully for the current codebase.

## Notes

This project is designed to be practical for real-device use, but actual backup/restore behavior depends on:

- the device model and Android version
- whether the phone is authorized for ADB
- whether the target folders exist on the device
- whether the user has permission to access the chosen folders

## License

This project currently does not declare a formal license in the repository root. Check the repo contents for any additional licensing notes before redistribution.
