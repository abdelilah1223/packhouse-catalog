package main

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"runtime"
	"strings"
	"sync"
	"time"

	wruntime "github.com/wailsapp/wails/v2/pkg/runtime"
)

// BackupCategory describes a backupable bucket of device data.
type BackupCategory struct {
	ID          string `json:"id"`
	Label       string `json:"label"`
	RemotePath  string `json:"remotePath"`
	Description string `json:"description"`
	Available   bool   `json:"available"`
	Recursive   bool   `json:"recursive"`
}

// BackupPlanItem is one category's contribution to a backup plan.
type BackupPlanItem struct {
	Category   string `json:"category"`
	Label      string `json:"label"`
	RemotePath string `json:"remotePath"`
	FileCount  int    `json:"fileCount"`
	TotalBytes int64  `json:"totalBytes"`
	Available  bool   `json:"available"`
	Error      string `json:"error"`
}

// BackupPlan is the reviewable preview shown before a backup starts.
type BackupPlan struct {
	TargetFolder string           `json:"targetFolder"`
	Items        []BackupPlanItem `json:"items"`
	TotalFiles   int              `json:"totalFiles"`
	TotalBytes   int64            `json:"totalBytes"`
}

// TransferResult summarises a finished backup or restore.
type TransferResult struct {
	Operation    string   `json:"operation"`
	TargetFolder string   `json:"targetFolder"`
	TotalFiles   int      `json:"totalFiles"`
	Copied       int      `json:"copied"`
	Failed       int      `json:"failed"`
	Bytes        int64    `json:"bytes"`
	Errors       []string `json:"errors"`
	ManifestPath string   `json:"manifestPath"`
}

// TransferProgress is streamed to the frontend while data moves.
type TransferProgress struct {
	Operation string `json:"operation"`
	Phase     string `json:"phase"`
	Category  string `json:"category"`
	Current   string `json:"current"`
	Completed int    `json:"completed"`
	Total     int    `json:"total"`
	Bytes     int64  `json:"bytes"`
	Failed    int    `json:"failed"`
	Done      bool   `json:"done"`
	Message   string `json:"message"`
}

// ManifestFile records where a backed-up file came from.
type ManifestFile struct {
	Category   string `json:"category"`
	RemotePath string `json:"remotePath"`
	LocalPath  string `json:"localPath"`
	Size       int64  `json:"size"`
}

// BackupManifest makes a backup self-describing and restorable.
type BackupManifest struct {
	CreatedAt    string         `json:"createdAt"`
	DeviceID     string         `json:"deviceId"`
	DeviceModel  string         `json:"deviceModel"`
	TargetFolder string         `json:"targetFolder"`
	Categories   []string       `json:"categories"`
	Files        []ManifestFile `json:"files"`
}

// defaultBackupFolder is where backups go when the user has not picked a
// folder: one folder per device (keyed by the device model, falling back to
// the serial) under the user's home directory. Backups and restores share the
// same identifier, so a phone's backups are always where the restore screen
// looks for them — the old CWD-relative "./device-backup" default depended on
// wherever the app happened to be launched from.
func (a *App) defaultBackupFolder() string {
	serial, model := a.currentSerial()
	id := strings.TrimSpace(model)
	if id == "" {
		id = strings.TrimSpace(serial)
	}
	if id == "" {
		id = "device"
	}
	home, err := os.UserHomeDir()
	if err != nil || home == "" {
		home = "."
	}
	return filepath.Join(home, "device-backup", sanitizeFileComponent(id))
}

// DefaultBackupFolder exposes the per-device default backup folder so the UI
// can prefill both the backup target and the restore source with it.
func (a *App) DefaultBackupFolder() (string, error) {
	return a.defaultBackupFolder(), nil
}

const (
	manifestName        = "manifest.json"
	maxWalkEntries      = 40000
	transferWorkerRatio = 2
)

func backupCategoryDefs() []BackupCategory {
	return []BackupCategory{
		{ID: "Photos", Label: "Photos (DCIM)", RemotePath: "/sdcard/DCIM", Description: "Camera photos and videos", Available: true, Recursive: true},
		{ID: "Pictures", Label: "Pictures", RemotePath: "/sdcard/Pictures", Description: "Saved images and screenshots", Available: true, Recursive: true},
		{ID: "Videos", Label: "Videos", RemotePath: "/sdcard/Movies", Description: "Downloaded / recorded videos", Available: true, Recursive: true},
		{ID: "Downloads", Label: "Downloads", RemotePath: "/sdcard/Download", Description: "Files from the browser and apps", Available: true, Recursive: true},
		{ID: "Music", Label: "Music", RemotePath: "/sdcard/Music", Description: "Audio tracks", Available: true, Recursive: true},
		{ID: "Documents", Label: "Documents", RemotePath: "/sdcard/Documents", Description: "PDFs, office files and notes", Available: true, Recursive: true},
		{ID: "WhatsApp", Label: "WhatsApp media", RemotePath: "/sdcard/Android/media/com.whatsapp/WhatsApp", Description: "WhatsApp images, video and voice notes", Available: true, Recursive: true},
		{ID: "AppFiles", Label: "App media (Android/data)", RemotePath: "/sdcard/Android/data", Description: "Media stored inside app folders", Available: true, Recursive: true},
		{ID: "DeviceBackups", Label: "Device backup folders", RemotePath: "/sdcard/backups", Description: "Existing on-device backups (MIUI, vendors)", Available: true, Recursive: true},
		{ID: "Messages", Label: "Messages (SMS)", RemotePath: "", Description: "The SMS database lives in protected app storage and needs root. Use the Recovery tab to look for exported MIUI/vendor message backups instead.", Available: false},
		{ID: "Calls", Label: "Call logs", RemotePath: "", Description: "Call log database is protected and needs root. Use the Recovery tab to look for exported call backups instead.", Available: false},
	}
}

func findCategory(id string) (BackupCategory, bool) {
	for _, def := range backupCategoryDefs() {
		if strings.EqualFold(def.ID, id) {
			return def, true
		}
	}
	return BackupCategory{}, false
}

// GetBackupCategories lists the backup buckets. Availability is deliberately NOT
// probed here: a single failed `test -d` used to disable every folder, which made
// the plan look empty ("0 B") even when the folders were full. Real problems are
// reported by PreviewBackupPlan per category instead.
func (a *App) GetBackupCategories() ([]BackupCategory, error) {
	if err := a.requireAnyDevice(); err != nil {
		return nil, err
	}
	defs := backupCategoryDefs()
	for i := range defs {
		defs[i].Available = defs[i].RemotePath != ""
	}
	return defs, nil
}

type backupJob struct {
	category   string
	remotePath string
	localPath  string
	size       int64
}

// fillMissingSizes resolves real byte counts when `ls -la` reported zeros but
// files were found (some Android `ls` builds/dirs report 0 for recursion-cached
// entries). Without this the plan can claim "0 B" for a non-empty folder.
func fillMissingSizes(entries []remoteEntry) int64 {
	var total int64
	for i := range entries {
		total += entries[i].Size
	}
	if total > 0 {
		return total
	}

	sem := make(chan struct{}, 6)
	var wg sync.WaitGroup
	var mu sync.Mutex
	for i := range entries {
		wg.Add(1)
		sem <- struct{}{}
		go func(idx int) {
			defer wg.Done()
			defer func() { <-sem }()
			size, err := remoteFileSize(entries[idx].Path)
			if err != nil {
				return
			}
			mu.Lock()
			entries[idx].Size = size
			total += size
			mu.Unlock()
		}(i)
	}
	wg.Wait()
	return total
}

// emitPlanProgress streams plan-building progress to the UI (operation "plan"
// on the transfer:progress channel). The review screen and the transfer panel
// both display it, so long device walks never look like a frozen app.
func (a *App) emitPlanProgress(category, current, message string) {
	if a == nil || a.ctx == nil {
		return
	}
	wruntime.EventsEmit(a.ctx, "transfer:progress", TransferProgress{
		Operation: "plan",
		Phase:     "planning",
		Category:  category,
		Current:   current,
		Message:   message,
	})
}

// buildBackupJobs walks each selected category (plus any user-picked folders) and
// produces the file list to copy. Progress is streamed so a big tree keeps the
// UI informed while it is scanned.
func (a *App) buildBackupJobs(categories []string, customFolders []string) ([]backupJob, []BackupPlanItem) {
	jobs := make([]backupJob, 0, 256)
	items := make([]BackupPlanItem, 0, len(categories)+len(customFolders))

	appendWalk := func(id, label, remotePath, localPrefix string, recursive bool, rootRequired bool) {
		a.emitPlanProgress(id, remotePath, fmt.Sprintf("Scanning %s…", label))
		item := BackupPlanItem{Category: id, Label: label, RemotePath: remotePath, Available: true}
		if rootRequired || strings.TrimSpace(remotePath) == "" {
			item.Available = false
			item.Error = "Not accessible without root"
			items = append(items, item)
			return
		}

		entries, err := walkRemoteTreeFast(remotePath, recursive, maxWalkEntries)
		if err != nil {
			item.Available = false
			item.Error = err.Error()
			items = append(items, item)
			return
		}
		if len(entries) == 0 {
			item.Error = "Folder is empty or unreadable on this device"
		}

		bytes := fillMissingSizes(entries)
		for _, entry := range entries {
			item.FileCount++
			jobs = append(jobs, backupJob{
				category:   id,
				remotePath: entry.Path,
				localPath:  filepath.Join(localPrefix, relativeRemotePath(remotePath, entry.Path)),
				size:       entry.Size,
			})
		}
		item.TotalBytes = bytes
		items = append(items, item)
		a.emitPlanProgress(id, "", fmt.Sprintf("%s: %d files (%s)", label, item.FileCount, humanBytes(bytes)))
	}

	for _, id := range categories {
		def, ok := findCategory(id)
		if !ok {
			items = append(items, BackupPlanItem{Category: id, Label: id, Available: false, Error: "Unknown category"})
			continue
		}
		appendWalk(def.ID, def.Label, def.RemotePath, def.ID, def.Recursive, !def.Available)
	}

	for _, folder := range customFolders {
		path := normalizeAndroidPath(folder)
		if path == "" || path == "/" {
			continue
		}
		base := remoteBaseName(path)
		appendWalk(path, path, path, filepath.Join("Custom", sanitizeFileComponent(base)), true, false)
	}

	return jobs, items
}

// PreviewBackupPlan reviews what a backup would copy before the user agrees.
func (a *App) PreviewBackupPlan(categories []string, targetFolder string, customFolders []string) (*BackupPlan, error) {
	if err := a.requireAnyDevice(); err != nil {
		return nil, err
	}
	targetFolder = strings.TrimSpace(targetFolder)
	if targetFolder == "" {
		targetFolder = a.defaultBackupFolder()
	}

	_, items := a.buildBackupJobs(categories, customFolders)
	plan := &BackupPlan{TargetFolder: targetFolder, Items: items}
	for _, item := range items {
		plan.TotalFiles += item.FileCount
		plan.TotalBytes += item.TotalBytes
	}
	return plan, nil
}

type progressReporter struct {
	app       *App
	operation string
	total     int
	completed int
	bytes     int64
	failed    int
	lastEmit  time.Time
	mu        sync.Mutex
}

func newProgressReporter(app *App, operation string, total int) *progressReporter {
	return &progressReporter{app: app, operation: operation, total: total}
}

func (p *progressReporter) report(phase, category, current string, done bool, message string) {
	p.mu.Lock()
	p.completed++
	now := time.Now()
	// Throttle the event stream so huge transfers don't flood the UI.
	shouldEmit := done || now.Sub(p.lastEmit) > 60*time.Millisecond
	if shouldEmit {
		p.lastEmit = now
	}
	payload := TransferProgress{
		Operation: p.operation,
		Phase:     phase,
		Category:  category,
		Current:   current,
		Completed: p.completed,
		Total:     p.total,
		Bytes:     p.bytes,
		Failed:    p.failed,
		Done:      done,
		Message:   message,
	}
	p.mu.Unlock()
	if shouldEmit {
		p.app.emitTransferProgress(payload)
	}
}

func (p *progressReporter) addFailed() {
	p.mu.Lock()
	p.failed++
	p.mu.Unlock()
}

func (p *progressReporter) addBytes(n int64) {
	p.mu.Lock()
	p.bytes += n
	p.mu.Unlock()
}

func (p *progressReporter) finish(message string) {
	payload := TransferProgress{
		Operation: p.operation,
		Phase:     "done",
		Completed: p.completed,
		Total:     p.total,
		Bytes:     p.bytes,
		Failed:    p.failed,
		Done:      true,
		Message:   message,
	}
	p.app.emitTransferProgress(payload)
}

func (a *App) emitTransferProgress(payload TransferProgress) {
	if a.ctx == nil {
		return
	}
	wruntime.EventsEmit(a.ctx, "transfer:progress", payload)
}

// RunBackup copies the selected categories (plus any user-picked folders) to the
// host with live progress.
func (a *App) RunBackup(categories []string, targetFolder string, customFolders []string) (*TransferResult, error) {
	if err := a.requireAnyDevice(); err != nil {
		return nil, err
	}
	targetFolder = strings.TrimSpace(targetFolder)
	if targetFolder == "" {
		targetFolder = a.defaultBackupFolder()
	}
	if err := os.MkdirAll(targetFolder, 0o755); err != nil {
		return nil, fmt.Errorf("failed to create backup folder: %v", err)
	}

	jobs, items := a.buildBackupJobs(categories, customFolders)
	result := &TransferResult{Operation: "backup", TargetFolder: targetFolder, TotalFiles: len(jobs)}

	reporter := newProgressReporter(a, "backup", len(jobs))
	reporter.report("planning", "", "", false, fmt.Sprintf("Planned %d files", len(jobs)))

	for _, item := range items {
		if item.Error != "" {
			result.Errors = append(result.Errors, fmt.Sprintf("%s: %s", item.Category, item.Error))
		}
	}

	if len(jobs) == 0 {
		reporter.finish("No files to back up.")
		return result, nil
	}

	workers := runtime.NumCPU() * transferWorkerRatio
	if workers < 2 {
		workers = 2
	}
	jobCh := make(chan backupJob, workers)
	var mu sync.Mutex
	var wg sync.WaitGroup

	for w := 0; w < workers; w++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for job := range jobCh {
				dest := filepath.Join(targetFolder, job.localPath)
				if err := os.MkdirAll(filepath.Dir(dest), 0o755); err != nil {
					reporter.addFailed()
					mu.Lock()
					result.Failed++
					if len(result.Errors) < 40 {
						result.Errors = append(result.Errors, fmt.Sprintf("%s: %v", job.remotePath, err))
					}
					mu.Unlock()
					reporter.report("copying", job.category, job.remotePath, false, "")
					continue
				}
				if _, err := executeADB("pull", job.remotePath, dest); err != nil {
					reporter.addFailed()
					mu.Lock()
					result.Failed++
					if len(result.Errors) < 40 {
						result.Errors = append(result.Errors, fmt.Sprintf("%s: %v", job.remotePath, err))
					}
					mu.Unlock()
					reporter.report("copying", job.category, job.remotePath, false, "")
					continue
				}
				reporter.addBytes(job.size)
				mu.Lock()
				result.Copied++
				result.Bytes += job.size
				mu.Unlock()
				reporter.report("copying", job.category, job.remotePath, false, "")
			}
		}()
	}

	for _, job := range jobs {
		jobCh <- job
	}
	close(jobCh)
	wg.Wait()

	// The manifest is merged with the one already in the folder instead of being
	// replaced: a run only records its own categories, so overwriting it erased
	// the device paths of everything backed up earlier while those files stayed
	// on disk.
	previous, _ := loadManifest(targetFolder)
	manifest := BackupManifest{
		CreatedAt:    time.Now().Format(time.RFC3339),
		TargetFolder: targetFolder,
		Files:        mergeManifestFiles(targetFolder, previous, jobs),
	}
	manifest.Categories = manifestCategories(manifest.Files)
	if serial, model := a.currentSerial(); serial != "" || model != "" {
		manifest.DeviceID = serial
		manifest.DeviceModel = model
	}
	manifestPath := filepath.Join(targetFolder, manifestName)
	if data, err := json.MarshalIndent(manifest, "", "  "); err == nil {
		if err := os.WriteFile(manifestPath, data, 0o644); err == nil {
			result.ManifestPath = manifestPath
		}
	}

	message := fmt.Sprintf("Backed up %d of %d files", result.Copied, result.TotalFiles)
	if result.Failed > 0 {
		message += fmt.Sprintf(" (%d failed)", result.Failed)
	}
	reporter.finish(message)
	return result, nil
}

// mergeManifestFiles keeps this run's files plus the entries of an earlier
// manifest whose files are still in the backup folder, so a later, narrower
// backup does not erase what is already there.
func mergeManifestFiles(targetFolder string, previous *BackupManifest, jobs []backupJob) []ManifestFile {
	files := make([]ManifestFile, 0, len(jobs))
	seen := make(map[string]bool, len(jobs))
	for _, job := range jobs {
		files = append(files, ManifestFile{
			Category:   job.category,
			RemotePath: job.remotePath,
			LocalPath:  job.localPath,
			Size:       job.size,
		})
		seen[filepath.Clean(job.localPath)] = true
	}
	if previous == nil {
		return files
	}
	for _, file := range previous.Files {
		key := filepath.Clean(file.LocalPath)
		if seen[key] {
			continue
		}
		if _, err := os.Stat(filepath.Join(targetFolder, file.LocalPath)); err != nil {
			// The file is gone from the folder, so it must not stay in the
			// manifest either.
			continue
		}
		seen[key] = true
		files = append(files, file)
	}
	return files
}

// manifestCategories lists the distinct categories a manifest covers, in file
// order, so the header of the file matches its contents.
func manifestCategories(files []ManifestFile) []string {
	out := make([]string, 0, 8)
	seen := map[string]bool{}
	for _, file := range files {
		if file.Category == "" || seen[file.Category] {
			continue
		}
		seen[file.Category] = true
		out = append(out, file.Category)
	}
	return out
}

// RestorePlanItem is one category's contribution to a restore plan.
type RestorePlanItem struct {
	Category   string `json:"category"`
	Label      string `json:"label"`
	FileCount  int    `json:"fileCount"`
	TotalBytes int64  `json:"totalBytes"`
	Available  bool   `json:"available"`
	Error      string `json:"error"`
}

// RestorePlan is the reviewable preview shown before a restore starts.
type RestorePlan struct {
	LocalFolder string            `json:"localFolder"`
	Items       []RestorePlanItem `json:"items"`
	TotalFiles  int               `json:"totalFiles"`
	TotalBytes  int64             `json:"totalBytes"`
	HasManifest bool              `json:"hasManifest"`
	// Error explains an empty plan (missing folder, empty manifest …) so the
	// UI can show a real reason instead of a blank screen.
	Error string `json:"error"`
}

func loadManifest(folder string) (*BackupManifest, bool) {
	data, err := os.ReadFile(filepath.Join(folder, manifestName))
	if err != nil {
		return nil, false
	}
	var manifest BackupManifest
	if err := json.Unmarshal(data, &manifest); err != nil {
		return nil, false
	}
	return &manifest, true
}

// PreviewRestorePlan reviews what a restore would push back to the device.
// It never fails silently: when there is nothing to show, plan.Error carries the
// reason so the UI can explain it instead of rendering a blank screen.
func (a *App) PreviewRestorePlan(localFolder string) (*RestorePlan, error) {
	localFolder = strings.TrimSpace(localFolder)
	if localFolder == "" {
		localFolder = a.defaultBackupFolder()
	}
	plan := &RestorePlan{LocalFolder: localFolder, Items: []RestorePlanItem{}}

	if info, err := os.Stat(localFolder); err != nil || !info.IsDir() {
		plan.Error = fmt.Sprintf("Backup folder not found: %s", localFolder)
		return plan, nil
	}

	if _, ok := loadManifest(localFolder); ok {
		plan.HasManifest = true
	}
	if _, err := os.ReadDir(localFolder); err != nil {
		plan.Error = fmt.Sprintf("Cannot read %s: %v", localFolder, err)
		return plan, nil
	}

	// The folders in the backup directory decide the plan, so everything the user
	// backed up is offered again — not just the categories of the last run.
	for _, group := range collectRestoreGroups(localFolder) {
		item := RestorePlanItem{Category: group.category, Label: group.label, Available: true}
		for _, job := range group.jobs {
			item.FileCount++
			item.TotalBytes += job.size
		}
		plan.Items = append(plan.Items, item)
		plan.TotalFiles += item.FileCount
		plan.TotalBytes += item.TotalBytes
	}
	if len(plan.Items) == 0 {
		plan.Error = fmt.Sprintf("No backup data found in %s — choose the folder the backup was written to.", localFolder)
	}
	return plan, nil
}

type restoreJob struct {
	category   string
	remotePath string
	localPath  string
	size       int64
}

const customFolderDir = "Custom"

// restoreGroup is one restorable folder inside a backup directory: the category
// the UI lists it under plus the files it would push back to the phone.
type restoreGroup struct {
	category string
	label    string
	jobs     []restoreJob
}

// collectRestoreGroups lists everything a backup folder can restore. The folders
// on disk decide that list; manifest.json is only consulted for the exact device
// paths of the run that wrote it. Trusting the manifest alone hid real data:
// every backup run overwrites the manifest with just its own categories, so the
// Downloads / WhatsApp / custom-folder backups of earlier runs stayed on disk but
// never appeared in the restore plan.
func collectRestoreGroups(localFolder string) []restoreGroup {
	manifest, _ := loadManifest(localFolder)

	// Files the manifest recorded, per category, and only while they still exist
	// in the backup folder: a file can be deleted after the manifest was written,
	// and a plan must never promise something that is gone.
	manifestJobs := map[string][]restoreJob{}
	customFolders := map[string]string{} // Custom/<name> -> device path
	if manifest != nil {
		for _, file := range manifest.Files {
			local := filepath.Join(localFolder, file.LocalPath)
			if info, err := os.Stat(local); err != nil || info.IsDir() {
				continue
			}
			remote := file.RemotePath
			if remote == "" {
				if def, known := findCategory(file.Category); known {
					remote = strings.TrimRight(def.RemotePath, "/") + "/" + filepath.Base(file.LocalPath)
				}
			}
			manifestJobs[file.Category] = append(manifestJobs[file.Category], restoreJob{
				category:   file.Category,
				remotePath: remote,
				localPath:  local,
				size:       file.Size,
			})
		}
		// A custom folder is stored in the manifest under the device path it was
		// copied from, which is how it is matched back to Custom/<name>.
		for category := range manifestJobs {
			if strings.HasPrefix(category, "/") {
				customFolders[sanitizeFileComponent(remoteBaseName(category))] = category
			}
		}
	}

	entries, err := os.ReadDir(localFolder)
	if err != nil {
		return nil
	}

	groups := make([]restoreGroup, 0, len(entries))
	appendGroup := func(category, label, remoteBase, root string) {
		jobs := manifestJobs[category]
		if len(jobs) == 0 {
			jobs = walkRestoreTree(category, root, remoteBase)
		}
		if len(jobs) == 0 {
			return
		}
		groups = append(groups, restoreGroup{category: category, label: label, jobs: jobs})
	}

	for _, entry := range entries {
		if !entry.IsDir() {
			continue
		}
		name := entry.Name()
		switch {
		case name == "Apps":
			// App backups are reinstalled with InstallAppBackups, not pushed as
			// raw files, so they must not appear in the data-folders list.
		case name == customFolderDir:
			nested, err := os.ReadDir(filepath.Join(localFolder, name))
			if err != nil {
				continue
			}
			for _, child := range nested {
				if !child.IsDir() {
					continue
				}
				folder := child.Name()
				remote := customFolders[sanitizeFileComponent(folder)]
				if remote == "" {
					// The manifest no longer records this folder's device path (a
					// later, narrower backup overwrote it), so fall back to the
					// /sdcard/<name> guess this app has always used for folders it
					// cannot place.
					remote = filepath.ToSlash(filepath.Join("/sdcard", folder))
				}
				appendGroup(remote, fmt.Sprintf("%s (%s)", folder, customFolderDir), remote,
					filepath.Join(localFolder, name, folder))
			}
		default:
			def, known := findCategory(name)
			if known && def.RemotePath == "" {
				// Known category without a device path (SMS/calls): protected app
				// storage that cannot be pushed back.
				continue
			}
			remoteBase := filepath.ToSlash(filepath.Join("/sdcard", name))
			label := name
			if known {
				remoteBase = def.RemotePath
				label = def.Label
			}
			appendGroup(name, label, remoteBase, filepath.Join(localFolder, name))
		}
	}
	return groups
}

// walkRestoreTree turns one local folder into push jobs below a device path.
func walkRestoreTree(category, root, remoteBase string) []restoreJob {
	jobs := []restoreJob{}
	_ = filepath.Walk(root, func(current string, info os.FileInfo, err error) error {
		if err != nil || info == nil || info.IsDir() {
			return nil
		}
		rel, relErr := filepath.Rel(root, current)
		if relErr != nil {
			return nil
		}
		jobs = append(jobs, restoreJob{
			category:   category,
			remotePath: strings.TrimRight(remoteBase, "/") + "/" + filepath.ToSlash(rel),
			localPath:  current,
			size:       info.Size(),
		})
		return nil
	})
	return jobs
}

// buildRestoreJobs flattens every restorable folder into the push list.
func buildRestoreJobs(localFolder string) []restoreJob {
	jobs := make([]restoreJob, 0, 128)
	for _, group := range collectRestoreGroups(localFolder) {
		jobs = append(jobs, group.jobs...)
	}
	return jobs
}

// RunRestore pushes backed-up files back onto the device with live progress.
func (a *App) RunRestore(localFolder string, categories []string) (*TransferResult, error) {
	if err := a.requireAnyDevice(); err != nil {
		return nil, err
	}
	localFolder = strings.TrimSpace(localFolder)
	if localFolder == "" {
		localFolder = a.defaultBackupFolder()
	}

	selected := map[string]bool{}
	for _, category := range categories {
		selected[strings.ToLower(category)] = true
	}

	allJobs := buildRestoreJobs(localFolder)
	jobs := make([]restoreJob, 0, len(allJobs))
	for _, job := range allJobs {
		if len(selected) > 0 && !selected[strings.ToLower(job.category)] {
			continue
		}
		jobs = append(jobs, job)
	}

	result := &TransferResult{Operation: "restore", TargetFolder: localFolder, TotalFiles: len(jobs)}
	reporter := newProgressReporter(a, "restore", len(jobs))
	reporter.report("planning", "", "", false, fmt.Sprintf("Planned %d files", len(jobs)))

	if len(jobs) == 0 {
		reporter.finish("Nothing to restore.")
		return result, nil
	}

	// Ensure target directories exist.
	dirs := map[string]bool{}
	for _, job := range jobs {
		dirs[filepath.ToSlash(filepath.Dir(job.remotePath))] = true
	}
	for dir := range dirs {
		_, _ = executeADB("shell", "mkdir", "-p", deviceQuote(dir))
	}

	workers := runtime.NumCPU()
	if workers < 2 {
		workers = 2
	}
	jobCh := make(chan restoreJob, workers)
	var mu sync.Mutex
	var wg sync.WaitGroup

	for w := 0; w < workers; w++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for job := range jobCh {
				if _, err := executeADB("push", job.localPath, job.remotePath); err != nil {
					reporter.addFailed()
					mu.Lock()
					result.Failed++
					if len(result.Errors) < 40 {
						result.Errors = append(result.Errors, fmt.Sprintf("%s: %v", job.localPath, err))
					}
					mu.Unlock()
					reporter.report("copying", job.category, job.remotePath, false, "")
					continue
				}
				reporter.addBytes(job.size)
				mu.Lock()
				result.Copied++
				result.Bytes += job.size
				mu.Unlock()
				reporter.report("copying", job.category, job.remotePath, false, "")
			}
		}()
	}

	for _, job := range jobs {
		jobCh <- job
	}
	close(jobCh)
	wg.Wait()

	message := fmt.Sprintf("Restored %d of %d files", result.Copied, result.TotalFiles)
	if result.Failed > 0 {
		message += fmt.Sprintf(" (%d failed)", result.Failed)
	}
	reporter.finish(message)
	return result, nil
}

// BackupData keeps the original entry point working for older frontends.
func (a *App) BackupData(targetFolder string, categories []string) error {
	result, err := a.RunBackup(categories, targetFolder, nil)
	if err != nil {
		return err
	}
	if result.Failed > 0 {
		return fmt.Errorf("completed with %d errors. First error: %s", result.Failed, firstOr(result.Errors, "unknown"))
	}
	return nil
}

// RestoreData keeps the original entry point working for older frontends.
func (a *App) RestoreData(targetFolder string, categories []string) error {
	result, err := a.RunRestore(targetFolder, categories)
	if err != nil {
		return err
	}
	if result.Failed > 0 {
		return fmt.Errorf("restore completed with %d errors", result.Failed)
	}
	return nil
}

func firstOr(values []string, fallback string) string {
	if len(values) > 0 {
		return values[0]
	}
	return fallback
}
