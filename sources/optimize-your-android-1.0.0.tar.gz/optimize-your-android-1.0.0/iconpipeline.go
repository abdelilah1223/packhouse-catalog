package main

import (
	"encoding/base64"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	wruntime "github.com/wailsapp/wails/v2/pkg/runtime"
)

// The icon pipeline supports two modes:
//
//	fast — stream just the launcher-icon entry out of each APK with the device's
//	       own `unzip` (a few kilobytes per app, ~50ms).
//	apk  — pull the full APKs of *user-installed* apps into a folder with a worker
//	       pool, then read the icon locally. Slower on the first run, but the
//	       pulled APKs are reused on the next run.
//
// System apps always get the generic Android icon: they rarely ship a raster
// launcher icon and are hidden by default in the app list anyway.

const systemAppIconSVG = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="96" height="96" role="img">` +
	`<rect width="24" height="24" rx="5" fill="#3ddc84"/>` +
	`<g fill="#0f1115">` +
	`<path d="M6.3 6.1 5.4 4.6a.55.55 0 1 1 .95-.55l.9 1.6A7.2 7.2 0 0 1 12 4.6c1.75 0 3.4.4 4.75 1.1l.9-1.6a.55.55 0 1 1 .95.55l-.9 1.5A6.5 6.5 0 0 1 21.2 11.4H2.8A6.5 6.5 0 0 1 6.3 6.1z"/>` +
	`<circle cx="8.1" cy="9.1" r="1.15" fill="#3ddc84"/>` +
	`<circle cx="15.9" cy="9.1" r="1.15" fill="#3ddc84"/>` +
	`<rect x="4.4" y="12.6" width="15.2" height="5.6" rx="1.1"/>` +
	`<rect x="1.9" y="13.1" width="1.6" height="4.6" rx=".8"/>` +
	`<rect x="20.5" y="13.1" width="1.6" height="4.6" rx=".8"/>` +
	`<rect x="7.4" y="19.4" width="1.7" height="3.2" rx=".85"/>` +
	`<rect x="14.9" y="19.4" width="1.7" height="3.2" rx=".85"/>` +
	`</g></svg>`

// systemAppIconFile writes the generic icon into the icon folder and returns it.
func systemAppIconFile() string {
	path := filepath.Join(appCacheDir("icons"), "android-default.svg")
	if _, err := os.Stat(path); err != nil {
		_ = os.WriteFile(path, []byte(systemAppIconSVG), 0o644)
	}
	return path
}

func systemAppIconDataURL() string {
	return "data:image/svg+xml;base64," + base64.StdEncoding.EncodeToString([]byte(systemAppIconSVG))
}

// GetSystemAppIcon returns the generic Android icon shown for system apps.
func (a *App) GetSystemAppIcon() string {
	return systemAppIconDataURL()
}

// GetIconFolder is the folder where extracted icons are saved as real images.
func (a *App) GetIconFolder() string {
	return appCacheDir("icons")
}

// defaultAPKFolder is where pulled APKs are kept so a second run can reuse them.
func defaultAPKFolder() string {
	return appCacheDir("apks")
}

// GetAPKFolder is the default folder APKs are pulled into.
func (a *App) GetAPKFolder() string {
	return defaultAPKFolder()
}

// IconExtractRequest describes an icon-extraction batch.
type IconExtractRequest struct {
	Packages      []string `json:"packages"` // empty => every installed app
	Mode          string   `json:"mode"`     // "fast" | "apk"
	APKFolder     string   `json:"apkFolder"`
	Workers       int      `json:"workers"`
	SkipCached    bool     `json:"skipCached"`
	GenericSystem bool     `json:"genericSystem"`
}

// IconExtractResult is the outcome for a single package.
//
// Source is one of:
//
//	system  — written by us: the generic Android icon for a system app
//	generic — the app's icon could not be read, so the generic icon was used
//	apk     — read from an APK that was pulled to APKPath
//	fast    — read directly out of the on-device APK
//	cache   — reused from a previous run
//	none    — nothing could be produced (only when the generic fallback is off)
type IconExtractResult struct {
	PackageName string `json:"packageName"`
	DataURL     string `json:"dataUrl"`
	Source      string `json:"source"`
	FilePath    string `json:"filePath"`
	APKPath     string `json:"apkPath"`
	Error       string `json:"error"`
}

// IconProgress is streamed to the UI while icons are extracted.
type IconProgress struct {
	Completed int    `json:"completed"`
	Total     int    `json:"total"`
	Percent   int    `json:"percent"`
	Current   string `json:"current"`
	Done      bool   `json:"done"`
	Message   string `json:"message"`
	Failed    int    `json:"failed"`
}

// iconPerAppTimeout bounds one app's extraction. Every adb call already has its
// own deadline, but a single app can chain several of them (list entries, read
// manifest, read resources, fall back to a pull); this cap guarantees one slow
// app can never stall the batch — or the waiting screen — indefinitely.
const iconPerAppTimeout = 2 * time.Minute

// extractOneIconBounded runs extractOneIcon under a deadline. On timeout the
// worker slot is released with the generic icon and an error, while the
// background attempt is free to finish and populate the icon cache for the
// next run.
func extractOneIconBounded(app AppInfo, mode, apkFolder string, skipCached, genericSystem bool) IconExtractResult {
	ch := make(chan IconExtractResult, 1)
	go func() {
		ch <- extractOneIcon(app, mode, apkFolder, skipCached, genericSystem)
	}()
	select {
	case result := <-ch:
		return result
	case <-time.After(iconPerAppTimeout):
		return IconExtractResult{
			PackageName: app.PackageName,
			DataURL:     systemAppIconDataURL(),
			FilePath:    systemAppIconFile(),
			Source:      "generic",
			Error:       fmt.Sprintf("icon extraction for %s timed out after %s", app.PackageName, iconPerAppTimeout),
		}
	}
}

func (a *App) emitIconProgress(progress IconProgress) {
	if a.ctx == nil {
		return
	}
	wruntime.EventsEmit(a.ctx, "icons:progress", progress)
}

func apkLocalPath(folder, packageName string) string {
	return filepath.Join(folder, sanitizeFileComponent(packageName)+".apk")
}

// pullAppAPK copies an installed app's base APK into folder and returns the local
// path. An existing, non-empty copy is reused so repeat runs cost nothing.
func pullAppAPK(remotePath, folder, packageName string) (string, error) {
	if strings.TrimSpace(remotePath) == "" {
		return "", fmt.Errorf("app %s has no apk path", packageName)
	}
	if err := os.MkdirAll(folder, 0o755); err != nil {
		return "", err
	}
	local := apkLocalPath(folder, packageName)
	if info, err := os.Stat(local); err == nil && info.Size() > 0 {
		return local, nil
	}
	partial := local + ".part"
	_ = os.Remove(partial)
	if _, err := executeADB("pull", remotePath, partial); err != nil {
		_ = os.Remove(partial)
		return "", err
	}
	if err := os.Rename(partial, local); err != nil {
		_ = os.Remove(partial)
		return "", err
	}
	return local, nil
}

// apkReader reads entries out of an APK, either from the host or the device, so
// the resolution logic below is written once and works for both.
type apkReader interface {
	read(name string) ([]byte, error)
}

type localAPKReader struct{ path string }

func (r localAPKReader) read(name string) ([]byte, error) {
	return readLocalZipEntry(r.path, name)
}

type deviceAPKReader struct{ path string }

func (r deviceAPKReader) read(name string) ([]byte, error) {
	return executeADBRaw("exec-out", "unzip", "-p", r.path, name)
}

// strongIconScore is the name-match score above which a launcher icon is
// considered unambiguous, and reading the resource table would be wasted work.
// Below it we resolve the icon the way Android does instead of guessing.
const strongIconScore = 40

// extractAPKIcon produces the launcher icon bytes for an APK.
//
// Order of attack:
//  1. an unambiguous launcher-named image (cheap, no extra reads);
//  2. the android:icon resource resolved through AndroidManifest.xml and
//     resources.arsc (correct even for resource-obfuscated APKs);
//  3. the best remaining name-based match.
func extractAPKIcon(reader apkReader, entries []apkEntry) []byte {
	if data := readIconBytes(reader, entries, strongIconScore); len(data) > 0 {
		return data
	}
	if data := extractManifestIcon(reader, entries); len(data) > 0 {
		return data
	}
	return readIconBytes(reader, entries, 0)
}

// readIconBytes reads the best name-based candidate whose score is at least min.
func readIconBytes(reader apkReader, entries []apkEntry, min int) []byte {
	best, ok := pickIconEntry(entries)
	if !ok || scoreIconEntry(best.name) < min {
		return nil
	}
	data, err := reader.read(best.name)
	if err != nil || len(data) == 0 {
		return nil
	}
	if detectImageMime(data) == "" {
		return nil
	}
	return data
}

// extractManifestIcon follows android:icon into the resource table and picks the
// sharpest variant that actually exists in the APK.
func extractManifestIcon(reader apkReader, entries []apkEntry) []byte {
	manifest, err := reader.read("AndroidManifest.xml")
	if err != nil || len(manifest) == 0 {
		return nil
	}
	resID, ok := manifestIconResource(manifest)
	if !ok {
		return nil
	}
	arsc, err := reader.read("resources.arsc")
	if err != nil || len(arsc) == 0 {
		return nil
	}
	return resolveIconResource(reader, entries, arsc, resID, 0)
}

// resolveIconResource turns a resource ID into image bytes. Modern icons are
// adaptive: the ID resolves to an XML layer list rather than a bitmap, so XML
// candidates are followed (up to a small depth) and their referenced layers are
// resolved in turn.
func resolveIconResource(reader apkReader, entries []apkEntry, arsc []byte, resID uint32, depth int) []byte {
	if resID == 0 || depth > 3 {
		return nil
	}
	candidates := resourceFileCandidates(arsc, resID)
	if len(candidates) == 0 {
		return nil
	}

	byName := make(map[string]apkEntry, len(entries))
	for _, entry := range entries {
		byName[entry.name] = entry
	}

	// Prefer the sharpest bitmap the resource resolves to directly.
	bestName := ""
	bestRank := -1
	bestSize := int64(-1)
	xmlLayers := make([]string, 0, 4)
	for _, candidate := range candidates {
		entry, exists := byName[candidate.path]
		if !exists {
			continue
		}
		lower := strings.ToLower(candidate.path)
		if !isIconImageEntry(lower) {
			if strings.HasSuffix(lower, ".xml") {
				xmlLayers = append(xmlLayers, candidate.path)
			}
			continue
		}
		rank := densityRankOf(candidate.density)
		if rank > bestRank || (rank == bestRank && entry.size > bestSize) {
			bestRank, bestSize, bestName = rank, entry.size, candidate.path
		}
	}
	if bestName != "" {
		if data, err := reader.read(bestName); err == nil && len(data) > 0 && detectImageMime(data) != "" {
			return data
		}
	}

	// No bitmap: follow the layer list (adaptive icon / vector wrapper).
	for _, layerPath := range xmlLayers {
		layerXML, err := reader.read(layerPath)
		if err != nil || len(layerXML) == 0 {
			continue
		}
		for _, reference := range xmlResourceLayerReferences(layerXML) {
			if data := resolveIconResource(reader, entries, arsc, reference, depth+1); len(data) > 0 {
				return data
			}
		}
	}
	return nil
}

// iconFromLocalAPK extracts the launcher icon from an APK already on the host.
func iconFromLocalAPK(localPath string) []byte {
	entries, err := localZipEntries(localPath)
	if err != nil {
		return nil
	}
	return extractAPKIcon(localAPKReader{localPath}, entries)
}

// percentBetween maps a completed/total pair onto a sub-range of a progress bar.
func percentBetween(from, to, completed, total int) int {
	if total <= 0 || to <= from {
		return to
	}
	return from + (to-from)*completed/total
}

// extractIcons runs the bounded worker pool. It performs no device-availability
// check of its own so it can be reused inside PrepareSession (which has already
// verified the device).
func (a *App) extractIcons(apps []AppInfo, req IconExtractRequest, fromPercent, toPercent int) []IconExtractResult {
	workers := req.Workers
	if workers <= 0 {
		workers = 6
	}
	if workers > 16 {
		workers = 16
	}

	mode := strings.ToLower(strings.TrimSpace(req.Mode))
	if mode != "apk" {
		mode = "fast"
	}
	apkFolder := strings.TrimSpace(req.APKFolder)
	if apkFolder == "" {
		apkFolder = defaultAPKFolder()
	}
	if mode == "apk" {
		_ = os.MkdirAll(apkFolder, 0o755)
	}

	total := len(apps)
	results := make([]IconExtractResult, total)
	if total == 0 {
		return results
	}

	// Throttle progress events so a few hundred apps do not flood the UI.
	step := total / 60
	if step < 1 {
		step = 1
	}

	jobs := make(chan int)
	var wg sync.WaitGroup
	var completed int32
	var failed int32

	for i := 0; i < workers; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for index := range jobs {
				app := apps[index]
				result := extractOneIconBounded(app, mode, apkFolder, req.SkipCached, req.GenericSystem)
				results[index] = result
				if result.Error != "" {
					atomic.AddInt32(&failed, 1)
				}
				done := int(atomic.AddInt32(&completed, 1))
				if done == 1 || done == total || done%step == 0 {
					a.emitIconProgress(IconProgress{
						Completed: done,
						Total:     total,
						Percent:   percentBetween(fromPercent, toPercent, done, total),
						Current:   app.Name,
						Failed:    int(atomic.LoadInt32(&failed)),
					})
				}
			}
		}()
	}

	for index := range apps {
		jobs <- index
	}
	close(jobs)
	wg.Wait()

	failedTotal := int(atomic.LoadInt32(&failed))
	message := fmt.Sprintf("%d icons ready", total)
	if failedTotal > 0 {
		message = fmt.Sprintf("%d icons ready (%d failed — retried next run)", total, failedTotal)
	}
	a.emitIconProgress(IconProgress{
		Completed: total,
		Total:     total,
		Percent:   toPercent,
		Done:      true,
		Message:   message,
		Failed:    failedTotal,
	})
	return results
}

// extractOneIcon resolves a single app's icon: generic for system apps, APK pull
// in "apk" mode, otherwise a direct stream of the icon entry from the device.
//
// When nothing can be read — most often a resource-obfuscated APK whose drawables
// are renamed to things like res/0H.png, so no name rule can find the launcher
// icon — the generic Android icon is used so the UI never shows an empty slot.
func extractOneIcon(app AppInfo, mode, apkFolder string, skipCached, genericSystem bool) IconExtractResult {
	result := IconExtractResult{PackageName: app.PackageName}

	// Resolve the user-visible app name while we are about to read this APK
	// anyway; the label is cached by package name, so this costs nothing on later
	// runs — including for system apps, which skip icon extraction entirely below.
	ensureAppLabel(app.PackageName, app.Path)

	if genericSystem && !app.IsThirdParty {
		result.DataURL = systemAppIconDataURL()
		result.FilePath = systemAppIconFile()
		result.Source = "system"
		return result
	}

	if skipCached {
		if data, ok := readIconCache(app.PackageName); ok {
			if len(data) > 0 {
				result.DataURL = iconDataURL(data)
				mime := detectImageMime(data)
				if mime == "" {
					mime = "image/png"
				}
				result.FilePath = iconImagePath(app.PackageName, mime)
				result.Source = "cache"
				return result
			}
			// Cached decision: this app has no extractable icon — do not re-read
			// its APK on every launch.
			result.DataURL = systemAppIconDataURL()
			result.FilePath = systemAppIconFile()
			result.Source = "generic"
			return result
		}
	}

	var data []byte
	source := ""
	conclusive := false
	var pullErr error
	pulled := false

	if mode == "apk" && app.IsThirdParty {
		if local, err := pullAppAPK(app.Path, apkFolder, app.PackageName); err != nil {
			pullErr = err
		} else {
			pulled = true
			result.APKPath = local
			if icon := iconFromLocalAPK(local); len(icon) > 0 {
				data = icon
				source = "apk"
				conclusive = true
			} else {
				// The full APK was read locally and really has no icon.
				conclusive = true
			}
		}
	}

	// The on-device read uses the same entry rules as the local read, so it is only
	// worth doing when we have no local APK to inspect.
	if len(data) == 0 && !pulled {
		icon, ok := fetchAppIconBytesForApp(app.PackageName, app.Path)
		if len(icon) > 0 {
			data = icon
			source = "fast"
			conclusive = true
		} else {
			conclusive = ok
		}
	}

	if len(data) == 0 {
		result.DataURL = systemAppIconDataURL()
		result.FilePath = systemAppIconFile()
		result.Source = "generic"
		if conclusive {
			// Remember "no icon for this package" so the next launch skips it.
			if _, err := writeIconCache(app.PackageName, nil); err != nil {
				result.Error = err.Error()
			}
		}
		if pullErr != nil {
			result.Error = pullErr.Error()
		}
		return result
	}

	if _, err := writeIconCache(app.PackageName, data); err != nil {
		result.Error = err.Error()
	}
	mime := detectImageMime(data)
	if mime == "" {
		mime = "image/png"
	}
	result.DataURL = iconDataURL(data)
	result.Source = source
	result.FilePath = iconImagePath(app.PackageName, mime)
	return result
}

// ExtractAppIcons extracts icons for the requested packages (all installed apps
// when the list is empty) and saves each one into the icon folder.
func (a *App) ExtractAppIcons(req IconExtractRequest) ([]IconExtractResult, error) {
	if err := a.requireAnyDevice(); err != nil {
		return nil, err
	}
	installed, err := a.GetInstalledApps()
	if err != nil {
		return nil, err
	}

	wanted := make(map[string]bool, len(req.Packages))
	for _, pkg := range req.Packages {
		if trimmed := strings.TrimSpace(pkg); trimmed != "" {
			wanted[trimmed] = true
		}
	}

	targets := make([]AppInfo, 0, len(installed))
	for _, app := range installed {
		if len(wanted) > 0 && !wanted[app.PackageName] {
			continue
		}
		targets = append(targets, app)
	}
	if len(targets) == 0 {
		return nil, nil
	}
	return a.extractIcons(targets, req, 0, 100), nil
}
