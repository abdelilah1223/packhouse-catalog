import {
    CheckDeviceState, ChooseFolder, ClearIconCache, DefaultBackupFolder,
    DeleteRecoveredFile, DeleteRecoveredFiles,
    DisableApp, EnableApp, ExtractAppIcons, GetAppIcon, GetBackupCategories,
    GetCachedSession, GetConnectedDevices, GetFilePreview, GetFileSizes, GetFileThumbnail,
    GetIconFolder, GetInstalledApps, GetStorageVolumes, GetSystemAppIcon, InstallAppBackups,
    ListAndroidFiles, ListLocalAppBackups, ListZipContents, OpenFileExternally, PrefetchAndroidFiles,
    PrepareSession, PreviewAppBackup, PreviewBackupPlan, PreviewRestorePlan, ReadZipEntry,
    RemotePathExists, RequestADBAuthorization, RestoreFilesToDevice, RestoreRecoveredFileTo,
    RunAppBackup, RunBackup, RunRestore, SaveFileToPC, SaveFilesToPC, ScanRecoverableFiles,
    UninstallApp,
} from '../wailsjs/go/main/App';
import { EventsOn } from '../wailsjs/runtime/runtime';

/* ------------------------------------------------------------------ *
 * Translations
 * ------------------------------------------------------------------ */

const translations = {
    en: {
        brand: 'Android Optimizer',
        dashboard: 'Dashboard',
        apps: 'App Manager',
        backup: 'Backup & Restore',
        tasks: 'Data Recovery',
        files: 'File Browser',
        logs: 'Messages & Calls',
        guide: 'USB Debugging Guide',
        scan: 'Scan',
        scanning: 'Scanning...',
        disconnected: 'Disconnected',
        connectedDevices: 'Device(s) connected',
        noDevices: 'No devices found. Enable USB debugging and accept the ADB prompt on the phone.',
        errorChecking: 'Error checking devices:',
        langSwitch: 'عربي',
        welcomeTitle: 'Welcome to Android Optimizer',
        welcomeDesc: 'Connect your device via USB with USB debugging enabled, or over Wi-Fi, to inspect apps, back up data and recover residual files.',
        enableDevMode: 'How to Enable Developer Mode & USB Debugging',
        step1Title: '1. Open Settings', step1Desc: "Open your Android phone's Settings app.",
        step2Title: '2. About phone', step2Desc: "Scroll down and tap 'About phone'.",
        step3Title: '3. Build number', step3Desc: "Tap 'Build number' 7 times until you see 'You are now a developer!'.",
        step4Title: '4. Developer options', step4Desc: "Open Developer options and enable 'USB debugging'. Then accept the prompt on the phone.",
        /* shared */
        close: 'Close', cancel: 'Cancel', back: 'Back', refresh: 'Refresh', loading: 'Loading...',
        search: 'Search', all: 'All', none: 'None', retry: 'Retry', preview: 'Preview',
        saveToPc: 'Save to PC', openExternally: 'Open externally', loadingIcons: 'Loading icons…',
        loadMore: 'Load more', showing: 'Showing', of: 'of', filesWord: 'files', unknown: 'Unknown',
        selectDevicePrompt: 'Connect the phone with USB debugging enabled and accept the ADB prompt, then retry.',
        /* apps */
        appsSearchPlaceholder: 'Filter by app name or package…',
        appsSafetyFilter: 'Recommendation', appsTypeFilter: 'App type',
        filterAll: 'All apps', filterRemove: 'Recommended to remove', filterSafe: 'Safe to keep',
        filterUnknown: 'Not in database', filterUser: 'User apps', filterSystem: 'System apps',
        sortBy: 'Sort', sortName: 'Name', sortPackage: 'Package', sortRisk: 'Risk',
        recommendedRemove: 'Recommended to remove', safeKeep: 'Safe to keep', notInDb: 'Not in local database',
        uninstall: 'Uninstall', confirmUninstall: 'Uninstall this app from the phone?',
        disable: 'Disable', enable: 'Enable',
        confirmDisable: 'Disable this app? It stays installed but cannot run until you enable it again.',
        disabledState: 'disabled',
        iconsFolder: 'Icons are saved in',
        iconsFolderHint: 'one image file per app, named after its package',
        noAppsMatch: 'No apps match the current filters.',
        loadAllIcons: 'Load all icons', reloadIcons: 'Re-read icons from device',
        iconsCached: 'icons cached',
        /* backup */
        backupIntro: 'Pick what to copy from the phone, review the plan, then start the backup.',
        backupTargetFolder: 'Save backups to this folder on the PC',
        backupReview: 'Review backup plan',
        backupPlanTitle: 'Backup plan',
        backupPlanNote: 'Nothing has been copied yet. Confirm to start the transfer.',
        backupStart: 'Yes, start backup',
        backupDone: 'Backup finished',
        backupRestoreIntro: 'Restore files from a backup folder on the PC back onto the phone.',
        backupLocalFolder: 'Backup folder on the PC',
        backupReviewRestore: 'Review restore plan',
        backupRestorePlanTitle: 'Restore plan',
        backupRestoreStart: 'Yes, start restore',
        backupRestoreDone: 'Restore finished',
        backupNothing: 'Select at least one category or phone folder first.',
        backupNotAvailable: 'Not accessible without root',
        backupProgress: 'Transfer progress',
        backupCopied: 'Copied', backupFailed: 'Failed', backupCategory: 'Category',
        backupManifest: 'Manifest written to', backupNoManifest: 'No manifest found — using the folder structure.',
        backupRestart: 'Back to backup setup',
        category: 'Category', selectedFiles: 'Files', sizeLabel: 'Size',
        /* recovery */
        recoveryIntro: 'Choose the kind of data you are looking for. The scanner then digs through trash, caches, thumbnails and app folders.',
        recoveryPickType: 'What are you looking for?',
        recPhotos: 'Photos', recVideos: 'Videos', recAudio: 'Audio', recDocs: 'Documents',
        recArchives: 'Archives', recApks: 'APK files', recPhone: 'Messages & calls', recAll: 'Everything',
        recoveryQueryPlaceholder: 'Optional: filter by file name, folder or phone number',
        recoveryQuickScan: 'Quick scan', recoveryDeepScan: 'Deep scan',
        recoveryQuickHint: 'Quick scan checks the usual residual spots: trash, caches, thumbnails and app folders.',
        recoveryDeepHint: 'Deep scan walks the whole shared storage as well — slower, but finds more.',
        recoveryScanning: 'Scanning device… this can take a while.',
        recoveryResults: 'Scan results',
        recoveryNoResults: 'Nothing matched. Try Deep scan or a different data type.',
        recoveryRestoreDevice: 'Restore on phone',
        recoveryRestoreFolder: 'Destination folder on the phone',
        recoverySavedTo: 'Saved to',
        recRemove: 'Remove', recRemoveSelected: 'Remove selected',
        recRemoveConfirm: 'Permanently delete this file from the phone?',
        recRemoveSelectedConfirm: 'Permanently delete the selected files from the phone?',
        recRemoved: 'Removed',
        recoveryChangeType: 'Choose another type',
        recoveryHidden: 'hidden',
        /* files */
        filesPath: 'Path', filesEmpty: 'This folder is empty.',
        filesPrefetch: 'Preloading folders…', filesUp: 'Parent folder',
        filesReadError: 'Unable to read this folder.',
        filesCached: 'Cached — loaded instantly',
        /* preview */
        previewTitle: 'File preview', previewTooLarge: 'File too large to preview inline.',
        previewNoInline: 'No inline preview for this file type.',
        previewKind: 'Type', previewSize: 'Size', previewModified: 'Modified',
        smsLabel: 'SMS messages', callLogLabel: 'Call log',
        riskDanger: 'Danger — do not remove', riskRecommended: 'Recommended to remove',
        riskSafe: 'Safe to keep', riskUnknown: 'Unknown app',
        filterRecommended: 'Recommended to remove', filterDanger: 'Dangerous to remove',
        filterUserOnly: 'Installed user apps', filterSystemOnly: 'System apps',
        filterTypeLabel: 'Filter', uninstallBlocked: 'Flagged as unsafe to remove',
        uninstallBlockedHint: 'The local database lists this app as unsafe to remove, so Uninstall stays disabled for it — removing system apps can stop parts of your phone from working.',
        loadingData: 'Reading data from the device…',
        backupCustom: 'Back up a specific folder on the phone',
        backupCustomHint: 'Pick a device folder (for example /sdcard/DCIM) to copy it completely, including subfolders. Add as many folders as you need.',
        backupAddFolder: 'Add folder', backupCustomEmpty: 'No custom folders added.',
        backupEmptyFolder: 'Empty on this device',
        backupFolderInvalid: 'That path does not exist on the device — check the spelling.',
        backupFolderChecking: 'Checking path…',
        backupBrowse: 'Browse…',
        backupPickPhoneFolder: 'Pick a folder on the phone',
        backupUseThisFolder: 'Use this folder',
        backupFolderSelected: 'Selected phone folder',
        backupFolderPickHint: 'Open folders to move around, then use the current folder.',
        backupFolderLoadError: 'Unable to read this folder.',
        /* app (APK) backup */
        backupAppsSection: 'App backups (APK files)',
        backupAppsHint: 'Choose the apps to copy to the PC as installable APK files. Split APKs are included so apps can be reinstalled later.',
        backupAppsSearch: 'Filter apps…',
        backupAppsSelectAll: 'Select all',
        backupAppsClear: 'Clear',
        backupAppsStart: 'Back up selected apps',
        backupAppsSelected: 'selected',
        appBackupPlanTitle: 'App backup plan',
        appBackupDone: 'App backup finished',
        appBackupProgress: 'App backup progress',
        installAppsTitle: 'App backups found in this folder',
        installAppsHint: 'These apps were backed up from a phone. Tick the ones you want, then install them — split APK parts are installed together automatically on the connected phone.',
        installSelected: 'Install selected',
        installNoneSelected: 'Tick at least one app to install.',
        installProgress: 'Installing apps',
        installDone: 'App install finished',
        /* recovery bulk actions */
        recoverySelectAll: 'Select all',
        recoverySaveSelected: 'Save selected to PC…',
        recoveryRestoreSelected: 'Restore selected on phone…',
        recoveryNoneSelected: 'Select at least one file first.',
        recoveryWorking: 'Working…',
        recoverySavedAll: 'Saved',
        recoveryRestoredAll: 'Copied to',
        /* file browser storage + zip */
        filesStorage: 'Storage',
        filesInternal: 'Internal storage',
        filesSdCard: 'SD card',
        filesUsed: 'used',
        filesFree: 'free',
        filesStorageUnknown: 'Size unavailable',
        zipContents: 'Archive contents',
        zipEntries: 'entries',
        zipBack: 'Back to the archive',
        zipOpenHint: 'Click a file inside the archive to preview it.',
        zipEmpty: 'The archive is empty.',
        recoveryThumbHint: 'Thumbnails load as you scroll',
        /* onboarding */
        onbConnectTitle: 'Connect your phone',
        onbConnectDesc: 'Plug your Android phone into this computer with a USB cable and keep it unlocked.',
        onbConnectHint: 'Waiting for a device…',
        onbNoPhoneYet: 'No Android phone detected yet.',
        onbUsbDevices: 'USB devices on this computer',
        onbUsbDetected: 'Phone detected on USB',
        onbEnableTitle: 'Phone found — turn on USB debugging',
        onbEnableDesc: 'A phone is connected, but USB debugging is still off, so its data cannot be read yet.',
        onbUsbModeHint: 'Tip: on the phone, tap the USB notification and choose “File transfer / MTP” so the connection stays active while you work.',
        onbDone: 'I have enabled USB debugging',
        onbAuthorizeTitle: 'Waiting for your approval',
        onbAuthorizeDesc: 'Look at your phone and tap “Allow” on the “Allow USB debugging?” prompt.',
        onbAuthorizeHint: 'Nothing appeared? Unplug and replug the cable, keep the phone unlocked, then press Check again.',
        onbCheckAgain: 'Check again',
        onbGettingReady: 'Getting data ready',
        onbPreparingDesc: 'Reading installed apps, preparing the file browser and extracting app icons.',
        onbAdbMissingTitle: 'ADB tool not found',
        onbAdbMissingDesc: 'Install the Android SDK Platform-Tools so the “adb” command is available, then retry.',
        onbOfflineDesc: 'The phone is connected but ADB cannot talk to it yet. Unplug and replug the cable, then retry.',
        onbSkip: 'Skip for now',
        onbRetry: 'Retry',
        onbReadyTitle: 'Device ready',
        onbReadyDesc: 'The phone is connected and authorized.',
        onbLoadData: 'Load apps & files',
        onbDeviceLabel: 'Device',
        onbErrorTitle: 'Something went wrong',
        onbReconnect: 'Set up a device',
        onbOfflineTitle: 'Connecting to the phone…',
        /* icon pipeline */
        iconSource: 'Icon source',
        iconSourceFast: 'Fast — read from device',
        iconSourceApk: 'Pull APKs — user apps only',
        iconSourceHint: 'Fast streams only the icon file from the phone. Pull-APKs copies the whole APK of each user-installed app into a folder and reads the icon from those files — slower once, then cached.',
        apkFolderLabel: 'Folder for pulled APKs',
        apkFolderDefault: 'Default app cache folder',
        extractIcons: 'Extract all icons',
        extractingIcons: 'Extracting icons…',
        iconsExtracted: 'icons extracted',
        pullApkConfirmTitle: 'Pull APKs from the phone?',
        pullApkConfirmBody: 'The app will copy the APKs of user-installed apps to:\n{folder}\nand extract their icons. This can take a while the first time; later runs reuse the copied files.',
        systemAppIconNote: 'The Android icon is used only when an app icon cannot be read.',
        loadingFromCache: 'Loaded from cache',
    },
    ar: {
        brand: 'محسن الأندرويد',
        dashboard: 'لوحة القيادة',
        apps: 'إدارة التطبيقات',
        backup: 'النسخ الاحتياطي والاستعادة',
        tasks: 'استعادة البيانات',
        files: 'متصفح الملفات',
        logs: 'الرسائل والمكالمات',
        guide: 'دليل تصحيح USB',
        scan: 'فحص',
        scanning: 'جاري الفحص...',
        disconnected: 'غير متصل',
        connectedDevices: 'جهاز متصل',
        noDevices: 'لم يتم العثور على أجهزة. فعّل تصحيح USB ووافق على الطلب في الهاتف.',
        errorChecking: 'خطأ في فحص الأجهزة:',
        langSwitch: 'English',
        welcomeTitle: 'مرحباً بك في محسن الأندرويد',
        welcomeDesc: 'وصّل جهازك عبر USB مع تفعيل تصحيح الأخطاء، أو عبر Wi-Fi، لفحص التطبيقات والنسخ الاحتياطي واستعادة الملفات المتبقية.',
        enableDevMode: 'كيفية تمكين وضع المطور وتصحيح USB',
        step1Title: '1. افتح الإعدادات', step1Desc: 'افتح تطبيق الإعدادات في هاتفك.',
        step2Title: '2. حول الهاتف', step2Desc: "مرر لأسفل واضغط على 'حول الهاتف'.",
        step3Title: '3. رقم الإصدار', step3Desc: "اضغط على 'رقم الإصدار' 7 مرات حتى تظهر رسالة 'أنت الآن مطور!'.",
        step4Title: '4. خيارات المطور', step4Desc: "افتح خيارات المطور وفعّل 'تصحيح أخطاء USB' ثم وافق على الطلب في الهاتف.",
        close: 'إغلاق', cancel: 'إلغاء', back: 'رجوع', refresh: 'تحديث', loading: 'جاري التحميل...',
        search: 'بحث', all: 'الكل', none: 'لا شيء', retry: 'إعادة', preview: 'معاينة',
        saveToPc: 'حفظ على الحاسوب', openExternally: 'فتح خارجياً', loadingIcons: 'جاري تحميل الأيقونات…',
        loadMore: 'المزيد', showing: 'عرض', of: 'من', filesWord: 'ملف', unknown: 'غير معروف',
        selectDevicePrompt: 'وصّل الهاتف مع تفعيل تصحيح USB ووافق على الطلب ثم أعد المحاولة.',
        appsSearchPlaceholder: 'ابحث باسم التطبيق أو الحزمة…',
        appsSafetyFilter: 'التوصية', appsTypeFilter: 'نوع التطبيق',
        filterAll: 'كل التطبيقات', filterRemove: 'يُنصح بإزالته', filterSafe: 'آمن للإبقاء',
        filterUnknown: 'غير موجود في القاعدة', filterUser: 'تطبيقات المستخدم', filterSystem: 'تطبيقات النظام',
        sortBy: 'ترتيب', sortName: 'الاسم', sortPackage: 'الحزمة', sortRisk: 'الخطورة',
        recommendedRemove: 'يُنصح بإزالته', safeKeep: 'آمن للإبقاء', notInDb: 'غير موجود في القاعدة المحلية',
        uninstall: 'إزالة', confirmUninstall: 'هل تريد إزالة هذا التطبيق من الهاتف؟',
        disable: 'تعطيل', enable: 'تفعيل',
        confirmDisable: 'تعطيل هذا التطبيق؟ يبقى مثبتاً لكنه لن يعمل حتى تعيد تفعيله.',
        disabledState: 'معطّل',
        iconsFolder: 'الأيقونات محفوظة في',
        iconsFolderHint: 'صورة واحدة لكل تطبيق باسم حزمته',
        noAppsMatch: 'لا توجد تطبيقات مطابقة للتصفية الحالية.',
        loadAllIcons: 'تحميل كل الأيقونات', reloadIcons: 'إعادة قراءة الأيقونات من الجهاز',
        iconsCached: 'أيقونة مخزنة',
        backupIntro: 'اختر ما تريد نسخه من الهاتف، راجع الخطة، ثم ابدأ النسخ الاحتياطي.',
        backupTargetFolder: 'حفظ النسخ في هذا المجلد على الحاسوب',
        backupReview: 'مراجعة خطة النسخ',
        backupPlanTitle: 'خطة النسخ الاحتياطي',
        backupPlanNote: 'لم يتم نسخ أي شيء بعد. أكّد لبدء النقل.',
        backupStart: 'نعم، ابدأ النسخ',
        backupDone: 'اكتمل النسخ الاحتياطي',
        backupRestoreIntro: 'استعد الملفات من مجلد النسخة الاحتياطية على الحاسوب إلى الهاتف.',
        backupLocalFolder: 'مجلد النسخة الاحتياطية على الحاسوب',
        backupReviewRestore: 'مراجعة خطة الاستعادة',
        backupRestorePlanTitle: 'خطة الاستعادة',
        backupRestoreStart: 'نعم، ابدأ الاستعادة',
        backupRestoreDone: 'اكتملت الاستعادة',
        backupNothing: 'اختر فئة واحدة أو مجلداً من الهاتف على الأقل.',
        backupNotAvailable: 'غير متاح بدون صلاحيات الجذر',
        backupProgress: 'تقدم النقل',
        backupCopied: 'تم النسخ', backupFailed: 'فشل', backupCategory: 'الفئة',
        backupManifest: 'تم كتابة الملف الوصفي في', backupNoManifest: 'لا يوجد ملف وصفي — سيتم استخدام بنية المجلدات.',
        backupRestart: 'العودة لإعداد النسخ',
        category: 'الفئة', selectedFiles: 'الملفات', sizeLabel: 'الحجم',
        recoveryIntro: 'اختر نوع البيانات التي تبحث عنها. سيبحث الماسح في سلة المهملات والذاكرات المؤقتة والمصغرات ومجلدات التطبيقات.',
        recoveryPickType: 'ما الذي تبحث عنه؟',
        recPhotos: 'صور', recVideos: 'فيديو', recAudio: 'صوتيات', recDocs: 'مستندات',
        recArchives: 'ملفات مضغوطة', recApks: 'ملفات APK', recPhone: 'رسائل ومكالمات', recAll: 'كل شيء',
        recoveryQueryPlaceholder: 'اختياري: تصفية باسم الملف أو المجلد أو رقم الهاتف',
        recoveryQuickScan: 'فحص سريع', recoveryDeepScan: 'فحص عميق',
        recoveryQuickHint: 'الفحص السريع يبحث في المواقع المعتادة: سلة المهملات، الذاكرة المؤقتة، المصغرات ومجلدات التطبيقات.',
        recoveryDeepHint: 'الفحص العميق يمر على كامل مساحة التخزين — أبطأ لكنه يجد أكثر.',
        recoveryScanning: 'جاري فحص الجهاز… قد يستغرق وقتاً.',
        recoveryResults: 'نتائج الفحص',
        recoveryNoResults: 'لا نتائج. جرّب الفحص العميق أو نوع بيانات مختلف.',
        recoveryRestoreDevice: 'استعادة في الهاتف',
        recoveryRestoreFolder: 'مجلد الوجهة في الهاتف',
        recoverySavedTo: 'تم الحفظ في',
        recRemove: 'حذف', recRemoveSelected: 'حذف المحدد',
        recRemoveConfirm: 'حذف هذا الملف من الهاتف نهائياً؟',
        recRemoveSelectedConfirm: 'حذف الملفات المحددة من الهاتف نهائياً؟',
        recRemoved: 'تم الحذف',
        recoveryChangeType: 'اختر نوعاً آخر',
        recoveryHidden: 'مخفي',
        filesPath: 'المسار', filesEmpty: 'هذا المجلد فارغ.',
        filesPrefetch: 'جاري التحميل المسبق للمجلدات…', filesUp: 'المجلد الأعلى',
        filesReadError: 'تعذّر قراءة هذا المجلد.',
        filesCached: 'مخزّن — تم التحميل فوراً',
        previewTitle: 'معاينة الملف', previewTooLarge: 'الملف كبير جداً للمعاينة.',
        previewNoInline: 'لا تتوفر معاينة لهذا النوع.',
        previewKind: 'النوع', previewSize: 'الحجم', previewModified: 'التعديل',
        smsLabel: 'رسائل SMS', callLogLabel: 'سجل المكالمات',
        riskDanger: 'خطر — لا تقم بالإزالة', riskRecommended: 'يُنصح بإزالته',
        riskSafe: 'آمن للإبقاء', riskUnknown: 'تطبيق غير معروف',
        filterRecommended: 'يُنصح بإزالته', filterDanger: 'خطير الإزالة',
        filterUserOnly: 'تطبيقات المستخدم المثبتة', filterSystemOnly: 'تطبيقات النظام',
        filterTypeLabel: 'تصفية', uninstallBlocked: 'مُعلَّم كغير آمن للإزالة',
        uninstallBlockedHint: 'قاعدة البيانات المحلية تُصنّف هذا التطبيق كغير آمن للإزالة، لذلك يبقى زر الإزالة معطّلاً — إزالة تطبيقات النظام قد تعطّل أجزاءً من الهاتف.',
        loadingData: 'جاري قراءة البيانات من الجهاز…',
        backupCustom: 'نسخ مجلد معيّن من الهاتف',
        backupCustomHint: 'اختر مجلداً من الجهاز (مثلاً /sdcard/DCIM) لنسخه بالكامل مع المجلدات الفرعية. أضف ما تحتاج من المجلدات.',
        backupAddFolder: 'إضافة مجلد', backupCustomEmpty: 'لم تُضف مجلدات مخصصة.',
        backupEmptyFolder: 'فارغ على هذا الجهاز',
        backupFolderInvalid: 'هذا المسار غير موجود في الجهاز — تحقق من كتابته.',
        backupFolderChecking: 'جارٍ التحقق من المسار…',
        backupBrowse: 'استعراض…',
        backupPickPhoneFolder: 'اختر مجلداً من الهاتف',
        backupUseThisFolder: 'استخدم هذا المجلد',
        backupFolderSelected: 'المجلد المحدد من الهاتف',
        backupFolderPickHint: 'افتح المجلدات للتنقل، ثم استخدم المجلد الحالي.',
        backupFolderLoadError: 'تعذرت قراءة هذا المجلد.',
        backupAppsSection: 'نسخ احتياطي للتطبيقات (ملفات APK)',
        backupAppsHint: 'اختر التطبيقات لنسخها إلى الحاسوب كملفات APK قابلة للتثبيت. يتم تضمين ملفات الـ Split حتى يمكن إعادة تثبيت التطبيقات لاحقاً.',
        backupAppsSearch: 'تصفية التطبيقات…',
        backupAppsSelectAll: 'تحديد الكل',
        backupAppsClear: 'إلغاء التحديد',
        backupAppsStart: 'نسخ التطبيقات المحددة',
        backupAppsSelected: 'محدد',
        appBackupPlanTitle: 'خطة نسخ التطبيقات',
        appBackupDone: 'اكتمل نسخ التطبيقات',
        appBackupProgress: 'تقدم نسخ التطبيقات',
        installAppsTitle: 'توجد نسخ تطبيقات في هذا المجلد',
        installAppsHint: 'هذه التطبيقات نُسخت سابقاً من هاتف. حدّد ما تريده ثم ثبّته — يتم تثبيت أجزاء Split APK معاً تلقائياً على الهاتف الموصول.',
        installSelected: 'تثبيت المحدد',
        installNoneSelected: 'حدّد تطبيقاً واحداً على الأقل للتثبيت.',
        installProgress: 'جارٍ تثبيت التطبيقات',
        installDone: 'اكتمل تثبيت التطبيقات',
        recoverySelectAll: 'تحديد الكل',
        recoverySaveSelected: 'حفظ المحدد على الحاسوب…',
        recoveryRestoreSelected: 'استعادة المحدد في الهاتف…',
        recoveryNoneSelected: 'اختر ملفاً واحداً على الأقل أولاً.',
        recoveryWorking: 'جارٍ العمل…',
        recoverySavedAll: 'تم الحفظ',
        recoveryRestoredAll: 'تم النسخ إلى',
        filesStorage: 'التخزين',
        filesInternal: 'الذاكرة الداخلية',
        filesSdCard: 'بطاقة الذاكرة',
        filesUsed: 'مستخدم',
        filesFree: 'متبقي',
        filesStorageUnknown: 'الحجم غير متاح',
        zipContents: 'محتويات الملف المضغوط',
        zipEntries: 'عنصراً',
        zipBack: 'العودة إلى الملف المضغوط',
        zipOpenHint: 'اضغط على ملف داخل الأرشيف لمعاينته.',
        zipEmpty: 'الأرشيف فارغ.',
        recoveryThumbHint: 'تُحمّل المصغرات أثناء التمرير',
        onbConnectTitle: 'وصّل هاتفك',
        onbConnectDesc: 'وصّل هاتف أندرويد بهذا الحاسوب عبر كابل USB واتركه مفتوحاً.',
        onbConnectHint: 'في انتظار جهاز…',
        onbNoPhoneYet: 'لم يتم العثور على هاتف أندرويد بعد.',
        onbUsbDevices: 'أجهزة USB على هذا الحاسوب',
        onbUsbDetected: 'تم العثور على هاتف عبر USB',
        onbEnableTitle: 'تم العثور على الهاتف — فعّل تصحيح USB',
        onbEnableDesc: 'الهاتف موصول لكن تصحيح USB لا يزال معطلاً، لذلك لا يمكن قراءة بياناته.',
        onbUsbModeHint: 'ملاحظة: اضغط على إشعار USB في الهاتف واختر «نقل الملفات / MTP» ليبقى الاتصال فعّالاً.',
        onbDone: 'لقد فعّلت تصحيح USB',
        onbAuthorizeTitle: 'في انتظار موافقتك',
        onbAuthorizeDesc: 'انظر إلى شاشة الهاتف واضغط «السماح» في رسالة «السماح بتصحيح أخطاء USB؟».',
        onbAuthorizeHint: 'لم تظهر الرسالة؟ افصل الكابل وأعد توصيله واترك الهاتف مفتوحاً ثم اضغط تحقّق مرة أخرى.',
        onbCheckAgain: 'تحقّق مرة أخرى',
        onbGettingReady: 'جارٍ تجهيز البيانات',
        onbPreparingDesc: 'قراءة التطبيقات المثبّتة، وتجهيز متصفح الملفات، واستخراج أيقونات التطبيقات.',
        onbAdbMissingTitle: 'أداة ADB غير موجودة',
        onbAdbMissingDesc: 'ثبّت Android SDK Platform-Tools ليتوفر أمر «adb» ثم أعد المحاولة.',
        onbOfflineDesc: 'الهاتف موصول لكن ADB لا يستطيع التواصل معه بعد. افصل الكابل وأعد توصيله ثم أعد المحاولة.',
        onbSkip: 'تخطٍ الآن',
        onbRetry: 'إعادة المحاولة',
        onbReadyTitle: 'الجهاز جاهز',
        onbReadyDesc: 'الهاتف موصول ومصرّح به.',
        onbLoadData: 'تحميل التطبيقات والملفات',
        onbDeviceLabel: 'الجهاز',
        onbErrorTitle: 'حدث خطأ ما',
        onbReconnect: 'إعداد جهاز',
        onbOfflineTitle: 'جارٍ الاتصال بالهاتف…',
        iconSource: 'مصدر الأيقونات',
        iconSourceFast: 'سريع — قراءة من الجهاز',
        iconSourceApk: 'سحب ملفات APK — تطبيقات المستخدم فقط',
        iconSourceHint: 'الوضع السريع يسحب ملف الأيقونة فقط من الهاتف. سحب APK ينسخ ملف APK كامل لكل تطبيق مستخدم إلى مجلد ثم يقرأ الأيقونة منها — أبطأ مرة واحدة ثم يُخزّن.',
        apkFolderLabel: 'مجلد ملفات APK المسحوبة',
        apkFolderDefault: 'مجلد ذاكرة التطبيق الافتراضي',
        extractIcons: 'استخراج كل الأيقونات',
        extractingIcons: 'جارٍ استخراج الأيقونات…',
        iconsExtracted: 'أيقونة مستخرجة',
        pullApkConfirmTitle: 'سحب ملفات APK من الهاتف؟',
        pullApkConfirmBody: 'سيتم نسخ ملفات APK لتطبيقات المستخدم إلى:\n{folder}\nواستخراج أيقوناتها. قد يستغرق الأمر وقتاً أول مرة، ثم تُعاد الملفات المنسوخة في المرات التالية.',
        systemAppIconNote: 'تُستخدم أيقونة أندرويد فقط عندما لا يمكن قراءة أيقونة التطبيق.',
        loadingFromCache: 'تم التحميل من الذاكرة المؤقتة',
    },
};

/* ------------------------------------------------------------------ *
 * Small utilities
 * ------------------------------------------------------------------ */

const state = {
    lang: 'en',
    view: 'dashboard',
    token: 0,
    timers: [],
    apps: {
        list: null, search: '', safety: 'all', type: 'all', sort: 'name',
        visible: 60, icons: new Map(), iconInflight: new Map(),
        iconOptions: { mode: 'fast', folder: '', workers: 6 },
    },
    // Onboarding gate shown before any device data is read.
    onboarding: {
        active: false, stage: 'no_usb', state: null, pollTimer: null,
        preparing: false, progress: null, error: '', skipped: false, done: false,
    },
    // Cached device data (apps + file listings + icons) for instant rendering.
    session: null,
    genericIcon: '',
    backup: {
        categories: null, seeded: false, selected: new Set(),
        target: '', result: null, localFolder: '',
        customFolders: [], customDraft: '',
        appsSelected: new Set(), appsSearch: '',
        installSelected: new Set(),
    },
    recovery: {
        mode: null, query: '', deep: false, results: null, scanning: false, sizes: {},
        selected: new Set(),
    },
    files: { path: '/sdcard', cache: new Map(), sizes: {} },
    transferHandler: null,
};

function t(key) {
    const table = translations[state.lang] || {};
    if (table[key] !== undefined) return table[key];
    if (translations.en[key] !== undefined) return translations.en[key];
    return key;
}

function escapeHtml(value) {
    return String(value === undefined || value === null ? '' : value)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
}

function formatBytes(bytes) {
    const value = Number(bytes);
    if (!Number.isFinite(value) || value <= 0) return '0 B';
    const units = ['B', 'KB', 'MB', 'GB', 'TB'];
    let n = value;
    let i = 0;
    while (n >= 1024 && i < units.length - 1) { n /= 1024; i += 1; }
    return (i === 0 ? n.toFixed(0) : n.toFixed(1)) + ' ' + units[i];
}

async function ensureDefaultBackupFolders() {
    try {
        const folder = await DefaultBackupFolder();
        if (!folder) return;
        const isLegacyRelative = (value) => !value || value === './device-backup' || value.startsWith('.');
        if (isLegacyRelative(state.backup.target)) state.backup.target = folder;
        if (isLegacyRelative(state.backup.localFolder)) state.backup.localFolder = folder;
    } catch (err) {
        // The Go-side default still applies when this is unavailable.
    }
}

// Bounded-concurrency task runner so parallel adb-driven calls stay polite.
function createLimiter(max) {
    let active = 0;
    const queue = [];
    const next = () => {
        if (active >= max || queue.length === 0) return;
        active += 1;
        const job = queue.shift();
        job().finally(() => { active -= 1; next(); });
    };
    return function run(fn) {
        return new Promise((resolve, reject) => {
            queue.push(() => fn().then(resolve, reject));
            next();
        });
    };
}

/* ------------------------------------------------------------------ *
 * Modal + toast helpers
 * ------------------------------------------------------------------ */

function openModal({ title, body, footer, wide, onClose }) {
    const root = document.getElementById('modal-root');
    const wrapper = document.createElement('div');
    wrapper.className = 'fixed inset-0 z-[70] flex items-center justify-center bg-black/70 backdrop-blur-sm p-6';
    wrapper.innerHTML = `
        <div class="w-full ${wide ? 'max-w-4xl' : 'max-w-lg'} max-h-[90vh] overflow-y-auto bg-[#141821] border border-white/10 rounded-2xl shadow-2xl">
            <div class="flex items-center justify-between px-5 py-4 border-b border-white/10 sticky top-0 bg-[#141821] z-10">
                <h3 class="text-lg font-semibold">${escapeHtml(title)}</h3>
                <button data-modal-close class="text-gray-400 hover:text-white text-2xl leading-none px-2">&times;</button>
            </div>
            <div class="p-5" data-modal-body></div>
            <div class="px-5 py-4 border-t border-white/10 flex justify-end gap-2" data-modal-footer></div>
        </div>
    `;
    root.appendChild(wrapper);

    const bodyEl = wrapper.querySelector('[data-modal-body]');
    const footerEl = wrapper.querySelector('[data-modal-footer]');
    if (typeof body === 'string') bodyEl.innerHTML = body; else if (body) bodyEl.appendChild(body);
    if (footer) footerEl.innerHTML = footer; else footerEl.remove();

    const close = () => { wrapper.remove(); if (onClose) onClose(); };
    wrapper.querySelector('[data-modal-close]').addEventListener('click', close);
    wrapper.addEventListener('click', (event) => { if (event.target === wrapper) close(); });
    return { close, wrapper, body: bodyEl, footer: footerEl };
}

function confirmDialog(message, confirmLabel) {
    return new Promise((resolve) => {
        let settled = false;
        const finish = (value) => {
            if (settled) return;
            settled = true;
            resolve(value);
        };
        // The footer has to be handed to openModal: it removes an empty footer, so
        // filling modal.footer afterwards wrote the buttons into a detached node.
        // The dialog then had no Cancel/Confirm at all and its promise never
        // resolved — Uninstall, Install selected, Disable and every other
        // confirmation silently did nothing.
        const modal = openModal({
            title: confirmLabel || t('confirmUninstall'),
            body: `<p class="text-gray-300 leading-relaxed whitespace-pre-line">${escapeHtml(message)}</p>`,
            footer: `
                <button data-no class="px-4 py-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10">${escapeHtml(t('cancel'))}</button>
                <button data-yes class="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 font-medium">${escapeHtml(confirmLabel || t('backupStart'))}</button>
            `,
            // Dismissing with the X (or the backdrop) counts as "no" instead of
            // leaving the caller waiting forever.
            onClose: () => finish(false),
        });
        modal.footer.querySelector('[data-no]').addEventListener('click', () => { finish(false); modal.close(); });
        modal.footer.querySelector('[data-yes]').addEventListener('click', () => { finish(true); modal.close(); });
    });
}

function pickAndroidFolder(startPath = '/sdcard') {
    return new Promise((resolve) => {
        let current = startPath || '/sdcard';
        let settled = false;
        const done = (value) => {
            if (settled) return;
            settled = true;
            modal.close();
            resolve(value || '');
        };
        const modal = openModal({
            title: t('backupPickPhoneFolder'),
            wide: true,
            body: `
                <p class="text-xs text-gray-500 mb-3">${escapeHtml(t('backupFolderPickHint'))}</p>
                <div class="flex items-center gap-2 mb-3">
                    <button data-up class="px-3 py-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-sm">${escapeHtml(t('filesUp'))}</button>
                    <div data-path class="flex-1 min-w-0 bg-white/5 border border-white/10 rounded-xl px-3 py-2 text-sm text-gray-200 truncate"></div>
                </div>
                <div data-list class="max-h-[52vh] overflow-y-auto scroll-area space-y-1"></div>
            `,
            footer: `
                <button data-cancel class="px-4 py-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10">${escapeHtml(t('cancel'))}</button>
                <button data-use class="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 font-medium">${escapeHtml(t('backupUseThisFolder'))}</button>
            `,
        });

        const pathEl = modal.body.querySelector('[data-path]');
        const listEl = modal.body.querySelector('[data-list]');
        const upBtn = modal.body.querySelector('[data-up]');

        const parentPath = (path) => {
            const clean = (path || '/').replace(/\/+$/, '') || '/';
            if (clean === '/') return '/';
            const idx = clean.lastIndexOf('/');
            return idx <= 0 ? '/' : clean.slice(0, idx);
        };

        const load = async (path) => {
            current = (path || '/sdcard').replace(/\\/g, '/').replace(/\/+$/, '') || '/';
            pathEl.textContent = current;
            listEl.innerHTML = `
                <div class="flex items-center gap-3 text-gray-400 py-4">
                    <svg class="w-5 h-5 animate-spin text-blue-400" viewBox="0 0 24 24" fill="none">
                        <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                        <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z"></path>
                    </svg>
                    <span>${escapeHtml(t('loadingData'))}</span>
                </div>`;
            try {
                const entries = await ListAndroidFiles(current);
                const dirs = (entries || [])
                    .filter((entry) => entry.isDir)
                    .sort((a, b) => (a.name || '').localeCompare(b.name || ''));
                listEl.innerHTML = dirs.length ? dirs.map((entry) => `
                    <button data-folder="${escapeHtml(entry.path)}" class="w-full flex items-center gap-3 px-3 py-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-left">
                        <span class="w-8 h-8 rounded-lg bg-blue-500/15 text-blue-200 flex items-center justify-center shrink-0">/</span>
                        <span class="min-w-0">
                            <span class="block text-sm truncate">${escapeHtml(entry.name)}</span>
                            <span class="block text-[10px] text-gray-500 truncate">${escapeHtml(entry.path)}</span>
                        </span>
                    </button>`).join('') : `<div class="text-xs text-gray-500 py-3">${escapeHtml(t('backupEmptyFolder'))}</div>`;
                listEl.querySelectorAll('[data-folder]').forEach((button) => {
                    button.addEventListener('click', () => load(button.dataset.folder));
                });
            } catch (err) {
                listEl.innerHTML = `<div class="text-sm text-red-300 py-3">${escapeHtml(t('backupFolderLoadError'))}</div>`;
            }
        };

        upBtn.addEventListener('click', () => load(parentPath(current)));
        modal.footer.querySelector('[data-cancel]').addEventListener('click', () => done(''));
        modal.footer.querySelector('[data-use]').addEventListener('click', () => done(current));
        modal.wrapper.addEventListener('click', (event) => {
            if (event.target === modal.wrapper || event.target.closest('[data-modal-close]')) resolve('');
        }, { capture: true, once: true });
        load(current);
    });
}

function toast(message, kind = 'info') {
    const root = document.getElementById('toast-root');
    if (!root) return;
    const colors = {
        info: 'bg-white/10 border-white/15',
        success: 'bg-emerald-600/20 border-emerald-400/30 text-emerald-100',
        error: 'bg-red-600/20 border-red-400/30 text-red-100',
    };
    const el = document.createElement('div');
    el.className = `px-4 py-3 rounded-xl border backdrop-blur-md text-sm shadow-lg max-w-sm ${colors[kind] || colors.info}`;
    el.textContent = message;
    root.appendChild(el);
    setTimeout(() => el.remove(), 4500);
}

/* ------------------------------------------------------------------ *
 * Router — every async view checks token + view before touching the DOM
 * ------------------------------------------------------------------ */

function isValidView(token, view) {
    return token === state.token && state.view === view;
}

function viewContent() {
    return document.getElementById('view-content');
}

// A neutral placeholder shown while the device data is still being read, so the
// UI never flashes an empty/partial screen.
function loadingCard(title, message) {
    return `
        <div class="bg-white/5 border border-white/10 backdrop-blur-xl rounded-2xl p-6 col-span-full">
            <h2 class="text-2xl font-semibold mb-2">${escapeHtml(title)}</h2>
            <div class="flex items-center gap-3 text-gray-400 mt-4">
                <svg class="w-5 h-5 animate-spin text-blue-400" viewBox="0 0 24 24" fill="none">
                    <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                    <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z"></path>
                </svg>
                <span>${escapeHtml(message || t('loadingData'))}</span>
            </div>
        </div>`;
}

function errorCard(title, message) {
    return `
        <div class="bg-white/5 border border-white/10 backdrop-blur-xl rounded-2xl p-6 col-span-full">
            <h2 class="text-2xl font-semibold mb-2">${escapeHtml(title)}</h2>
            <p class="text-red-400">${escapeHtml(message)}</p>
        </div>`;
}

function setViewHtml(token, view, html) {
    if (!isValidView(token, view)) return false;
    const el = viewContent();
    if (!el) return false;
    el.innerHTML = html;
    return true;
}

function clearTimers() {
    state.timers.forEach((id) => clearInterval(id));
    state.timers = [];
}

// Long listings used to leave the main pane scrolled past the new (shorter)
// content, which made the browser look "stuck" with folders off-screen.
function resetMainScroll() {
    const main = document.querySelector('main');
    if (main) main.scrollTop = 0;
}

function navigate(view) {
    state.view = view;
    state.token += 1;
    clearTimers();
    state.transferHandler = null;
    document.querySelectorAll('.nav-item').forEach((item) => {
        const isActive = item.dataset.view === view;
        item.classList.toggle('active', isActive);
        item.classList.toggle('bg-blue-600', isActive);
        item.classList.toggle('text-white', isActive);
        item.classList.toggle('text-gray-400', !isActive);
    });
    const title = document.getElementById('view-title');
    if (title) title.innerText = t(view);
    const content = viewContent();
    if (content) content.innerHTML = '';
    resetMainScroll();
    renderView(view, state.token);
}

function renderView(view, token) {
    switch (view) {
        case 'dashboard': renderDashboard(token); break;
        case 'guide': renderGuide(token); break;
        case 'apps': renderApps(token); break;
        case 'backup': renderBackup(token); break;
        case 'tasks': renderRecovery(token); break;
        case 'files': renderFiles(token); break;
        default: renderDashboard(token);
    }
}

/* ------------------------------------------------------------------ *
 * Dashboard + guide + logs
 * ------------------------------------------------------------------ */

async function requireDevice(token, view) {
    try {
        const devices = await GetConnectedDevices();
        if (!isValidView(token, view)) return null;
        if (!devices || devices.length === 0) {
            setViewHtml(token, view, `
                <div class="bg-white/5 border border-white/10 backdrop-blur-xl rounded-2xl p-6 col-span-full">
                    <h2 class="text-2xl font-semibold mb-2">${escapeHtml(t(view))}</h2>
                    <p class="text-gray-400">${escapeHtml(t('selectDevicePrompt'))}</p>
                </div>`);
            return null;
        }
        return devices;
    } catch (err) {
        if (!isValidView(token, view)) return null;
        setViewHtml(token, view, `
            <div class="bg-white/5 border border-white/10 backdrop-blur-xl rounded-2xl p-6 col-span-full">
                <h2 class="text-2xl font-semibold mb-2">${escapeHtml(t(view))}</h2>
                <p class="text-red-400">${escapeHtml(err.message || String(err))}</p>
            </div>`);
        return null;
    }
}

function deviceStatusBadge(connected, count) {
    const dot = document.getElementById('device-dot');
    const text = document.getElementById('device-text');
    if (dot) {
        dot.classList.toggle('bg-emerald-500', connected);
        dot.classList.toggle('bg-red-500', !connected);
    }
    if (text) text.innerText = connected ? `${count} ${t('connectedDevices')}` : t('disconnected');
}

function renderDashboard(token) {
    if (!setViewHtml(token, 'dashboard', `
        <div class="bg-white/5 border border-white/10 backdrop-blur-xl rounded-2xl p-6 col-span-full">
            <h2 class="text-2xl font-semibold mb-3">${escapeHtml(t('welcomeTitle'))}</h2>
            <p class="text-gray-400 leading-relaxed">${escapeHtml(t('welcomeDesc'))}</p>
            <div id="devices-list" class="mt-6 text-gray-400">${escapeHtml(t('loading'))}</div>
        </div>`)) return;
    scanDevices(token, 'dashboard');
}

async function scanDevices(token, view) {
    const refreshBtn = document.getElementById('refresh-btn');
    if (refreshBtn) refreshBtn.innerText = t('scanning');
    try {
        const devices = await GetConnectedDevices();
        if (!isValidView(token, view)) return;
        if (devices && devices.length > 0) {
            deviceStatusBadge(true, devices.length);
            const list = document.getElementById('devices-list');
            if (list) {
                list.innerHTML = '<ul class="space-y-3">' + devices.map((dev) => `
                    <li class="bg-white/5 p-4 rounded-xl flex justify-between items-center border border-white/5">
                        <div>
                            <strong class="text-lg">${escapeHtml(dev.model || t('unknown'))}</strong><br>
                            <small class="text-gray-400">ID: ${escapeHtml(dev.id)}</small>
                        </div>
                        <span class="text-emerald-400 font-medium px-3 py-1 bg-emerald-400/10 rounded-full">${escapeHtml(dev.status)}</span>
                    </li>`).join('') + '</ul>';
            }
        } else {
            deviceStatusBadge(false, 0);
            const list = document.getElementById('devices-list');
            if (list) list.innerHTML = `<p class="text-red-400">${escapeHtml(t('noDevices'))}</p>`;
        }
    } catch (err) {
        if (!isValidView(token, view)) return;
        deviceStatusBadge(false, 0);
        const list = document.getElementById('devices-list');
        if (list) list.innerHTML = `<p class="text-red-400">${escapeHtml(t('errorChecking'))} ${escapeHtml(err.message || String(err))}</p>`;
    } finally {
        if (refreshBtn) refreshBtn.innerText = t('scan');
    }
}

function renderGuide(token) {
    const steps = [1, 2, 3, 4].map((n) => `
        <div class="flex items-start">
            <div class="flex-shrink-0 w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center font-bold">${n}</div>
            <div class="ml-4 rtl:ml-0 rtl:mr-4">
                <h3 class="text-lg font-medium text-white">${escapeHtml(t('step' + n + 'Title'))}</h3>
                <p class="mt-1 text-gray-400">${escapeHtml(t('step' + n + 'Desc'))}</p>
            </div>
        </div>`).join('');
    const ok = setViewHtml(token, 'guide', `
        <div class="bg-white/5 border border-white/10 backdrop-blur-xl rounded-2xl p-6 col-span-full">
            <h2 class="text-2xl font-semibold mb-6">${escapeHtml(t('enableDevMode'))}</h2>
            <div class="space-y-6">${steps}</div>
            <p class="text-xs text-amber-300 mt-6 leading-relaxed">${escapeHtml(t('onbUsbModeHint'))}</p>
            <button id="guide-setup" class="mt-5 px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 font-medium">${escapeHtml(t('onbReconnect'))}</button>
        </div>`);
    if (!ok) return;
    const setup = document.getElementById('guide-setup');
    if (setup) setup.addEventListener('click', () => showOnboarding());
}

/* ------------------------------------------------------------------ *
 * App manager: filters + lazy parallel icons
 * ------------------------------------------------------------------ */

// Risk levels drive both the badge colour and whether uninstall is allowed:
//   danger      -> red, removal is blocked (flagged unsafe)
//   recommended -> green, safe to remove
//   safe/unknown -> neutral
function appRisk(app) {
    const rec = (app.recommended || '').toLowerCase();
    if (!app.recommended || rec.includes('no recommendation')) return 'unknown';
    if (rec.includes('unsafe') || rec.includes('do not') || rec.includes('danger') || rec.includes('keep')) return 'danger';
    if (rec.includes('recommend') || rec.includes('remove') || rec.includes('delete') || rec.includes('caution') || rec.includes('advanced')) return 'recommended';
    if (rec.includes('safe') || rec.includes('no side effect')) return 'safe';
    return 'unknown';
}

function riskLabel(risk) {
    switch (risk) {
        case 'danger': return t('riskDanger');
        case 'recommended': return t('riskRecommended');
        case 'safe': return t('riskSafe');
        default: return t('riskUnknown');
    }
}

function isVisibleInstalledUserApp(app, risk) {
    if (!app.isThirdParty) return false;
    // Keep service/helper packages loaded so the recommendation filter can still
    // surface removals, but keep the normal Installed user apps view focused on
    // real launcher apps.
    if (risk === 'recommended') return true;
    if (app.isServiceLike) return false;
    if (app.isLaunchable === false) return false;
    return true;
}

function filteredApps() {
    const data = state.apps;
    const query = data.search.trim().toLowerCase();
    let list = (data.list || []).filter((app) => {
        const risk = appRisk(app);
        if (query) {
            const hay = `${app.name || ''} ${app.packageName || ''}`.toLowerCase();
            if (!hay.includes(query)) return false;
        }
        if (data.safety !== 'all' && risk !== data.safety) return false;
        if (data.type === 'user' && !isVisibleInstalledUserApp(app, risk)) return false;
        if (data.type === 'system' && app.isThirdParty) return false;
        return true;
    });
    const sorters = {
        name: (a, b) => (a.name || '').localeCompare(b.name || ''),
        package: (a, b) => (a.packageName || '').localeCompare(b.packageName || ''),
        risk: (a, b) => String(appRisk(a)).localeCompare(String(appRisk(b))),
    };
    list = list.slice().sort(sorters[data.sort] || sorters.name);
    return list;
}

function iconSlotMarkup(app) {
    const url = state.apps.icons.get(app.packageName);
    const letter = (app.name || app.packageName || 'A').charAt(0).toUpperCase();
    if (url) {
        return `<img src="${url}" alt="" class="w-11 h-11 rounded-xl object-cover bg-white/5" />`;
    }
    return `<div class="w-11 h-11 rounded-xl bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center font-bold text-white" data-icon-fallback="${escapeHtml(app.packageName)}">${escapeHtml(letter)}</div>`;
}

function appRowsMarkup(list, token) {
    return list.map((app) => {
        const risk = appRisk(app);
        const tone = risk === 'danger' ? 'text-red-300'
            : risk === 'recommended' ? 'text-emerald-300'
                : risk === 'safe' ? 'text-gray-300' : 'text-gray-400';
        const badge = risk === 'danger' ? 'bg-red-500/20 text-red-300'
            : risk === 'recommended' ? 'bg-emerald-500/20 text-emerald-300'
                : 'bg-white/10 text-gray-300';
        const blocked = risk === 'danger';
        const enableButton = `<button data-toggle-disable class="app-disable-btn rounded-full px-3 py-1.5 text-xs font-medium ${app.isDisabled ? 'bg-blue-500/20 text-blue-200 hover:bg-blue-500/30' : 'bg-white/10 text-gray-200 hover:bg-white/20'}">${escapeHtml(app.isDisabled ? t('enable') : t('disable'))}</button>`;
        let actions;
        if (blocked && app.isDisabled) {
            // A danger-flagged app still needs a way back if it was disabled before.
            actions = enableButton;
        } else if (blocked) {
            // Removal stays blocked, but not as a dead element: clicking used to
            // do nothing at all, which reads as a broken Uninstall button.
            actions = `<button data-uninstall-blocked title="${escapeHtml(t('uninstallBlockedHint'))}" class="app-blocked-btn rounded-full px-3 py-1.5 text-xs font-medium bg-red-500/20 text-red-300 hover:bg-red-500/30">${escapeHtml(t('uninstallBlocked'))}</button>`;
        } else {
            actions = `<div class="flex items-center gap-2 shrink-0">
                ${enableButton}
                <button data-uninstall class="app-remove-btn rounded-full px-3 py-1.5 text-xs font-medium ${risk === 'recommended' ? 'bg-emerald-500/20 text-emerald-300 hover:bg-emerald-500/30' : 'bg-white/10 text-gray-200 hover:bg-white/20'}">${escapeHtml(t('uninstall'))}</button>
            </div>`;
        }
        return `
            <div class="app-row bg-white/5 border border-white/10 rounded-xl p-4 flex items-center justify-between gap-4"
                 data-package="${escapeHtml(app.packageName)}" data-path="${escapeHtml(app.path || '')}"
                 data-verified="false">
                <div class="flex items-center gap-3 min-w-0">
                    <div data-icon-host="${escapeHtml(app.packageName)}">${iconSlotMarkup(app)}</div>
                    <div class="min-w-0">
                        <div class="font-semibold text-white truncate">${escapeHtml(app.name || app.packageName)}</div>
                        <div class="text-xs text-gray-400 truncate">${escapeHtml(app.packageName)}</div>
                        <div class="text-xs mt-1 flex items-center gap-2">
                            <span class="px-2 py-0.5 rounded-full ${badge}">${escapeHtml(riskLabel(risk))}</span>
                            <span class="${tone}">${escapeHtml(app.isThirdParty ? t('filterUserOnly') : t('filterSystemOnly'))}</span>
                            ${app.isDisabled ? `<span class="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-200">${escapeHtml(t('disabledState'))}</span>` : ''}
                        </div>
                    </div>
                </div>
                ${actions}
            </div>`;
    }).join('');
}

let iconObserver = null;

function applyIcon(packageName, url, token) {
    if (!isValidView(token, 'apps')) return;
    document.querySelectorAll('[data-icon-host]').forEach((host) => {
        if (host.dataset.iconHost !== packageName) return;
        if (url) {
            host.innerHTML = `<img src="${url}" alt="" class="w-11 h-11 rounded-xl object-cover bg-white/5" />`;
        }
    });
}

// The generic Android icon is fetched once and shared by every system app.
let genericIconPromise = null;

function ensureGenericIcon() {
    if (state.genericIcon) return Promise.resolve(state.genericIcon);
    if (!genericIconPromise) {
        genericIconPromise = GetSystemAppIcon()
            .then((url) => { state.genericIcon = url || ''; return state.genericIcon; })
            .catch(() => '');
    }
    return genericIconPromise;
}

function ensureIcon(app, token) {
    const data = state.apps;
    if (data.icons.has(app.packageName)) return Promise.resolve(data.icons.get(app.packageName));
    if (data.iconInflight.has(app.packageName)) return data.iconInflight.get(app.packageName);

    const promise = iconLimiter(() => GetAppIcon(app.packageName, app.path || ''))
        .then((url) => {
            data.icons.set(app.packageName, url || '');
            data.iconInflight.delete(app.packageName);
            if (url) applyIcon(app.packageName, url, token);
            return url || '';
        })
        .catch(() => {
            // Device unreachable for this row: show the Android icon instead.
            return ensureGenericIcon().then((url) => {
                data.iconInflight.delete(app.packageName);
                if (url) {
                    data.icons.set(app.packageName, url);
                    applyIcon(app.packageName, url, token);
                }
                return url;
            });
        });
    data.iconInflight.set(app.packageName, promise);
    return promise;
}

const iconLimiter = createLimiter(4);

function setupIconLoading(token) {
    if (iconObserver) { iconObserver.disconnect(); iconObserver = null; }
    const byPackage = new Map((state.apps.list || []).map((app) => [app.packageName, app]));

    iconObserver = new IntersectionObserver((entries) => {
        entries.forEach((entry) => {
            if (!entry.isIntersecting) return;
            const row = entry.target;
            const pkg = row.dataset.package;
            const app = byPackage.get(pkg);
            if (!app) return;
            if (state.apps.icons.has(pkg)) {
                iconObserver.unobserve(row);
                return;
            }
            ensureIcon(app, token).then((url) => { if (url) iconObserver.unobserve(row); });
        });
    }, { root: null, rootMargin: '200px' });

    document.querySelectorAll('[data-icon-host]').forEach((host) => {
        const row = host.closest('.app-row');
        if (row && row.dataset.verified === 'false') iconObserver.observe(row);
    });
}

function renderAppsListInto(token) {
    if (!isValidView(token, 'apps')) return;
    const list = filteredApps();
    const shown = list.slice(0, state.apps.visible);
    const container = document.getElementById('apps-rows');
    const summary = document.getElementById('apps-summary');
    const moreWrap = document.getElementById('apps-more');
    if (!container) return;

    container.innerHTML = shown.length ? appRowsMarkup(shown, token) : `<div class="text-gray-400 p-4">${escapeHtml(t('noAppsMatch'))}</div>`;
    if (summary) {
        summary.textContent = `${t('showing')} ${shown.length} ${t('of')} ${list.length} • ${state.apps.icons.size} ${t('iconsCached')}`;
    }
    if (moreWrap) {
        moreWrap.innerHTML = list.length > shown.length
            ? `<button id="apps-more-btn" class="mt-4 px-4 py-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10">${escapeHtml(t('loadMore'))} (${list.length - shown.length})</button>`
            : '';
        const btn = document.getElementById('apps-more-btn');
        if (btn) btn.addEventListener('click', () => {
            state.apps.visible += 80;
            renderAppsListInto(token);
            bindAppRowActions(token);
            setupIconLoading(token);
        });
    }

    bindAppRowActions(token);
    setupIconLoading(token);
}

function bindAppRowActions(token) {
    document.querySelectorAll('.app-disable-btn').forEach((button) => {
        if (button.dataset.bound === 'true') return;
        button.dataset.bound = 'true';
        button.addEventListener('click', async () => {
            const row = button.closest('.app-row');
            if (!row) return;
            const pkg = row.dataset.package;
            const app = (state.apps.list || []).find((a) => a.packageName === pkg);
            if (!app) return;
            const enabling = !!app.isDisabled;
            if (!enabling) {
                const ok = await confirmDialog(`${t('confirmDisable')}\n\n${pkg}`, t('disable'));
                if (!ok) return;
            }
            const label = button.textContent;
            button.textContent = '…';
            try {
                // Unsafe apps never reach this handler (their row shows no button).
                const unsafe = appRisk(app) === 'danger';
                if (enabling) await EnableApp(pkg);
                else await DisableApp(pkg, unsafe);
                app.isDisabled = !enabling;
                renderAppsListInto(token);
                toast(`${pkg} — ${enabling ? t('enable') : t('disable')}`, 'success');
            } catch (err) {
                button.textContent = label;
                toast(err.message || String(err), 'error');
            }
        });
    });

    // Apps the local database flags as unsafe keep their Uninstall disabled, and
    // the click says why instead of silently doing nothing.
    document.querySelectorAll('.app-blocked-btn').forEach((button) => {
        if (button.dataset.bound === 'true') return;
        button.dataset.bound = 'true';
        button.addEventListener('click', () => {
            const row = button.closest('.app-row');
            const pkg = row ? row.dataset.package : '';
            // The footer must be passed in: openModal drops it when it is empty.
            const modal = openModal({
                title: t('uninstallBlocked'),
                body: `<p class="text-gray-300 leading-relaxed whitespace-pre-line">${escapeHtml(`${t('uninstallBlockedHint')}\n\n${pkg}`)}</p>`,
                footer: `<button data-close-info class="px-4 py-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10">${escapeHtml(t('close'))}</button>`,
            });
            modal.footer.querySelector('[data-close-info]').addEventListener('click', () => modal.close());
        });
    });

    document.querySelectorAll('.app-remove-btn').forEach((button) => {
        if (button.dataset.bound === 'true') return;
        button.dataset.bound = 'true';
        button.addEventListener('click', async () => {
            const row = button.closest('.app-row');
            if (!row) return;
            const pkg = row.dataset.package;
            const app = (state.apps.list || []).find((a) => a.packageName === pkg);
            const ok = await confirmDialog(`${t('confirmUninstall')}\n\n${pkg}`, t('uninstall'));
            if (!ok) return;
            button.textContent = '…';
            try {
                // Unsafe apps never reach this handler (their button is disabled).
                const unsafe = app ? appRisk(app) === 'danger' : false;
                await UninstallApp(pkg, unsafe);
                row.classList.add('opacity-40');
                button.textContent = '✓';
                if (app) {
                    state.apps.list = state.apps.list.filter((a) => a.packageName !== pkg);
                }
                toast(`${pkg} — ${t('uninstall')}`, 'success');
            } catch (err) {
                button.textContent = t('uninstall');
                toast(err.message || String(err), 'error');
            }
        });
    });
}

function bindAppFilterControls(token) {
    const search = document.getElementById('apps-search');
    const safety = document.getElementById('apps-safety');
    const type = document.getElementById('apps-type');
    const sort = document.getElementById('apps-sort');

    if (search) {
        search.addEventListener('input', () => {
            state.apps.search = search.value;
            state.apps.visible = 60;
            renderAppsListInto(token);
        });
    }
    if (safety) {
        safety.addEventListener('change', () => {
            state.apps.safety = safety.value;
            state.apps.visible = 60;
            renderAppsListInto(token);
        });
    }
    if (type) {
        type.addEventListener('change', () => {
            state.apps.type = type.value;
            state.apps.visible = 60;
            renderAppsListInto(token);
        });
    }
    if (sort) {
        sort.addEventListener('change', () => {
            state.apps.sort = sort.value;
            renderAppsListInto(token);
        });
    }
    const loadAll = document.getElementById('apps-load-icons');
    if (loadAll) {
        loadAll.addEventListener('click', () => {
            loadAll.innerHTML = escapeHtml(t('loadingIcons'));
            const apps = filteredApps().slice(0, state.apps.visible);
            const tasks = apps.map((app) => ensureIcon(app, token));
            Promise.all(tasks).then(() => {
                if (!isValidView(token, 'apps')) return;
                const summary = document.getElementById('apps-summary');
                if (summary) summary.textContent = `${state.apps.icons.size} ${t('iconsCached')}`;
                loadAll.innerHTML = escapeHtml(t('loadAllIcons'));
            });
        });
    }
    const reload = document.getElementById('apps-reload-icons');
    if (reload) {
        reload.addEventListener('click', async () => {
            try {
                await ClearIconCache();
                state.apps.icons.clear();
                state.apps.iconInflight.clear();
                if (!isValidView(token, 'apps')) return;
                renderAppsListInto(token);
                toast(t('reloadIcons'), 'success');
            } catch (err) {
                toast(err.message || String(err), 'error');
            }
        });
    }
}

// seedSessionState pushes cached device data into the UI state so views render
// instantly instead of waiting on adb.
function seedSessionState(session) {
    if (!session) return;
    state.session = session;
    if (Array.isArray(session.apps) && session.apps.length > 0) {
        state.apps.list = session.apps;
    }
    (session.icons || []).forEach((icon) => {
        if (icon && icon.packageName && icon.dataUrl) state.apps.icons.set(icon.packageName, icon.dataUrl);
    });
    const roots = session.fileRoots || {};
    Object.entries(roots).forEach(([path, list]) => {
        if (Array.isArray(list)) state.files.cache.set(path, list);
    });
    if (session.fileRoot) state.files.path = session.fileRoot;
}

async function renderApps(token) {
    const view = 'apps';
    const devices = await requireDevice(token, view);
    if (!devices) return;

    // A cached session already has the app list; only read the device when needed.
    if (!state.apps.list) {
        setViewHtml(token, view, loadingCard(t('apps')));
        try {
            const list = await GetInstalledApps();
            if (!isValidView(token, view)) return;
            state.apps.list = list || [];
        } catch (err) {
            if (!isValidView(token, view)) return;
            setViewHtml(token, view, errorCard(t('apps'), err.message || String(err)));
            return;
        }
    }

    // Native <option> popups ignore page CSS on some WebViews and render
    // white-on-white; inline colours keep every filter readable.
    const optionStyle = 'style="background-color:#171c26;color:#f3f4f6"';
    const selectOptions = (options, current) => options.map(([value, label]) =>
        `<option value="${value}" ${value === current ? 'selected' : ''} ${optionStyle}>${escapeHtml(label)}</option>`).join('');

    const iconOptions = state.apps.iconOptions;
    const ok = setViewHtml(token, view, `
        <div class="bg-white/5 border border-white/10 backdrop-blur-xl rounded-2xl p-6 col-span-full">
            <div class="flex flex-wrap items-center justify-between gap-3 mb-4">
                <h2 class="text-2xl font-semibold">${escapeHtml(t('apps'))}</h2>
                <div class="flex gap-2">
                    <button id="apps-load-icons" class="px-3 py-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-sm">${escapeHtml(t('loadAllIcons'))}</button>
                    <button id="apps-refresh-list" class="px-3 py-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-sm">${escapeHtml(t('refresh'))}</button>
                </div>
            </div>

            <div class="bg-white/[0.03] border border-white/10 rounded-xl p-3 mb-4">
                <div class="flex flex-wrap items-end gap-3">
                    <div>
                        <label class="block text-xs text-gray-400 mb-1">${escapeHtml(t('iconSource'))}</label>
                        <select id="apps-icon-source" class="bg-white/5 border border-white/10 rounded-xl px-3 py-2 text-white">
                            ${selectOptions([['fast', t('iconSourceFast')], ['apk', t('iconSourceApk')]], iconOptions.mode)}
                        </select>
                    </div>
                    <div class="flex-1 min-w-[220px]">
                        <label class="block text-xs text-gray-400 mb-1">${escapeHtml(t('apkFolderLabel'))}</label>
                        <input id="apps-apk-folder" value="${escapeHtml(iconOptions.folder)}" placeholder="${escapeHtml(t('apkFolderDefault'))}"
                               class="w-full bg-white/5 border border-white/10 rounded-xl px-3 py-2 text-white placeholder:text-gray-500" />
                    </div>
                    <button id="apps-extract-icons" class="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 font-medium text-sm">${escapeHtml(t('extractIcons'))}</button>
                    <button id="apps-reload-icons" class="px-3 py-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-sm">${escapeHtml(t('reloadIcons'))}</button>
                </div>
                <p class="text-xs text-gray-500 mt-2">${escapeHtml(t('iconSourceHint'))} ${escapeHtml(t('systemAppIconNote'))}</p>
                <div id="apps-icon-progress" class="text-xs text-emerald-300 mt-1"></div>
            </div>
            <div class="text-xs text-gray-500 mb-4" id="apps-icon-folder"></div>

            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-3 mb-4">
                <input id="apps-search" value="${escapeHtml(state.apps.search)}" placeholder="${escapeHtml(t('appsSearchPlaceholder'))}"
                       class="lg:col-span-2 self-end bg-white/5 border border-white/10 rounded-xl px-3 py-2 text-white placeholder:text-gray-500" />
                <div>
                    <label class="block text-xs text-gray-400 mb-1">${escapeHtml(t('appsSafetyFilter'))}</label>
                    <select id="apps-safety" class="w-full bg-white/5 border border-white/10 rounded-xl px-3 py-2 text-white">
                        ${selectOptions([['all', t('filterAll')], ['recommended', t('filterRecommended')], ['danger', t('filterDanger')], ['safe', t('filterSafe')], ['unknown', t('filterUnknown')]], state.apps.safety)}
                    </select>
                </div>
                <div>
                    <label class="block text-xs text-gray-400 mb-1">${escapeHtml(t('filterTypeLabel'))}</label>
                    <select id="apps-type" class="w-full bg-white/5 border border-white/10 rounded-xl px-3 py-2 text-white">
                        ${selectOptions([['user', t('filterUserOnly')], ['all', t('filterAll')], ['system', t('filterSystemOnly')]], state.apps.type)}
                    </select>
                </div>
                <div>
                    <label class="block text-xs text-gray-400 mb-1">${escapeHtml(t('sortBy'))}</label>
                    <select id="apps-sort" class="w-full bg-white/5 border border-white/10 rounded-xl px-3 py-2 text-white">
                        ${selectOptions([['name', t('sortName')], ['package', t('sortPackage')], ['risk', t('sortRisk')]], state.apps.sort)}
                    </select>
                </div>
            </div>

            <div class="text-xs text-gray-400 mb-3" id="apps-summary"></div>
            <div class="space-y-3" id="apps-rows"></div>
            <div id="apps-more"></div>
        </div>`);
    if (!ok) return;

    renderAppsListInto(token);
    bindAppFilterControls(token);
    bindIconOptions(token);
    loadIconFolderPath();
}

// loadIconFolderPath shows where extracted icons are saved: one image file per
// app, named after its package, in a cache folder the user can open.
function loadIconFolderPath() {
    const placeholder = document.getElementById('apps-icon-folder');
    if (!placeholder) return;
    GetIconFolder()
        .then((folder) => {
            const host = document.getElementById('apps-icon-folder');
            if (!host || !folder) return;
            host.innerHTML = `${escapeHtml(t('iconsFolder'))}: <span class="text-gray-300">${escapeHtml(folder)}</span> <span class="text-gray-600">(${escapeHtml(t('iconsFolderHint'))})</span>`;
        })
        .catch(() => {});
}

// bindIconOptions wires the icon-source controls: choosing to pull APKs for user
// apps, where those APKs are stored, and running the extraction batch.
function bindIconOptions(token) {
    const source = document.getElementById('apps-icon-source');
    const folder = document.getElementById('apps-apk-folder');
    if (source) {
        source.addEventListener('change', () => { state.apps.iconOptions.mode = source.value; });
    }
    if (folder) {
        folder.addEventListener('input', () => { state.apps.iconOptions.folder = folder.value.trim(); });
    }

    const extract = document.getElementById('apps-extract-icons');
    if (extract) {
        extract.addEventListener('click', () => runIconExtraction(token, extract));
    }

    const refreshList = document.getElementById('apps-refresh-list');
    if (refreshList) {
        refreshList.addEventListener('click', async () => {
            refreshList.textContent = t('scanning');
            try {
                const list = await GetInstalledApps();
                if (!isValidView(token, 'apps')) return;
                state.apps.list = list || [];
                renderApps(token);
            } catch (err) {
                refreshList.textContent = t('refresh');
                toast(err.message || String(err), 'error');
            }
        });
    }
}

async function runIconExtraction(token, button) {
    const options = state.apps.iconOptions;
    const packages = filteredApps().map((app) => app.packageName);
    if (packages.length === 0) {
        toast(t('noAppsMatch'), 'error');
        return;
    }

    if (options.mode === 'apk') {
        const message = t('pullApkConfirmBody').replace('{folder}', options.folder || t('apkFolderDefault'));
        const agreed = await confirmDialog(message, t('pullApkConfirmTitle'));
        if (!agreed) return;
    }

    const progress = document.getElementById('apps-icon-progress');
    if (progress) progress.textContent = t('extractingIcons');
    if (button) button.disabled = true;

    try {
        const results = await ExtractAppIcons({
            packages,
            mode: options.mode,
            apkFolder: options.folder || '',
            workers: options.workers,
            skipCached: true,
            genericSystem: false,
        });
        if (!isValidView(token, 'apps')) return;
        (results || []).forEach((result) => {
            if (result && result.packageName && result.dataUrl) {
                state.apps.icons.set(result.packageName, result.dataUrl);
            }
        });
        renderAppsListInto(token);
        const failed = (results || []).filter((result) => result && result.error);
        if (failed.length > 0) {
            toast(`${failed.length}/${(results || []).length} — ${failed[0].error}`, 'error');
        }
        if (progress) progress.textContent = `${state.apps.icons.size} ${t('iconsExtracted')}`;
        toast(`${t('extractIcons')} — ${(results || []).length}`, 'success');
    } catch (err) {
        if (progress) progress.textContent = '';
        toast(err.message || String(err), 'error');
    } finally {
        if (button) button.disabled = false;
    }
}

/* ------------------------------------------------------------------ *
 * Backup & Restore wizard
 * ------------------------------------------------------------------ */

function categoryRow(item, checked) {
    const disabled = !item.available;
    return `
        <label class="flex items-start gap-3 bg-white/5 border border-white/10 rounded-xl p-3 ${disabled ? 'opacity-40' : 'cursor-pointer hover:bg-white/10'}">
            <input type="checkbox" data-category="${escapeHtml(item.id)}" ${checked && !disabled ? 'checked' : ''} ${disabled ? 'disabled' : ''} class="mt-1 accent-blue-500" />
            <span class="min-w-0">
                <span class="block text-white font-medium">${escapeHtml(item.label)}</span>
                <span class="block text-xs text-gray-400">${escapeHtml(item.description || item.remotePath || '')}</span>
            </span>
        </label>`;
}

function transferPanel(operation) {
    const titles = {
        backup: t('backupProgress'),
        restore: t('backupProgress'),
        'app-backup': t('appBackupProgress'),
        install: t('installProgress'),
        export: t('recoveryWorking'),
        'device-restore': t('recoveryWorking'),
    };
    const verbs = {
        backup: t('backup'),
        restore: t('backupRestorePlanTitle'),
        'app-backup': t('appBackupPlanTitle'),
        install: t('installProgress'),
        export: t('saveToPc'),
        'device-restore': t('recoveryRestoreSelected'),
    };
    return `
        <div class="bg-white/5 border border-white/10 backdrop-blur-xl rounded-2xl p-6 col-span-full">
            <h2 class="text-2xl font-semibold mb-1">${escapeHtml(titles[operation] || t('backupProgress'))}</h2>
            <p class="text-gray-400 mb-4">${escapeHtml(verbs[operation] || '')}</p>
            <div class="w-full h-3 bg-white/10 rounded-full overflow-hidden">
                <div id="transfer-bar" class="h-full bg-gradient-to-r from-blue-500 to-emerald-500 transition-all" style="width:0%"></div>
            </div>
            <div class="flex justify-between text-sm text-gray-300 mt-3">
                <span id="transfer-count">0 / 0</span>
                <span id="transfer-bytes">0 B</span>
            </div>
            <div class="text-xs text-gray-500 mt-2 truncate" id="transfer-current"></div>
            <div class="text-xs text-emerald-300 mt-1 truncate" id="transfer-message"></div>
            <div class="text-xs text-red-300 mt-1" id="transfer-failed"></div>
        </div>`;
}

function bindTransferProgress(operation) {
    state.transferHandler = (payload) => {
        if (!payload || payload.operation !== operation) return;
        const bar = document.getElementById('transfer-bar');
        const count = document.getElementById('transfer-count');
        const bytes = document.getElementById('transfer-bytes');
        const current = document.getElementById('transfer-current');
        const message = document.getElementById('transfer-message');
        const failed = document.getElementById('transfer-failed');
        const pct = payload.total > 0 ? Math.min(100, Math.round((payload.completed / payload.total) * 100)) : (payload.phase === 'planning' ? 4 : 0);
        if (bar) bar.style.width = pct + '%';
        if (count) count.textContent = `${payload.completed} / ${payload.total}`;
        if (bytes) bytes.textContent = formatBytes(payload.bytes);
        if (current) current.textContent = payload.current || '';
        if (message) message.textContent = payload.message || '';
        if (failed) failed.textContent = payload.failed ? `${t('backupFailed')}: ${payload.failed}` : '';
    };
}

function resultMarkup(result, doneLabel) {
    // Errors wrap instead of being truncated: the device's reason for a failure
    // (INSTALL_FAILED_…, a pm "Failure […]" line) must stay readable.
    const errors = (result.errors || []).slice(0, 12).map((e) => `<li class="break-words">${escapeHtml(e)}</li>`).join('');
    return `
        <div class="bg-white/5 border border-white/10 backdrop-blur-xl rounded-2xl p-6 col-span-full">
            <h2 class="text-2xl font-semibold mb-3">${escapeHtml(doneLabel)}</h2>
            <div class="grid grid-cols-3 gap-3 mb-4">
                <div class="bg-white/5 rounded-xl p-3"><div class="text-xs text-gray-400">${escapeHtml(t('backupCopied'))}</div><div class="text-xl font-semibold text-emerald-300">${result.copied}</div></div>
                <div class="bg-white/5 rounded-xl p-3"><div class="text-xs text-gray-400">${escapeHtml(t('backupFailed'))}</div><div class="text-xl font-semibold ${result.failed ? 'text-red-300' : 'text-gray-300'}">${result.failed}</div></div>
                <div class="bg-white/5 rounded-xl p-3"><div class="text-xs text-gray-400">${escapeHtml(t('sizeLabel'))}</div><div class="text-xl font-semibold">${formatBytes(result.bytes)}</div></div>
            </div>
            ${result.manifestPath ? `<div class="text-sm text-gray-400 mb-2">${escapeHtml(t('backupManifest'))}: <span class="text-gray-200">${escapeHtml(result.manifestPath)}</span></div>` : ''}
            ${errors ? `<div class="text-xs text-red-300 mt-2"><div class="mb-1">${escapeHtml(t('backupFailed'))}:</div><ul class="list-disc ml-5 space-y-1">${errors}</ul></div>` : ''}
            <button id="backup-restart" class="mt-4 px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 font-medium">${escapeHtml(t('backupRestart'))}</button>
        </div>`;
}

async function renderBackup(token) {
    const view = 'backup';
    const devices = await requireDevice(token, view);
    if (!devices) return;

    if (!state.backup.categories) {
        setViewHtml(token, view, loadingCard(t('backup')));
        try {
            state.backup.categories = await GetBackupCategories();
        } catch (err) {
            if (!isValidView(token, view)) return;
            setViewHtml(token, view, errorCard(t('backup'), err.message || String(err)));
            return;
        }
        if (!isValidView(token, view)) return;
    }
    if (!state.backup.seeded) {
        for (const category of state.backup.categories) {
            if (category.available) state.backup.selected.add(category.id);
        }
        state.backup.seeded = true;
    }
    // The app (APK) backup section needs the app list — reuse the session cache.
    if (!Array.isArray(state.apps.list)) {
        try {
            state.apps.list = await GetInstalledApps();
        } catch (err) {
            state.apps.list = [];
        }
        if (!isValidView(token, view)) return;
    }
    renderBackupStepSelect(token);
}

async function renderBackupStepSelect(token) {
    await ensureDefaultBackupFolders();
    const cats = state.backup.categories || [];
    const selected = state.backup.selected;
    const appList = Array.isArray(state.apps.list) ? state.apps.list : [];
    const ok = setViewHtml(token, 'backup', `
        <div class="bg-white/5 border border-white/10 backdrop-blur-xl rounded-2xl p-6 col-span-full">
            <h2 class="text-2xl font-semibold mb-2">${escapeHtml(t('backup'))}</h2>
            <p class="text-gray-400 mb-5">${escapeHtml(t('backupIntro'))}</p>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-3 mb-5">
                ${cats.map((c) => categoryRow(c, selected.has(c.id))).join('')}
            </div>

            <div class="mb-5">
                <h3 class="text-lg font-medium mb-1">${escapeHtml(t('backupCustom'))}</h3>
                <p class="text-xs text-gray-500 mb-2">${escapeHtml(t('backupCustomHint'))}</p>
                <div class="flex flex-wrap gap-2">
                    <div class="flex-1 min-w-[240px] md:max-w-xl bg-white/5 border border-white/10 rounded-xl px-3 py-2 text-sm text-gray-200">
                        <span class="block text-[10px] uppercase text-gray-500">${escapeHtml(t('backupFolderSelected'))}</span>
                        <span id="backup-custom-display" class="block truncate">${escapeHtml(state.backup.customDraft || t('backupCustomEmpty'))}</span>
                    </div>
                    <button id="backup-custom-browse" class="px-3 py-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-sm">${escapeHtml(t('backupBrowse'))}</button>
                    <button id="backup-custom-add" class="px-4 py-2 rounded-xl bg-white/10 hover:bg-white/20 border border-white/10">${escapeHtml(t('backupAddFolder'))}</button>
                </div>
                <div class="flex flex-wrap gap-2 mt-2" id="backup-custom-list"></div>
            </div>

            ${appList.length > 0 ? `
            <div class="mb-5 bg-white/[0.03] border border-white/10 rounded-xl p-4">
                <div class="flex flex-wrap items-center justify-between gap-2 mb-1">
                    <h3 class="text-lg font-medium">${escapeHtml(t('backupAppsSection'))}</h3>
                    <span id="apps-backup-count" class="text-xs text-blue-300"></span>
                </div>
                <p class="text-xs text-gray-500 mb-3">${escapeHtml(t('backupAppsHint'))}</p>
                <div class="flex flex-wrap gap-2 mb-2">
                    <input id="apps-backup-search" value="${escapeHtml(state.backup.appsSearch)}" placeholder="${escapeHtml(t('backupAppsSearch'))}"
                           class="flex-1 min-w-[200px] bg-white/5 border border-white/10 rounded-xl px-3 py-2 text-white placeholder:text-gray-500" />
                    <button id="apps-backup-all" class="px-3 py-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-sm">${escapeHtml(t('backupAppsSelectAll'))}</button>
                    <button id="apps-backup-clear" class="px-3 py-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-sm">${escapeHtml(t('backupAppsClear'))}</button>
                </div>
                <div id="apps-backup-list" class="grid grid-cols-1 md:grid-cols-2 gap-2 max-h-[320px] overflow-y-auto scroll-area pr-1"></div>
                <button id="apps-backup-start" class="mt-3 px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-700 font-medium">${escapeHtml(t('backupAppsStart'))}</button>
            </div>` : ''}

            <label class="block text-sm text-gray-400 mb-1">${escapeHtml(t('backupTargetFolder'))}</label>
            <div class="flex flex-wrap gap-2 mb-5">
                <input id="backup-target" value="${escapeHtml(state.backup.target)}"
                       class="flex-1 min-w-[240px] md:max-w-md bg-white/5 border border-white/10 rounded-xl px-3 py-2 text-white" />
                <button id="backup-target-browse" class="px-3 py-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-sm">${escapeHtml(t('backupBrowse'))}</button>
            </div>

            <div class="flex flex-wrap gap-2">
                <button id="backup-review" class="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 font-medium">${escapeHtml(t('backupReview'))}</button>
            </div>

            <div class="mt-8 pt-6 border-t border-white/10">
                <h3 class="text-lg font-semibold mb-2">${escapeHtml(t('backupRestorePlanTitle'))}</h3>
                <p class="text-gray-400 mb-3">${escapeHtml(t('backupRestoreIntro'))}</p>
                <label class="block text-sm text-gray-400 mb-1">${escapeHtml(t('backupLocalFolder'))}</label>
                <div class="flex flex-wrap gap-2">
                    <input id="restore-folder" value="${escapeHtml(state.backup.localFolder)}"
                           class="flex-1 min-w-[240px] md:max-w-md bg-white/5 border border-white/10 rounded-xl px-3 py-2 text-white" />
                    <button id="restore-folder-browse" class="px-3 py-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-sm">${escapeHtml(t('backupBrowse'))}</button>
                </div>
                <button id="restore-review" class="mt-3 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 font-medium">${escapeHtml(t('backupReviewRestore'))}</button>
            </div>
        </div>`);
    if (!ok) return;

    const targetInput = document.getElementById('backup-target');
    targetInput.addEventListener('input', () => { state.backup.target = targetInput.value; });
    document.getElementById('restore-folder').addEventListener('input', (e) => { state.backup.localFolder = e.target.value; });

    document.getElementById('backup-target-browse').addEventListener('click', async () => {
        try {
            const folder = await ChooseFolder(t('backupTargetFolder'));
            if (folder) {
                state.backup.target = folder;
                targetInput.value = folder;
            }
        } catch (err) {
            toast(err.message || String(err), 'error');
        }
    });
    document.getElementById('restore-folder-browse').addEventListener('click', async () => {
        try {
            const folder = await ChooseFolder(t('backupLocalFolder'));
            if (folder) {
                state.backup.localFolder = folder;
                document.getElementById('restore-folder').value = folder;
            }
        } catch (err) {
            toast(err.message || String(err), 'error');
        }
    });

    document.querySelectorAll('[data-category]').forEach((box) => {
        box.addEventListener('change', () => {
            if (box.checked) state.backup.selected.add(box.dataset.category);
            else state.backup.selected.delete(box.dataset.category);
        });
    });

    if (appList.length > 0) {
        bindAppsBackupSection(token);
    }

    const customDisplay = document.getElementById('backup-custom-display');
    const customAddButton = document.getElementById('backup-custom-add');
    const setPickedCustomFolder = (path) => {
        state.backup.customDraft = (path || '').trim();
        if (customDisplay) customDisplay.textContent = state.backup.customDraft || t('backupCustomEmpty');
    };
    const addCustom = async () => {
        let value = (state.backup.customDraft || '').trim();
        if (!value) {
            value = await pickAndroidFolder('/sdcard');
            if (!value || !isValidView(token, 'backup')) return;
            setPickedCustomFolder(value);
        }
        const addBtn = document.getElementById('backup-custom-add');
        if (addBtn) { addBtn.disabled = true; addBtn.textContent = t('backupFolderChecking'); }
        try {
            // Validate against the device so typos never create silent empty backups.
            const exists = await RemotePathExists(value);
            if (!isValidView(token, 'backup')) return;
            if (!exists) {
                toast(`${value} — ${t('backupFolderInvalid')}`, 'error');
                return;
            }
            const normalized = value.replace(/\\/g, '/').replace(/\/+$/, '');
            if (!state.backup.customFolders.includes(normalized)) state.backup.customFolders.push(normalized);
            setPickedCustomFolder('');
            renderCustomFolderChips(token);
        } catch (err) {
            toast(err.message || String(err), 'error');
        } finally {
            if (addBtn) { addBtn.textContent = t('backupAddFolder'); }
        }
    };
    document.getElementById('backup-custom-browse').addEventListener('click', async () => {
        try {
            const folder = await pickAndroidFolder(state.backup.customDraft || '/sdcard');
            if (folder && isValidView(token, 'backup')) setPickedCustomFolder(folder);
        } catch (err) {
            toast(err.message || String(err), 'error');
        }
    });
    document.getElementById('backup-custom-add').addEventListener('click', addCustom);
    renderCustomFolderChips(token);

    document.getElementById('backup-review').addEventListener('click', () => reviewBackupPlan(token));
    document.getElementById('restore-review').addEventListener('click', () => reviewRestorePlan(token));
}

// The app (APK) backup section: searchable checkbox list of every installed app.
// backupIconObserver is replaced on every re-render (search keystrokes), so the
// old one is disconnected instead of leaking.
let backupIconObserver = null;

// bindAppBackupIcons fills the app-backup list icons: cached icons paint
// instantly, system apps get the default Android icon with no device read, and
// visible user apps extract their icon from the phone — all bounded to what is
// scrolled into view inside the list.
function bindAppBackupIcons(listHost, token) {
    if (backupIconObserver) {
        backupIconObserver.disconnect();
        backupIconObserver = null;
    }
    const hosts = [...listHost.querySelectorAll('[data-app-icon-host]')];
    if (hosts.length === 0) return;
    const byPackage = new Map((state.apps.list || []).map((app) => [app.packageName, app]));

    const paint = (host, url) => {
        if (!url || !host.isConnected) return;
        host.innerHTML = `<img src="${url}" alt="" class="w-8 h-8 object-cover" />`;
    };
    const loadIcon = (host, app) => {
        if (!app.isThirdParty) {
            ensureGenericIcon().then((url) => {
                if (url) state.apps.icons.set(app.packageName, url);
                paint(host, url);
            });
            return;
        }
        ensureIcon(app, token).then((url) => paint(host, url));
    };

    const observer = new IntersectionObserver((observed) => {
        observed.forEach((item) => {
            if (!item.isIntersecting) return;
            const host = item.target;
            observer.unobserve(host);
            const app = byPackage.get(host.dataset.appIconHost);
            if (!app) return;
            if (state.apps.icons.has(app.packageName)) {
                paint(host, state.apps.icons.get(app.packageName));
                return;
            }
            loadIcon(host, app);
        });
    }, { root: listHost, rootMargin: '80px' });
    backupIconObserver = observer;

    hosts.forEach((host) => {
        const cached = state.apps.icons.get(host.dataset.appIconHost);
        if (cached) paint(host, cached);
        else observer.observe(host);
    });
}

function bindAppsBackupSection(token) {
    const listHost = document.getElementById('apps-backup-list');
    const search = document.getElementById('apps-backup-search');
    const countLabel = document.getElementById('apps-backup-count');
    if (!listHost) return;

    const renderList = () => {
        const query = state.backup.appsSearch.trim().toLowerCase();
        const apps = (state.apps.list || []).filter((app) => {
            // Backup list shows only user-installed apps (no system apps,
            // services, extensions or other non-APK packages).
            if (!app.isThirdParty) return false;
            if (app.isServiceLike) return false;
            if (query) {
                return `${app.name || ''} ${app.packageName || ''}`.toLowerCase().includes(query);
            }
            return true;
        });
        listHost.innerHTML = apps.length ? apps.map((app) => {
            const checked = state.backup.appsSelected.has(app.packageName) ? 'checked' : '';
            const icon = state.apps.icons.get(app.packageName);
            const letter = escapeHtml((app.name || 'A').charAt(0).toUpperCase());
            // Icon host: filled from cache now, or lazily by bindAppBackupIcons
            // (user apps are extracted from the phone, system apps get the
            // default Android icon without touching the device).
            const iconMarkup = `<span class="w-8 h-8 rounded-lg bg-white/5 flex items-center justify-center text-xs shrink-0 overflow-hidden" data-app-icon-host="${escapeHtml(app.packageName)}">`
                + (icon ? `<img src="${icon}" alt="" class="w-8 h-8 object-cover" />` : letter)
                + `</span>`;
            return `
                <label class="flex items-center gap-2 bg-white/5 border border-white/10 rounded-xl p-2 cursor-pointer hover:bg-white/10">
                    <input type="checkbox" data-app="${escapeHtml(app.packageName)}" ${checked} class="accent-blue-500 shrink-0" />
                    ${iconMarkup}
                    <span class="min-w-0">
                        <span class="block text-sm truncate">${escapeHtml(app.name || app.packageName)}</span>
                        <span class="block text-[10px] text-gray-500 truncate">${escapeHtml(app.isThirdParty ? t('filterUserOnly') : t('filterSystemOnly'))}</span>
                    </span>
                </label>`;
        }).join('') : `<div class="text-xs text-gray-500 p-2">${escapeHtml(t('noAppsMatch'))}</div>`;

        listHost.querySelectorAll('[data-app]').forEach((box) => {
            box.addEventListener('change', () => {
                if (box.checked) state.backup.appsSelected.add(box.dataset.app);
                else state.backup.appsSelected.delete(box.dataset.app);
                updateCount();
            });
        });

        bindAppBackupIcons(listHost, token);
    };

    const updateCount = () => {
        if (countLabel) {
            countLabel.textContent = state.backup.appsSelected.size > 0
                ? `${state.backup.appsSelected.size} ${t('backupAppsSelected')}`
                : '';
        }
        const start = document.getElementById('apps-backup-start');
        if (start) start.disabled = state.backup.appsSelected.size === 0;
    };

    if (search) {
        search.addEventListener('input', () => {
            state.backup.appsSearch = search.value;
            renderList();
        });
    }
    document.getElementById('apps-backup-all').addEventListener('click', () => {
        const query = state.backup.appsSearch.trim().toLowerCase();
        (state.apps.list || []).forEach((app) => {
            if (!query || `${app.name || ''} ${app.packageName || ''}`.toLowerCase().includes(query)) {
                state.backup.appsSelected.add(app.packageName);
            }
        });
        renderList();
        updateCount();
    });
    document.getElementById('apps-backup-clear').addEventListener('click', () => {
        state.backup.appsSelected.clear();
        renderList();
        updateCount();
    });
    document.getElementById('apps-backup-start').addEventListener('click', () => appBackupReview(token));

    renderList();
    updateCount();
}

async function appBackupReview(token) {
    const packages = [...state.backup.appsSelected];
    if (packages.length === 0) { toast(t('recoveryNoneSelected'), 'error'); return; }

    setViewHtml(token, 'backup', `
        <div class="bg-white/5 border border-white/10 backdrop-blur-xl rounded-2xl p-6 col-span-full">
            <h2 class="text-2xl font-semibold mb-2">${escapeHtml(t('appBackupPlanTitle'))}</h2>
            <div class="flex items-center gap-3 text-gray-400 mt-4">
                <svg class="w-5 h-5 animate-spin text-blue-400" viewBox="0 0 24 24" fill="none">
                    <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                    <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z"></path>
                </svg>
                <span id="plan-status">${escapeHtml(t('loadingData'))}</span>
            </div>
        </div>`);

    let plan;
    try {
        plan = await PreviewAppBackup(packages, state.backup.target);
    } catch (err) {
        if (!isValidView(token, 'backup')) return;
        setViewHtml(token, 'backup', errorCard(t('appBackupPlanTitle'), err.message || String(err)));
        return;
    }
    if (!isValidView(token, 'backup')) return;

    const rows = (plan.items || []).map((item) => `
        <tr class="border-b border-white/5">
            <td class="py-2 pr-3">${escapeHtml(item.name || item.package)}</td>
            <td class="py-2 pr-3 text-xs text-gray-500">${escapeHtml(item.package)}</td>
            <td class="py-2 pr-3 text-right">${(item.apkPaths || []).length}</td>
            <td class="py-2 pr-3 text-right">${formatBytes(item.totalBytes)}</td>
            <td class="py-2 text-xs ${item.error ? 'text-red-300' : 'text-emerald-300'}">${escapeHtml(item.error || '')}</td>
        </tr>`).join('');

    const ok = setViewHtml(token, 'backup', `
        <div class="bg-white/5 border border-white/10 backdrop-blur-xl rounded-2xl p-6 col-span-full">
            <h2 class="text-2xl font-semibold mb-2">${escapeHtml(t('appBackupPlanTitle'))}</h2>
            <p class="text-gray-400 mb-4">${escapeHtml(t('backupPlanNote'))}</p>
            <div class="overflow-x-auto max-h-[45vh] scroll-area">
                <table class="w-full text-sm">
                    <thead class="text-gray-400 text-xs uppercase sticky top-0 bg-[#141821]">
                        <tr><th class="text-left py-2 pr-3">${escapeHtml(t('category'))}</th>
                            <th class="text-left py-2 pr-3"></th>
                            <th class="text-right py-2 pr-3">${escapeHtml(t('selectedFiles'))}</th>
                            <th class="text-right py-2 pr-3">${escapeHtml(t('sizeLabel'))}</th>
                            <th class="text-left py-2"></th></tr>
                    </thead>
                    <tbody>${rows}</tbody>
                </table>
            </div>
            <div class="flex flex-wrap gap-6 mt-4 text-sm">
                <div><span class="text-gray-400">${escapeHtml(t('selectedFiles'))}:</span> <strong>${plan.totalFiles}</strong></div>
                <div><span class="text-gray-400">${escapeHtml(t('sizeLabel'))}:</span> <strong>${formatBytes(plan.totalBytes)}</strong></div>
                <div class="min-w-0"><span class="text-gray-400">${escapeHtml(t('backupTargetFolder'))}:</span> <strong class="break-all">${escapeHtml(plan.targetFolder)}</strong></div>
            </div>
            <div class="flex gap-2 mt-5">
                <button id="app-backup-confirm" class="px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-700 font-medium">${escapeHtml(t('backupStart'))}</button>
                <button id="app-backup-cancel" class="px-4 py-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10">${escapeHtml(t('cancel'))}</button>
            </div>
        </div>`);
    if (!ok) return;

    document.getElementById('app-backup-cancel').addEventListener('click', () => renderBackupStepSelect(token));
    document.getElementById('app-backup-confirm').addEventListener('click', () => startAppBackup(token, packages));
}

async function startAppBackup(token, packages) {
    if (!setViewHtml(token, 'backup', transferPanel('app-backup'))) return;
    resetMainScroll();
    bindTransferProgress('app-backup');
    try {
        const result = await RunAppBackup(packages, state.backup.target);
        if (!isValidView(token, 'backup')) return;
        const ok = setViewHtml(token, 'backup', resultMarkup(result, t('appBackupDone')));
        if (ok) document.getElementById('backup-restart').addEventListener('click', () => renderBackupStepSelect(token));
        state.transferHandler = null;
        toast(`${t('appBackupDone')} — ${result.copied}/${result.totalFiles}`, result.failed ? 'error' : 'success');
    } catch (err) {
        if (!isValidView(token, 'backup')) return;
        state.transferHandler = null;
        toast(err.message || String(err), 'error');
        renderBackupStepSelect(token);
    }
}

function renderCustomFolderChips(token) {
    const host = document.getElementById('backup-custom-list');
    if (!host) return;
    const folders = state.backup.customFolders;
    host.innerHTML = folders.length
        ? folders.map((folder) => `
            <span class="inline-flex items-center gap-2 bg-white/10 border border-white/10 rounded-full px-3 py-1 text-xs">
                <span class="truncate max-w-[280px]">${escapeHtml(folder)}</span>
                <button data-remove-folder="${escapeHtml(folder)}" class="text-red-300 hover:text-red-200">&times;</button>
            </span>`).join('')
        : `<span class="text-xs text-gray-500">${escapeHtml(t('backupCustomEmpty'))}</span>`;

    host.querySelectorAll('[data-remove-folder]').forEach((button) => {
        button.addEventListener('click', () => {
            state.backup.customFolders = state.backup.customFolders.filter((f) => f !== button.dataset.removeFolder);
            renderCustomFolderChips(token);
        });
    });
}

async function reviewBackupPlan(token) {
    const selected = [...state.backup.selected];
    if (selected.length === 0 && state.backup.customFolders.length === 0) { toast(t('backupNothing'), 'error'); return; }

    // The plan preview walks the device folders, which can take a while — show
    // live status so the screen never looks frozen.
    setViewHtml(token, 'backup', `
        <div class="bg-white/5 border border-white/10 backdrop-blur-xl rounded-2xl p-6 col-span-full">
            <h2 class="text-2xl font-semibold mb-2">${escapeHtml(t('backupPlanTitle'))}</h2>
            <div class="flex items-center gap-3 text-gray-400 mt-4">
                <svg class="w-5 h-5 animate-spin text-blue-400" viewBox="0 0 24 24" fill="none">
                    <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                    <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z"></path>
                </svg>
                <span id="plan-status">${escapeHtml(t('loadingData'))}</span>
            </div>
        </div>`);

    let plan;
    try {
        plan = await PreviewBackupPlan(selected, state.backup.target, state.backup.customFolders);
    } catch (err) {
        if (!isValidView(token, 'backup')) return;
        setViewHtml(token, 'backup', errorCard(t('backupPlanTitle'), err.message || String(err)));
        toast(err.message || String(err), 'error');
        return;
    }
    if (!isValidView(token, 'backup')) return;

    const rows = plan.items.map((item) => `
        <tr class="border-b border-white/5">
            <td class="py-2 pr-3">${escapeHtml(item.label || item.category)}</td>
            <td class="py-2 pr-3 text-right">${item.fileCount}</td>
            <td class="py-2 pr-3 text-right">${formatBytes(item.totalBytes)}</td>
            <td class="py-2 text-xs ${item.error ? 'text-red-300' : 'text-emerald-300'}">${escapeHtml(item.error || '')}</td>
        </tr>`).join('');

    const ok = setViewHtml(token, 'backup', `
        <div class="bg-white/5 border border-white/10 backdrop-blur-xl rounded-2xl p-6 col-span-full">
            <h2 class="text-2xl font-semibold mb-2">${escapeHtml(t('backupPlanTitle'))}</h2>
            <p class="text-gray-400 mb-4">${escapeHtml(t('backupPlanNote'))}</p>
            <div class="overflow-x-auto">
                <table class="w-full text-sm">
                    <thead class="text-gray-400 text-xs uppercase">
                        <tr><th class="text-left py-2 pr-3">${escapeHtml(t('backupCategory'))}</th>
                            <th class="text-right py-2 pr-3">${escapeHtml(t('selectedFiles'))}</th>
                            <th class="text-right py-2 pr-3">${escapeHtml(t('sizeLabel'))}</th>
                            <th class="text-left py-2"></th></tr>
                    </thead>
                    <tbody>${rows}</tbody>
                </table>
            </div>
            <div class="flex flex-wrap gap-6 mt-4 text-sm">
                <div><span class="text-gray-400">${escapeHtml(t('selectedFiles'))}:</span> <strong>${plan.totalFiles}</strong></div>
                <div><span class="text-gray-400">${escapeHtml(t('sizeLabel'))}:</span> <strong>${formatBytes(plan.totalBytes)}</strong></div>
                <div class="min-w-0"><span class="text-gray-400">${escapeHtml(t('backupTargetFolder'))}:</span> <strong class="break-all">${escapeHtml(plan.targetFolder)}</strong></div>
            </div>
            <div class="flex gap-2 mt-5">
                <button id="backup-confirm" class="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 font-medium">${escapeHtml(t('backupStart'))}</button>
                <button id="backup-cancel" class="px-4 py-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10">${escapeHtml(t('cancel'))}</button>
            </div>
        </div>`);
    if (!ok) return;

    document.getElementById('backup-cancel').addEventListener('click', () => renderBackupStepSelect(token));
    document.getElementById('backup-confirm').addEventListener('click', () => startBackup(token, selected));
}

async function startBackup(token, selected) {
    if (!setViewHtml(token, 'backup', transferPanel('backup'))) return;
    resetMainScroll();
    bindTransferProgress('backup');
    try {
        const result = await RunBackup(selected, state.backup.target, state.backup.customFolders);
        if (!isValidView(token, 'backup')) return;
        state.backup.result = result;
        const ok = setViewHtml(token, 'backup', resultMarkup(result, t('backupDone')));
        if (ok) {
            document.getElementById('backup-restart').addEventListener('click', () => renderBackupStepSelect(token));
        }
        state.transferHandler = null;
        toast(`${t('backupDone')} — ${result.copied}/${result.totalFiles}`, result.failed ? 'error' : 'success');
    } catch (err) {
        if (!isValidView(token, 'backup')) return;
        state.transferHandler = null;
        toast(err.message || String(err), 'error');
        renderBackupStepSelect(token);
    }
}

// reviewRestorePlan always shows something: a spinner first, the plan next, and
// an explanatory card (never a blank pane) when the Go side reports a problem
// or the render itself throws.
async function reviewRestorePlan(token) {
    setViewHtml(token, 'backup', loadingCard(t('backupRestorePlanTitle')));
    try {
        await renderRestorePlan(token);
    } catch (err) {
        if (!isValidView(token, 'backup')) return;
        setViewHtml(token, 'backup', errorCard(t('backupRestorePlanTitle'), err.message || String(err)));
    }
}

async function renderRestorePlan(token) {
    let plan;
    try {
        plan = await PreviewRestorePlan(state.backup.localFolder);
    } catch (err) {
        if (!isValidView(token, 'backup')) return;
        toast(err.message || String(err), 'error');
        renderBackupStepSelect(token);
        return;
    }
    // Defensive: a null plan must not throw mid-render and leave a blank pane.
    plan = plan || { items: [] };

    // Previously backed-up apps in this folder can be reinstalled onto the phone.
    let appBackups = [];
    try {
        appBackups = (await ListLocalAppBackups(state.backup.localFolder)) || [];
    } catch (err) {
        appBackups = [];
    }

    if (!isValidView(token, 'backup')) return;

    if ((!plan.items || plan.items.length === 0) && appBackups.length === 0) {
        // Show a helpful empty state with a folder browser so the user can find
        // the backup folder instead of being sent back with a toast.
        const emptyOk = setViewHtml(token, 'backup', `
            <div class="bg-white/5 border border-white/10 backdrop-blur-xl rounded-2xl p-6 col-span-full">
                <h2 class="text-2xl font-semibold mb-2">${escapeHtml(t('backupRestorePlanTitle'))}</h2>
                <p class="text-gray-400 mb-4">${escapeHtml(plan.error || t('recoveryNoResults'))}</p>
                <label class="block text-sm text-gray-400 mb-1">${escapeHtml(t('backupLocalFolder'))}</label>
                <div class="flex flex-wrap gap-2 mb-4">
                    <input id="restore-folder-empty" value="${escapeHtml(state.backup.localFolder)}"
                           class="flex-1 min-w-[240px] md:max-w-md bg-white/5 border border-white/10 rounded-xl px-3 py-2 text-white" />
                    <button id="restore-folder-browse-empty" class="px-3 py-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-sm">${escapeHtml(t('backupBrowse'))}</button>
                </div>
                <button id="restore-review-empty" class="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 font-medium">${escapeHtml(t('backupReviewRestore'))}</button>
                <button id="restore-cancel-empty" class="ml-2 px-4 py-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10">${escapeHtml(t('cancel'))}</button>
            </div>`);
        if (!emptyOk) {
            // Fallback: inject directly into the view container if token validation
            // rejected the update (e.g. a re-render happened while scanning).
            const el = viewContent();
            if (el) el.innerHTML = `
                <div class="bg-white/5 border border-white/10 backdrop-blur-xl rounded-2xl p-6 col-span-full">
                    <h2 class="text-2xl font-semibold mb-2">${escapeHtml(t('backupRestorePlanTitle'))}</h2>
                    <p class="text-gray-400 mb-4">${escapeHtml(plan.error || t('recoveryNoResults'))}</p>
                </div>`;
        }
        return;
    }

    // Build a selectable rows list for the data-folders section so the user can
    // pick which folders to push back to the phone instead of restoring every
    // folder at once.
    let selectedFolders = new Set((plan.items || []).map((item) => item.category));

    const rows = (plan.items || []).map((item) => {
        const checked = selectedFolders.has(item.category) ? 'checked' : '';
        return `
        <tr class="border-b border-white/5">
            <td class="py-2 pr-3">
                <label class="flex items-center gap-2 cursor-pointer">
                    <input type="checkbox" data-folder-select="${escapeHtml(item.category)}" ${checked} class="accent-blue-500 shrink-0" />
                    <span class="text-sm">${escapeHtml(item.label || item.category)}</span>
                </label>
            </td>
            <td class="py-2 pr-3 text-right text-sm">${item.fileCount}</td>
            <td class="py-2 text-right text-sm">${formatBytes(item.totalBytes)}</td>
        </tr>`;
    }).join('');

    const filesSection = (plan.items || []).length > 0 ? `
        <div class="bg-white/[0.03] border border-white/10 rounded-xl p-4 mb-4">
            <h3 class="text-lg font-semibold mb-2">${escapeHtml(t('backupCategory'))} (${plan.totalFiles} files • ${formatBytes(plan.totalBytes)})</h3>
            <p class="text-xs text-gray-500 mb-3">${escapeHtml(plan.hasManifest ? t('backupPlanNote') : t('backupNoManifest'))}</p>
            <div class="overflow-x-auto max-h-[30vh] scroll-area">
                <table class="w-full text-sm">
                    <thead class="text-gray-400 text-xs uppercase sticky top-0 bg-[#141821]">
                        <tr><th class="text-left py-2 pr-3">${escapeHtml(t('backupCategory'))}</th>
                            <th class="text-right py-2 pr-3">${escapeHtml(t('selectedFiles'))}</th>
                            <th class="text-right py-2">${escapeHtml(t('sizeLabel'))}</th></tr>
                    </thead>
                    <tbody>${rows}</tbody>
                </table>
            </div>
            <div class="flex flex-wrap gap-6 mt-3 text-sm" data-restore-summary>
                <div><span class="text-gray-400">${escapeHtml(t('selectedFiles'))}:</span> <strong>${selectedFolders.size}</strong> / ${plan.items.length}</div>
                <div><span class="text-gray-400">${escapeHtml(t('sizeLabel'))}:</span> <strong>${formatBytes(plan.items.filter((it) => selectedFolders.has(it.category)).reduce((s, it) => s + it.totalBytes, 0))}</strong></div>
            </div>
        </div>` : '';

    const appsSection = appBackups.length > 0 ? `
        <div class="bg-white/[0.03] border border-white/10 rounded-xl p-4 mb-4">
            <h3 class="text-lg font-semibold mb-1">${escapeHtml(t('installAppsTitle'))} (${appBackups.length})</h3>
            <p class="text-xs text-gray-500 mb-3">${escapeHtml(t('installAppsHint'))}</p>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-2 max-h-[240px] overflow-y-auto scroll-area pr-1">
                ${appBackups.map((backup) => `
                    <label class="flex items-center gap-2 bg-white/5 border border-white/10 rounded-xl p-2 cursor-pointer hover:bg-white/10">
                        <input type="checkbox" data-install-app="${escapeHtml(backup.package)}" class="accent-blue-500 shrink-0" />
                        <span class="min-w-0">
                            <span class="block text-sm truncate">${escapeHtml(backup.name || backup.package)}</span>
                            <span class="block text-[10px] text-gray-500 truncate">${escapeHtml(backup.package)} • ${(backup.files || []).length} APK • ${formatBytes(backup.totalBytes)}</span>
                        </span>
                    </label>`).join('')}
            </div>
        </div>` : '';

    const hasData = (plan.items || []).length > 0;
    const hasApps = appBackups.length > 0;

    const ok = setViewHtml(token, 'backup', `
        <div class="bg-white/5 border border-white/10 backdrop-blur-xl rounded-2xl p-6 col-span-full">
            <div class="flex flex-wrap items-center justify-between gap-2 mb-4">
                <h2 class="text-2xl font-semibold">${escapeHtml(t('backupRestorePlanTitle'))}</h2>
                <div class="text-xs text-gray-500 bg-white/5 border border-white/10 rounded-xl px-3 py-1.5">
                    <span class="text-gray-400">${escapeHtml(t('backupLocalFolder'))}:</span>
                    <span class="font-mono ml-1 break-all">${escapeHtml(state.backup.localFolder)}</span>
                </div>
            </div>
            ${filesSection}
            ${appsSection}
            <div class="flex flex-wrap gap-2 mt-5">
                ${hasData ? `<button id="restore-confirm" class="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 font-medium">${escapeHtml(t('backupRestoreStart'))}</button>` : ''}
                ${hasApps ? `<button id="install-apps-start-plain" disabled class="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 font-medium disabled:opacity-40 disabled:cursor-not-allowed">${escapeHtml(t('installSelected'))}</button>` : ''}
                <button id="restore-cancel" class="px-4 py-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10">${escapeHtml(t('cancel'))}</button>
            </div>
        </div>`);
    if (!ok) {
        const el = viewContent();
        if (el) el.innerHTML = `<div class="bg-white/5 border border-white/10 backdrop-blur-xl rounded-2xl p-6 col-span-full"><p class="text-gray-400">${escapeHtml(t('loadingData'))}</p></div>`;
        return;
    }

    // Folder selection checkboxes
    document.querySelectorAll('[data-folder-select]').forEach((box) => {
        box.addEventListener('change', () => {
            if (box.checked) selectedFolders.add(box.dataset.folderSelect);
            else selectedFolders.delete(box.dataset.folderSelect);
            // Update the summary line
            const summary = document.querySelector('[data-restore-summary]');
            if (summary) {
                const selectedBytes = plan.items
                    .filter((it) => selectedFolders.has(it.category))
                    .reduce((s, it) => s + it.totalBytes, 0);
                summary.innerHTML = `<span class="text-gray-400">${escapeHtml(t('selectedFiles'))}:</span> <strong>${selectedFolders.size}</strong> / ${plan.items.length} • <span class="text-gray-400">${escapeHtml(t('sizeLabel'))}:</span> <strong>${formatBytes(selectedBytes)}</strong>`;
            }
        });
    });

    document.getElementById('restore-cancel').addEventListener('click', () => renderBackupStepSelect(token));

    const restoreConfirm = document.getElementById('restore-confirm');
    if (restoreConfirm) {
        restoreConfirm.addEventListener('click', () => {
            const categories = [...selectedFolders];
            startRestoreWithCategories(token, state.backup.localFolder, categories);
        });
    }

    if (hasApps) {
        state.backup.installSelected = new Set();
        const installBtn = document.getElementById('install-apps-start') || document.getElementById('install-apps-start-plain');
        // The button stays disabled until something is ticked, so clicking it
        // never ends in silence.
        if (installBtn) installBtn.disabled = true;
        const boxes = [...document.querySelectorAll('[data-install-app]')];
        boxes.forEach((box) => {
            box.addEventListener('change', () => {
                if (box.checked) state.backup.installSelected.add(box.dataset.installApp);
                else state.backup.installSelected.delete(box.dataset.installApp);
                if (installBtn) installBtn.disabled = state.backup.installSelected.size === 0;
            });
        });
        if (installBtn) installBtn.addEventListener('click', () => startAppInstall(token));
    }
}

async function startRestoreWithCategories(token, localFolder, categories) {
    if (categories.length === 0) { toast(t('recoveryNoneSelected'), 'error'); return; }
    if (!setViewHtml(token, 'backup', transferPanel('restore'))) return;
    resetMainScroll();
    bindTransferProgress('restore');
    try {
        const result = await RunRestore(localFolder, categories);
        if (!isValidView(token, 'backup')) return;
        const ok = setViewHtml(token, 'backup', resultMarkup({ ...result, manifestPath: '' }, t('backupRestoreDone')));
        if (ok) document.getElementById('backup-restart').addEventListener('click', () => renderBackupStepSelect(token));
        state.transferHandler = null;
        toast(`${t('backupRestoreDone')} — ${result.copied}/${result.totalFiles}`, result.failed ? 'error' : 'success');
    } catch (err) {
        if (!isValidView(token, 'backup')) return;
        state.transferHandler = null;
        toast(err.message || String(err), 'error');
        renderBackupStepSelect(token);
    }
}

async function startAppInstall(token) {
    const packages = [...state.backup.installSelected];
    if (packages.length === 0) { toast(t('installNoneSelected'), 'error'); return; }
    const agreed = await confirmDialog(
        `${t('installSelected')}\n\n${packages.join('\n')}`, t('installSelected'));
    if (!agreed) return;

    if (!setViewHtml(token, 'backup', transferPanel('install'))) return;
    resetMainScroll();
    bindTransferProgress('install');
    try {
        const result = await InstallAppBackups(state.backup.localFolder, packages);
        if (!isValidView(token, 'backup')) return;
        const ok = setViewHtml(token, 'backup', resultMarkup({ ...result, manifestPath: '' }, t('installDone')));
        if (ok) document.getElementById('backup-restart').addEventListener('click', () => renderBackupStepSelect(token));
        state.transferHandler = null;
        toast(`${t('installDone')} — ${result.copied}/${result.totalFiles}`, result.failed ? 'error' : 'success');
    } catch (err) {
        if (!isValidView(token, 'backup')) return;
        state.transferHandler = null;
        toast(err.message || String(err), 'error');
        renderBackupStepSelect(token);
    }
}
/* ------------------------------------------------------------------ *
* Recovery wizard

 * ------------------------------------------------------------------ */

const RECOVERY_TYPES = [
    { id: 'photo', icon: '🖼', labelKey: 'recPhotos' },
    { id: 'video', icon: '🎬', labelKey: 'recVideos' },
    { id: 'audio', icon: '🎵', labelKey: 'recAudio' },
    { id: 'documents', icon: '📄', labelKey: 'recDocs' },
    { id: 'archive', icon: '🗜', labelKey: 'recArchives' },
    { id: 'apk', icon: '📦', labelKey: 'recApks' },
    { id: 'phone', icon: '📞', labelKey: 'recPhone' },
    { id: 'all', icon: '🔎', labelKey: 'recAll' },
];

async function renderRecovery(token) {
    const view = 'tasks';
    const devices = await requireDevice(token, view);
    if (!devices) return;

    if (!state.recovery.mode) {
        renderRecoveryTypeStep(token);
    } else {
        renderRecoveryScanStep(token);
    }
}

function renderRecoveryTypeStep(token) {
    const cards = RECOVERY_TYPES.map((type) => `
        <button data-type="${type.id}" class="text-left bg-white/5 hover:bg-white/10 border border-white/10 rounded-xl p-4 transition-colors">
            <div class="text-2xl mb-2">${type.icon}</div>
            <div class="font-medium text-white">${escapeHtml(t(type.labelKey))}</div>
        </button>`).join('');

    const ok = setViewHtml(token, 'tasks', `
        <div class="bg-white/5 border border-white/10 backdrop-blur-xl rounded-2xl p-6 col-span-full">
            <h2 class="text-2xl font-semibold mb-2">${escapeHtml(t('tasks'))}</h2>
            <p class="text-gray-400 mb-5">${escapeHtml(t('recoveryIntro'))}</p>
            <h3 class="text-lg font-medium mb-3">${escapeHtml(t('recoveryPickType'))}</h3>
            <div class="grid grid-cols-2 md:grid-cols-4 gap-3">${cards}</div>
        </div>`);
    if (!ok) return;

    document.querySelectorAll('[data-type]').forEach((card) => {
        card.addEventListener('click', () => {
            state.recovery.mode = card.dataset.type;
            state.recovery.results = null;
            renderRecoveryScanStep(token);
        });
    });
}

function renderRecoveryScanStep(token) {
    const type = RECOVERY_TYPES.find((item) => item.id === state.recovery.mode);
    const scanning = state.recovery.scanning;

    const ok = setViewHtml(token, 'tasks', `
        <div class="bg-white/5 border border-white/10 backdrop-blur-xl rounded-2xl p-6 col-span-full">
            <div class="flex flex-wrap items-center justify-between gap-3 mb-4">
                <h2 class="text-2xl font-semibold">${escapeHtml(t('tasks'))}</h2>
                <button id="recovery-change" class="px-3 py-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-sm">${escapeHtml(t('recoveryChangeType'))}</button>
            </div>

            <div class="flex items-center gap-3 mb-4">
                <span class="text-2xl">${type ? type.icon : '🔎'}</span>
                <span class="font-medium">${escapeHtml(type ? t(type.labelKey) : t('recAll'))}</span>
            </div>

            <div class="flex flex-col md:flex-row gap-3 mb-3">
                <input id="recovery-query" value="${escapeHtml(state.recovery.query)}" placeholder="${escapeHtml(t('recoveryQueryPlaceholder'))}"
                       class="flex-1 bg-white/5 border border-white/10 rounded-xl px-3 py-2 text-white placeholder:text-gray-500" />
                <button id="recovery-quick" class="px-4 py-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10" ${scanning ? 'disabled' : ''}>${escapeHtml(t('recoveryQuickScan'))}</button>
                <button id="recovery-deep" class="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 font-medium" ${scanning ? 'disabled' : ''}>${escapeHtml(t('recoveryDeepScan'))}</button>
            </div>
            <div class="text-xs text-gray-500 mb-4">
                ${escapeHtml(t('recoveryQuickHint'))}<br>${escapeHtml(t('recoveryDeepHint'))}
            </div>
            <div id="recovery-status" class="text-sm text-gray-400 mb-4">${scanning ? escapeHtml(t('recoveryScanning')) : ''}</div>
            <div id="recovery-results"></div>
        </div>`);
    if (!ok) return;

    document.getElementById('recovery-change').addEventListener('click', () => {
        state.recovery.mode = null;
        state.recovery.results = null;
        renderRecoveryTypeStep(token);
    });
    const query = document.getElementById('recovery-query');
    query.addEventListener('input', () => { state.recovery.query = query.value; });
    document.getElementById('recovery-quick').addEventListener('click', () => runRecoveryScan(token, false));
    document.getElementById('recovery-deep').addEventListener('click', () => runRecoveryScan(token, true));

    if (state.recovery.results) renderRecoveryResults(token);
}

async function runRecoveryScan(token, deep) {
    state.recovery.scanning = true;
    state.recovery.deep = deep;
    // Drop the previous result set and selection so the user sees the scan state,
    // not stale rows.
    state.recovery.results = null;
    state.recovery.selected = new Set();
    renderRecoveryScanStep(token);

    try {
        const results = await ScanRecoverableFiles({
            mode: state.recovery.mode || 'all',
            query: state.recovery.query || '',
            deep: !!deep,
        });
        state.recovery.scanning = false;
        if (!isValidView(token, 'tasks')) return;
        state.recovery.results = results || [];
        renderRecoveryScanStep(token);
        loadRecoverySizes(token);
    } catch (err) {
        state.recovery.scanning = false;
        if (!isValidView(token, 'tasks')) return;
        renderRecoveryScanStep(token);
        toast(err.message || String(err), 'error');
    }
}

function loadRecoverySizes(token) {
    const results = state.recovery.results || [];
    const pending = results.filter((item) => state.recovery.sizes[item.path] === undefined).slice(0, 40);
    if (pending.length === 0) return;
    GetFileSizes(pending.map((item) => item.path)).then((sizes) => {
        if (!isValidView(token, 'tasks')) return;
        Object.assign(state.recovery.sizes, sizes || {});
        renderRecoveryResults(token);
    }).catch(() => {});
}

function renderRecoveryResults(token) {
    const host = document.getElementById('recovery-results');
    if (!host) return;
    const results = state.recovery.results || [];
    if (results.length === 0) {
        host.innerHTML = `<div class="text-gray-400">${escapeHtml(t('recoveryNoResults'))}</div>`;
        return;
    }

    host.innerHTML = `
        <div class="flex flex-wrap items-center justify-between gap-2 mb-3">
            <div class="text-sm text-gray-400">${escapeHtml(t('recoveryResults'))}: <strong class="text-gray-200">${results.length}</strong></div>
            <div class="flex flex-wrap items-center gap-2">
                <label class="flex items-center gap-2 text-xs text-gray-300 cursor-pointer">
                    <input type="checkbox" id="recovery-select-all" class="accent-blue-500" />
                    ${escapeHtml(t('recoverySelectAll'))}
                </label>
                <button id="recovery-save-selected" class="px-3 py-1.5 text-xs rounded-full bg-blue-500/20 text-blue-200 hover:bg-blue-500/30">${escapeHtml(t('recoverySaveSelected'))}</button>
                <button id="recovery-restore-selected" class="px-3 py-1.5 text-xs rounded-full bg-emerald-500/20 text-emerald-300 hover:bg-emerald-500/30">${escapeHtml(t('recoveryRestoreSelected'))}</button>
                <button id="recovery-remove-selected" class="px-3 py-1.5 text-xs rounded-full bg-red-500/20 text-red-300 hover:bg-red-500/30">${escapeHtml(t('recRemoveSelected'))}</button>
            </div>
        </div>
        <div id="recovery-bulk-status" class="hidden text-xs text-emerald-300 mb-3"></div>
        <div class="space-y-2">
            ${results.map((item) => {
                const size = state.recovery.sizes[item.path];
                const checked = state.recovery.selected.has(item.path) ? 'checked' : '';
                return `
                <div class="bg-white/5 border border-white/10 rounded-xl p-3 flex items-center justify-between gap-3">
                    <input type="checkbox" data-rec-select="${escapeHtml(item.path)}" ${checked} class="accent-blue-500 shrink-0" />
                    <button data-preview-path="${escapeHtml(item.path)}" class="w-14 h-14 shrink-0 rounded-lg bg-white/5 border border-white/10 overflow-hidden flex items-center justify-center text-lg hover:border-blue-400/60" data-rec-thumb="${escapeHtml(item.path)}" title="${escapeHtml(t('preview'))}">
                        ${escapeHtml(fileGlyph({ isDir: false, kind: item.kind || item.type }))}
                    </button>
                    <div class="min-w-0 flex-1">
                        <div class="font-medium text-white truncate">
                            ${escapeHtml(item.name)}
                            ${item.hidden ? `<span class="ml-2 text-[10px] uppercase bg-amber-500/20 text-amber-200 px-2 py-0.5 rounded-full">${escapeHtml(t('recoveryHidden'))}</span>` : ''}
                        </div>
                        <div class="text-xs text-gray-400 truncate">${escapeHtml(item.path)}</div>
                        <div class="text-xs text-amber-300 mt-1">${escapeHtml(item.kind || item.type)} • ${escapeHtml(item.notes || '')}${size !== undefined ? ' • ' + formatBytes(size) : ''}</div>
                        <div class="text-[11px] text-gray-500 mt-1">${escapeHtml(t('recoveryThumbHint'))}</div>
                    </div>
                    <div class="flex flex-col sm:flex-row gap-2 shrink-0">
                        <button data-preview-path="${escapeHtml(item.path)}" class="px-3 py-1.5 text-xs rounded-full bg-white/10 hover:bg-white/20">${escapeHtml(t('preview'))}</button>
                        <button data-save-path="${escapeHtml(item.path)}" class="px-3 py-1.5 text-xs rounded-full bg-blue-500/20 text-blue-200">${escapeHtml(t('saveToPc'))}</button>
                        <button data-restore-path="${escapeHtml(item.path)}" class="px-3 py-1.5 text-xs rounded-full bg-emerald-500/20 text-emerald-300">${escapeHtml(t('recoveryRestoreDevice'))}</button>
                        <button data-remove-path="${escapeHtml(item.path)}" class="px-3 py-1.5 text-xs rounded-full bg-red-500/20 text-red-300 hover:bg-red-500/30">${escapeHtml(t('recRemove'))}</button>
                    </div>
                </div>`;
            }).join('')}
        </div>`;

    host.querySelectorAll('[data-rec-select]').forEach((box) => {
        box.addEventListener('change', () => {
            if (box.checked) state.recovery.selected.add(box.dataset.recSelect);
            else state.recovery.selected.delete(box.dataset.recSelect);
            const selectAll = document.getElementById('recovery-select-all');
            if (selectAll) selectAll.checked = state.recovery.selected.size > 0 && state.recovery.selected.size >= results.length;
        });
    });
    const selectAll = document.getElementById('recovery-select-all');
    if (selectAll) {
        selectAll.checked = state.recovery.selected.size >= results.length && results.length > 0;
        selectAll.addEventListener('change', () => {
            state.recovery.selected = new Set(selectAll.checked ? results.map((item) => item.path) : []);
            host.querySelectorAll('[data-rec-select]').forEach((box) => {
                box.checked = selectAll.checked;
            });
        });
    }
    const bulkStatus = document.getElementById('recovery-bulk-status');
    const showBulkProgress = (payload) => {
        if (!bulkStatus) return;
        bulkStatus.classList.remove('hidden');
        bulkStatus.textContent = `${payload.completed} / ${payload.total} • ${formatBytes(payload.bytes)}${payload.message ? ' • ' + payload.message : ''}`;
    };

    const saveSelected = document.getElementById('recovery-save-selected');
    if (saveSelected) {
        saveSelected.addEventListener('click', async () => {
            const paths = [...state.recovery.selected];
            if (paths.length === 0) { toast(t('recoveryNoneSelected'), 'error'); return; }
            let folder = '';
            try {
                folder = await ChooseFolder(t('recoverySaveSelected'));
            } catch (err) {
                toast(err.message || String(err), 'error');
                return;
            }
            if (!folder) return;
            saveSelected.disabled = true;
            state.transferHandler = showBulkProgress;
            try {
                const result = await SaveFilesToPC(paths, folder);
                toast(`${t('recoverySavedAll')} ${result.copied}/${result.totalFiles} → ${result.targetFolder}`, result.failed ? 'error' : 'success');
            } catch (err) {
                toast(err.message || String(err), 'error');
            } finally {
                state.transferHandler = null;
                saveSelected.disabled = false;
            }
        });
    }
    const restoreSelected = document.getElementById('recovery-restore-selected');
    if (restoreSelected) {
        restoreSelected.addEventListener('click', async () => {
            const paths = [...state.recovery.selected];
            if (paths.length === 0) { toast(t('recoveryNoneSelected'), 'error'); return; }
            const folder = window.prompt(t('recoveryRestoreFolder'), '/sdcard/Recovered');
            if (folder === null) return;
            restoreSelected.disabled = true;
            state.transferHandler = showBulkProgress;
            try {
                const result = await RestoreFilesToDevice(paths, folder || '/sdcard/Recovered');
                toast(`${t('recoveryRestoredAll')} ${result.copied}/${result.totalFiles} → ${result.targetFolder}`, result.failed ? 'error' : 'success');
            } catch (err) {
                toast(err.message || String(err), 'error');
            } finally {
                state.transferHandler = null;
                restoreSelected.disabled = false;
            }
        });
    }
    const removeSelected = document.getElementById('recovery-remove-selected');
    if (removeSelected) {
        removeSelected.addEventListener('click', async () => {
            const paths = [...state.recovery.selected];
            if (paths.length === 0) { toast(t('recoveryNoneSelected'), 'error'); return; }
            const ok = await confirmDialog(`${t('recRemoveSelectedConfirm')}\n\n${paths.slice(0, 12).join('\n')}${paths.length > 12 ? '\n…' : ''}`, t('recRemoveSelected'));
            if (!ok) return;
            removeSelected.disabled = true;
            state.transferHandler = showBulkProgress;
            try {
                const result = await DeleteRecoveredFiles(paths);
                const removed = new Set(paths);
                state.recovery.results = results.filter((item) => !(removed.has(item.path) && !result.errors?.some((e) => e.includes(item.path))));
                state.recovery.selected = new Set([...state.recovery.selected].filter((path) => !removed.has(path)));
                renderRecoveryResults(token);
                toast(`${t('recRemoved')} ${result.copied}/${result.totalFiles}`, result.failed ? 'error' : 'success');
            } catch (err) {
                toast(err.message || String(err), 'error');
            } finally {
                state.transferHandler = null;
                removeSelected.disabled = false;
            }
        });
    }

    host.querySelectorAll('[data-preview-path]').forEach((button) => {
        button.addEventListener('click', () => openPreview(button.dataset.previewPath));
    });
    setupRecoveryThumbnails(token, results);
    host.querySelectorAll('[data-save-path]').forEach((button) => {
        button.addEventListener('click', async () => {
            try {
                const dest = await SaveFileToPC(button.dataset.savePath, './recovered-data');
                toast(`${t('recoverySavedTo')} ${dest}`, 'success');
            } catch (err) {
                toast(err.message || String(err), 'error');
            }
        });
    });
    host.querySelectorAll('[data-restore-path]').forEach((button) => {
        button.addEventListener('click', async () => {
            const path = button.dataset.restorePath;
            const folder = window.prompt(t('recoveryRestoreFolder'), '/sdcard/Recovered');
            if (folder === null) return;
            button.textContent = '…';
            try {
                await RestoreRecoveredFileTo(path, folder || '/sdcard/Recovered');
                button.textContent = t('recoverySavedTo');
                toast(`${t('recoveryRestoreDevice')}: ${folder || '/sdcard/Recovered'}`, 'success');
            } catch (err) {
                button.textContent = t('recoveryRestoreDevice');
                toast(err.message || String(err), 'error');
            }
        });
    });
    host.querySelectorAll('[data-remove-path]').forEach((button) => {
        button.addEventListener('click', async () => {
            const path = button.dataset.removePath;
            const ok = await confirmDialog(`${t('recRemoveConfirm')}\n\n${path}`, t('recRemove'));
            if (!ok) return;
            button.textContent = '…';
            try {
                await DeleteRecoveredFile(path);
                state.recovery.results = results.filter((item) => item.path !== path);
                state.recovery.selected.delete(path);
                renderRecoveryResults(token);
                toast(`${t('recRemoved')}: ${path}`, 'success');
            } catch (err) {
                button.textContent = t('recRemove');
                toast(err.message || String(err), 'error');
            }
        });
    });
}

// Recovery rows show a real thumbnail for images and videos as they scroll into
// view, so the user can recognise detected media before restoring it.
function setupRecoveryThumbnails(token, results) {
    const host = document.getElementById('recovery-results');
    if (!host) return;
    const byPath = new Map(results.map((item) => [item.path, item]));
    const targets = [...host.querySelectorAll('[data-rec-thumb]')].filter((el) => {
        const item = byPath.get(el.dataset.recThumb);
        return item && (item.kind === 'image' || item.kind === 'video');
    });
    if (targets.length === 0) return;

    const observer = new IntersectionObserver((observed) => {
        observed.forEach((entry) => {
            if (!entry.isIntersecting) return;
            const el = entry.target;
            observer.unobserve(el);
            thumbLimiter(() => GetFileThumbnail(el.dataset.recThumb)).then((url) => {
                if (!url || !isValidView(token, 'tasks')) return;
                el.innerHTML = `<img src="${url}" class="w-full h-full object-cover" alt="" />`;
            }).catch(() => {});
        });
    }, { root: null, rootMargin: '200px' });
    targets.forEach((el) => observer.observe(el));
}

/* ------------------------------------------------------------------ *
 * File browser — cached, prefetched, with thumbnails and preview
 * ------------------------------------------------------------------ */

function parentPathOf(path) {
    if (!path || path === '/') return null;
    const parts = path.split('/').filter(Boolean);
    if (parts.length <= 1) return '/';
    return '/' + parts.slice(0, -1).join('/');
}

function fileGlyph(entry) {
    if (entry.isDir) return '📁';
    switch (entry.kind) {
        case 'image': return '🖼';
        case 'video': return '🎬';
        case 'audio': return '🎵';
        case 'pdf': return '📕';
        case 'text': return '📝';
        case 'document': return '📄';
        case 'archive': return '🗜';
        case 'apk': return '📦';
        default: return '📄';
    }
}

// Glyph by file name for places that only have a name (zip entries).
function glyphForName(name) {
    const ext = (String(name).split('.').pop() || '').toLowerCase();
    if (['jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp', 'heic', 'heif'].includes(ext)) return '🖼';
    if (['mp4', 'mov', 'avi', 'mkv', '3gp', 'webm', 'm4v', 'ts'].includes(ext)) return '🎬';
    if (['mp3', 'm4a', 'aac', 'wav', 'ogg', 'opus', 'flac', 'amr', 'mid'].includes(ext)) return '🎵';
    if (ext === 'pdf') return '📕';
    if (['txt', 'log', 'md', 'csv', 'json', 'xml', 'html', 'yml', 'yaml', 'srt'].includes(ext)) return '📝';
    if (['doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'odt', 'ods', 'rtf'].includes(ext)) return '📄';
    if (['zip', 'rar', '7z', 'tar', 'gz', 'bz2', 'xz'].includes(ext)) return '🗜';
    if (['apk', 'apks', 'aab'].includes(ext)) return '📦';
    return '📄';
}

function renderFilesInto(token, entries, fromCache) {
    const path = state.files.path;
    const host = document.getElementById('file-rows');
    if (!host) return;

    const parent = parentPathOf(path);
    const crumbs = ['/'].concat(path.split('/').filter(Boolean)).reduce((acc, part, index, arr) => {
        const target = index === 0 ? '/' : '/' + arr.slice(1, index + 1).join('/');
        acc.push({ label: part, target });
        return acc;
    }, []);

    const crumbHtml = crumbs.map((crumb, index) => `
        ${index > 0 ? '<span class="text-gray-600 mx-1">/</span>' : ''}
        <button data-nav="${escapeHtml(crumb.target)}" class="hover:text-white text-gray-300">${escapeHtml(crumb.label)}</button>`).join('');

    const rows = [];
    if (parent !== null) {
        rows.push(`
            <button data-nav="${escapeHtml(parent)}" class="file-row w-full text-left bg-white/5 hover:bg-white/10 border border-white/10 rounded-xl p-3 text-gray-200 flex items-center gap-3">
                <span class="text-lg">⬆</span><span>${escapeHtml(t('filesUp'))}</span>
            </button>`);
    }

    if (entries.length === 0) {
        rows.push(`<div class="text-gray-400 p-3">${escapeHtml(t('filesEmpty'))}</div>`);
    }

    entries.forEach((entry, index) => {
        const sizeLabel = entry.isDir ? '' : formatBytes(entry.size);
        rows.push(`
            <button data-index="${index}" class="file-row w-full text-left bg-white/5 hover:bg-white/10 border border-white/10 rounded-xl p-3 text-gray-200 flex items-center gap-3">
                <span class="w-10 h-10 shrink-0 rounded-lg bg-white/5 flex items-center justify-center text-lg" data-thumb-host="${escapeHtml(entry.path)}">${escapeHtml(fileGlyph(entry))}</span>
                <span class="min-w-0 flex-1">
                    <span class="block truncate ${entry.isDir ? 'font-medium' : ''}">${escapeHtml(entry.name)}${entry.isSymlink ? ' <span class="text-xs text-gray-500">↗</span>' : ''}</span>
                    <span class="block text-xs text-gray-500 truncate">${escapeHtml(entry.modified || '')}${sizeLabel ? ' • ' + sizeLabel : ''}</span>
                </span>
            </button>`);
    });

    host.innerHTML = rows.join('');

    const crumbHost = document.getElementById('file-crumbs');
    if (crumbHost) crumbHost.innerHTML = crumbHtml;

    const status = document.getElementById('file-status');
    if (status) status.textContent = fromCache ? t('filesCached') : '';

    host.querySelectorAll('[data-nav]').forEach((button) => {
        button.addEventListener('click', () => navigateFiles(token, button.dataset.nav));
    });
    host.querySelectorAll('[data-index]').forEach((button) => {
        button.addEventListener('click', () => {
            const entry = entries[Number(button.dataset.index)];
            if (!entry) return;
            if (entry.isDir) navigateFiles(token, entry.path);
            else openPreview(entry.path, entry);
        });
    });

    setupThumbnails(token);
}

function setupThumbnails(token) {
    const host = document.getElementById('file-rows');
    if (!host) return;
    const entries = state.files.cache.get(state.files.path) || [];
    const targets = [...host.querySelectorAll('[data-thumb-host]')].filter((el) => {
        const path = el.dataset.thumbHost;
        const entry = entries.find((item) => item.path === path);
        return entry && (entry.kind === 'image' || entry.kind === 'video');
    });
    if (targets.length === 0) return;

    const observer = new IntersectionObserver((observed) => {
        observed.forEach((item) => {
            if (!item.isIntersecting) return;
            const el = item.target;
            observer.unobserve(el);
            const path = el.dataset.thumbHost;
            const entry = entries.find((candidate) => candidate.path === path);
            const isVideo = entry && entry.kind === 'video';
            thumbLimiter(() => GetFileThumbnail(path)).then((url) => {
                if (!url || !isValidView(token, 'files')) return;
                if (isVideo) {
                    el.innerHTML = `<span class="relative block w-10 h-10">
                        <img src="${url}" class="w-10 h-10 rounded-lg object-cover" alt="" />
                        <span class="absolute inset-0 flex items-center justify-center text-white/90 text-xs drop-shadow pointer-events-none">▶</span>
                    </span>`;
                } else {
                    el.innerHTML = `<img src="${url}" class="w-10 h-10 rounded-lg object-cover" alt="" />`;
                }
            }).catch(() => {});
        });
    }, { root: null, rootMargin: '300px' });
    targets.forEach((el) => observer.observe(el));
}

const thumbLimiter = createLimiter(3);

async function prefetchFolders(token, entries) {
    const dirs = entries.filter((entry) => entry.isDir).map((entry) => entry.path).slice(0, 10);
    if (dirs.length === 0) return;
    try {
        const result = await PrefetchAndroidFiles(dirs);
        if (!result) return;
        Object.entries(result).forEach(([path, list]) => state.files.cache.set(path, list));
    } catch (err) {
        // Prefetch is best-effort; ignore failures.
    }
}

async function navigateFiles(token, path) {
    if (!isValidView(token, 'files')) return;
    state.files.path = path;
    const rows = document.getElementById('file-rows');
    if (rows) rows.scrollTop = 0;
    resetMainScroll();

    const cached = state.files.cache.get(path);
    if (cached) {
        renderFilesInto(token, cached, true);
    } else {
        const host = document.getElementById('file-rows');
        if (host) host.innerHTML = `<div class="text-gray-400 p-3">${escapeHtml(t('loading'))}</div>`;
    }

    try {
        const entries = await ListAndroidFiles(path);
        if (!isValidView(token, 'files')) return;
        state.files.cache.set(path, entries || []);
        renderFilesInto(token, entries || [], false);
        prefetchFolders(token, entries || []);
    } catch (err) {
        if (!isValidView(token, 'files')) return;
        const host = document.getElementById('file-rows');
        if (host) host.innerHTML = `<div class="text-red-400 p-3">${escapeHtml(t('filesReadError'))} ${escapeHtml(err.message || String(err))}</div>`;
    }
}

function storageCardMarkup(volume) {
    const total = volume.totalBytes || 0;
    const used = Math.max(0, Math.min(volume.usedBytes || 0, total));
    const pct = total > 0 ? Math.max(2, Math.round((used / total) * 100)) : 0;
    const sizeLine = total > 0
        ? `${formatBytes(used)} ${t('filesUsed')} • ${formatBytes(volume.freeBytes)} ${t('filesFree')}`
        : t('filesStorageUnknown');
    return `
        <button data-storage-path="${escapeHtml(volume.path)}" class="text-left bg-white/5 hover:bg-white/10 border border-white/10 rounded-xl p-4 transition-colors">
            <div class="flex items-center justify-between gap-3 mb-2">
                <span class="font-medium">${escapeHtml(volume.isRemovable ? t('filesSdCard') : t('filesInternal'))}</span>
                ${volume.isRemovable ? '<span class="text-[10px] uppercase bg-white/10 text-gray-300 px-2 py-0.5 rounded-full">SD</span>' : ''}
            </div>
            <div class="w-full h-2 bg-white/10 rounded-full overflow-hidden mb-2">
                <div class="h-full bg-gradient-to-r from-blue-500 to-emerald-500 rounded-full" style="width:${total > 0 ? pct : 4}%"></div>
            </div>
            <div class="text-xs text-gray-400">${escapeHtml(sizeLine)}</div>
            <div class="text-[11px] text-gray-500 truncate">${escapeHtml(volume.path)}</div>
        </button>`;
}

async function loadStorageCards(token) {
    const host = document.getElementById('storage-cards');
    if (!host) return;
    try {
        const volumes = await GetStorageVolumes();
        if (!isValidView(token, 'files')) return;
        if (!volumes || volumes.length === 0) return;
        host.innerHTML = `
            <div class="text-xs uppercase tracking-wide text-gray-500 mb-2">${escapeHtml(t('filesStorage'))}</div>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-3 mb-4">
                ${volumes.map((volume) => storageCardMarkup(volume)).join('')}
            </div>`;
        host.querySelectorAll('[data-storage-path]').forEach((button) => {
            button.addEventListener('click', () => navigateFiles(token, button.dataset.storagePath));
        });
    } catch (err) {
        // Storage overview is optional — the browser still works without it.
    }
}

function renderFiles(token) {
    const view = 'files';
    setViewHtml(token, view, `
        <div class="bg-white/5 border border-white/10 backdrop-blur-xl rounded-2xl p-6 col-span-full">
            <div class="flex flex-wrap items-center justify-between gap-3 mb-3">
                <h2 class="text-2xl font-semibold">${escapeHtml(t('files'))}</h2>
                <button id="files-refresh" class="px-3 py-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-sm">${escapeHtml(t('refresh'))}</button>
            </div>
            <div id="storage-cards"></div>
            <div id="file-crumbs" class="text-sm mb-1 truncate"></div>
            <div class="text-xs text-gray-500 mb-3" id="file-status"></div>
            <div class="space-y-2 scroll-area max-h-[62vh] overflow-y-auto pr-1" id="file-rows"></div>
        </div>`);

    const refresh = document.getElementById('files-refresh');
    if (refresh) {
        refresh.addEventListener('click', () => {
            state.files.cache.delete(state.files.path);
            navigateFiles(token, state.files.path);
        });
    }
    navigateFiles(token, state.files.path);
    loadStorageCards(token);
}

/* ------------------------------------------------------------------ *
 * Shared file preview modal
 * ------------------------------------------------------------------ */

async function openPreview(path, entry) {
    const modal = openModal({
        title: t('previewTitle'),
        wide: true,
        body: `<div class="text-gray-400">${escapeHtml(t('loading'))}</div>`,
        footer: `<button data-modal-close class="px-4 py-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10">${escapeHtml(t('close'))}</button>`,
    });
    modal.footer.querySelector('[data-modal-close]').addEventListener('click', modal.close);

    let preview;
    try {
        preview = await GetFilePreview(path);
    } catch (err) {
        modal.body.innerHTML = `<p class="text-red-400">${escapeHtml(err.message || String(err))}</p>`;
        return;
    }

    const meta = `
        <div class="flex flex-wrap gap-4 text-xs text-gray-400 mb-3">
            <span class="truncate">${escapeHtml(preview.path)}</span>
            <span>${escapeHtml(t('previewSize'))}: ${formatBytes(preview.size)}</span>
            <span>${escapeHtml(t('previewKind'))}: ${escapeHtml(preview.kind)}</span>
        </div>`;

    let viewer = '';
    if (preview.kind === 'archive') {
        // Archives are browsed inside the app: the zip contents viewer works for
        // large files too (it lists entries from a local copy, capped at 300 MB).
        viewer = `<div id="zip-browser"><div class="text-gray-400 text-sm">${escapeHtml(t('loading'))}</div></div>`;
    } else if (preview.tooLarge) {
        viewer = `<p class="text-amber-300 text-sm">${escapeHtml(preview.message || t('previewTooLarge'))}</p>`;
    } else if (preview.kind === 'image' && preview.dataUrl) {
        viewer = `<img src="${preview.dataUrl}" class="max-h-[65vh] w-auto mx-auto rounded-xl" alt="" />`;
    } else if (preview.kind === 'video' && preview.dataUrl) {
        viewer = `<video src="${preview.dataUrl}" controls autoplay class="w-full max-h-[65vh] rounded-xl bg-black"></video>`;
    } else if (preview.kind === 'audio' && preview.dataUrl) {
        viewer = `<audio src="${preview.dataUrl}" controls autoplay class="w-full"></audio>`;
    } else if (preview.kind === 'pdf' && preview.dataUrl) {
        viewer = `<embed src="${preview.dataUrl}" type="application/pdf" class="w-full h-[65vh] rounded-xl bg-white/5" />`;
    } else if (preview.text) {
        viewer = `<pre class="text-xs whitespace-pre-wrap break-words bg-black/40 rounded-xl p-4 max-h-[65vh] overflow-auto">${escapeHtml(preview.text)}</pre>`;
    } else {
        viewer = `<p class="text-gray-400 text-sm">${escapeHtml(preview.message || t('previewNoInline'))}</p>`;
    }

    modal.body.innerHTML = `
        ${meta}
        ${viewer}
        <div class="flex flex-wrap gap-2 mt-4">
            <button id="preview-save" class="px-3 py-2 text-sm rounded-xl bg-blue-600 hover:bg-blue-700">${escapeHtml(t('saveToPc'))}…</button>
            <button id="preview-open" class="px-3 py-2 text-sm rounded-xl bg-white/5 hover:bg-white/10 border border-white/10">${escapeHtml(t('openExternally'))}</button>
        </div>${entry ? `<div class="text-xs text-gray-500 mt-2">${escapeHtml(entry.modified || '')}</div>` : ''}`;

    if (preview.kind === 'archive') {
        const zipHost = document.getElementById('zip-browser');
        if (zipHost) loadZipBrowser(path, zipHost);
    }

    const save = document.getElementById('preview-save');
    if (save) {
        save.addEventListener('click', async () => {
            try {
                // The user always picks the destination folder.
                const folder = await ChooseFolder(t('saveToPc'));
                if (!folder) return;
                const dest = await SaveFileToPC(path, folder);
                toast(`${t('recoverySavedTo')} ${dest}`, 'success');
            } catch (err) {
                toast(err.message || String(err), 'error');
            }
        });
    }
    const openExternal = document.getElementById('preview-open');
    if (openExternal) {
        openExternal.addEventListener('click', async () => {
            try {
                await OpenFileExternally(path);
            } catch (err) {
                toast(err.message || String(err), 'error');
            }
        });
    }
}

// loadZipBrowser lists what is INSIDE a zip on the phone and previews single
// entries (text/images/videos) without extracting the archive to the disk.
async function loadZipBrowser(path, container) {
    let entries;
    try {
        entries = await ListZipContents(path);
    } catch (err) {
        container.innerHTML = `<p class="text-red-400 text-sm">${escapeHtml(err.message || String(err))}</p>`;
        return;
    }
    if (!isValidEntryList(entries)) {
        container.innerHTML = `<p class="text-gray-400 text-sm">${escapeHtml(t('zipEmpty'))}</p>`;
        return;
    }

    const renderList = (filter) => {
        const query = (filter || '').trim().toLowerCase();
        const visible = entries.filter((item) => !item.isDir && (!query || item.name.toLowerCase().includes(query)));
        const totalBytes = entries.reduce((sum, item) => sum + (item.size || 0), 0);
        container.innerHTML = `
            <div class="flex flex-wrap items-center justify-between gap-2 mb-1">
                <div class="text-sm text-gray-300">${entries.length} ${escapeHtml(t('zipEntries'))} • ${formatBytes(totalBytes)}</div>
            </div>
            <p class="text-xs text-gray-500 mb-2">${escapeHtml(t('zipOpenHint'))}</p>
            <input id="zip-filter" value="${escapeHtml(filter || '')}" placeholder="${escapeHtml(t('search'))}"
                   class="w-full bg-white/5 border border-white/10 rounded-xl px-3 py-2 text-sm mb-2 text-white placeholder:text-gray-500" />
            <div class="max-h-[45vh] overflow-y-auto scroll-area space-y-1">
                ${visible.length === 0 ? `<div class="text-gray-400 text-sm p-2">${escapeHtml(t('zipEmpty'))}</div>` : visible.map((item) => `
                    <button data-zip-entry="${escapeHtml(item.name)}" class="w-full text-left bg-white/5 hover:bg-white/10 border border-white/10 rounded-xl px-3 py-2 flex items-center gap-3 text-sm">
                        <span class="w-8 h-8 shrink-0 rounded-lg bg-white/5 flex items-center justify-center">${escapeHtml(glyphForName(item.name))}</span>
                        <span class="min-w-0 flex-1 truncate">${escapeHtml(item.name)}</span>
                        <span class="text-xs text-gray-500 shrink-0">${formatBytes(item.size)}</span>
                    </button>`).join('')}
            </div>`;

        const filterInput = container.querySelector('#zip-filter');
        if (filterInput) {
            filterInput.addEventListener('input', () => {
                const value = filterInput.value;
                if (value === (filter || '')) return;
                renderList(value);
                const refreshed = container.querySelector('#zip-filter');
                if (refreshed) { refreshed.focus(); refreshed.setSelectionRange(value.length, value.length); }
            });
        }
        container.querySelectorAll('[data-zip-entry]').forEach((button) => {
            button.addEventListener('click', () => openZipEntry(path, button.dataset.zipEntry, container, filter));
        });
    };

    renderList('');
}

function isValidEntryList(entries) {
    return Array.isArray(entries) && entries.length > 0;
}

async function openZipEntry(path, entryName, container, previousFilter) {
    container.innerHTML = `
        <button id="zip-back" class="px-3 py-1.5 text-xs rounded-full bg-white/5 hover:bg-white/10 border border-white/10 mb-3">← ${escapeHtml(t('zipBack'))}</button>
        <div class="text-xs text-gray-400 mb-2 truncate">${escapeHtml(entryName)}</div>
        <div class="text-gray-400 text-sm" id="zip-entry-body">${escapeHtml(t('loading'))}</div>`;
    container.querySelector('#zip-back').addEventListener('click', () => loadZipBrowser(path, container));

    let preview;
    try {
        preview = await ReadZipEntry(path, entryName);
    } catch (err) {
        const body = container.querySelector('#zip-entry-body');
        if (body) body.innerHTML = `<p class="text-red-400 text-sm">${escapeHtml(err.message || String(err))}</p>`;
        return;
    }
    const body = container.querySelector('#zip-entry-body');
    if (!body) return;
    if (preview.tooLarge) {
        body.innerHTML = `<p class="text-amber-300 text-sm">${escapeHtml(preview.message || t('previewTooLarge'))}</p>`;
    } else if (preview.kind === 'image' && preview.dataUrl) {
        body.innerHTML = `<img src="${preview.dataUrl}" class="max-h-[55vh] w-auto mx-auto rounded-xl" alt="" />`;
    } else if (preview.kind === 'video' && preview.dataUrl) {
        body.innerHTML = `<video src="${preview.dataUrl}" controls class="w-full max-h-[55vh] rounded-xl bg-black"></video>`;
    } else if (preview.kind === 'audio' && preview.dataUrl) {
        body.innerHTML = `<audio src="${preview.dataUrl}" controls class="w-full"></audio>`;
    } else if (preview.kind === 'pdf' && preview.dataUrl) {
        body.innerHTML = `<embed src="${preview.dataUrl}" type="application/pdf" class="w-full h-[55vh] rounded-xl bg-white/5" />`;
    } else if (preview.text) {
        body.innerHTML = `<pre class="text-xs whitespace-pre-wrap break-words bg-black/40 rounded-xl p-4 max-h-[55vh] overflow-auto">${escapeHtml(preview.text)}</pre>`;
    } else {
        body.innerHTML = `<p class="text-gray-400 text-sm">${escapeHtml(preview.message || t('previewNoInline'))}</p>`;
    }
}

/* ------------------------------------------------------------------ *
 * Onboarding gate
 *
 * Before any device data is read the app walks the user through:
 *   no_usb      -> plug the phone in (detected with libusb, not adb)
 *   usb_only    -> enable Developer options + USB debugging
 *   unauthorized-> approve the ADB prompt on the phone
 *   ready       -> "getting data ready" while apps/files/icons are loaded
 * Any bad state simply falls back to the matching screen and the poll keeps
 * running, so a flaky USB link recovers without the user starting over.
 * ------------------------------------------------------------------ */

const ONBOARDING_POLL_MS = 1500;

function onboardingRoot() {
    return document.getElementById('onboarding-root');
}

function spinner() {
    return `<svg class="w-5 h-5 animate-spin text-blue-400 shrink-0" viewBox="0 0 24 24" fill="none">
        <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
        <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z"></path>
    </svg>`;
}

function showOnboarding() {
    if (!onboardingRoot()) return;
    state.onboarding.active = true;
    state.onboarding.done = false;
    state.onboarding.skipped = false;
    state.onboarding.error = '';
    state.onboarding.lastKey = '';
    state.onboarding.prepareFailed = false;
    renderOnboarding();
    startOnboardingPoll();
}

function hideOnboarding() {
    state.onboarding.active = false;
    stopOnboardingPoll();
    const root = onboardingRoot();
    if (root) root.innerHTML = '';
}

function stopOnboardingPoll() {
    if (state.onboarding.pollTimer) {
        clearInterval(state.onboarding.pollTimer);
        state.onboarding.pollTimer = null;
    }
}

function startOnboardingPoll() {
    stopOnboardingPoll();
    pollDeviceState();
    state.onboarding.pollTimer = setInterval(pollDeviceState, ONBOARDING_POLL_MS);
}

async function pollDeviceState() {
    const onb = state.onboarding;
    if (!onb.active || onb.preparing) return;
    try {
        const deviceState = await CheckDeviceState();
        applyDeviceState(deviceState);
    } catch (err) {
        onb.error = err.message || String(err);
        renderOnboarding();
    }
}

// applyDeviceState is the single funnel through which every device sample — from
// polling, from an ADB authorization request, or from a device:state event — flows.
function applyDeviceState(deviceState) {
    if (!deviceState) return;
    const onb = state.onboarding;
    onb.state = deviceState;
    onb.error = '';

    const stage = deviceState.stage || 'no_usb';
    onb.stage = stage;

    if (deviceState.canProceed) {
        stopOnboardingPoll();
        // A preparation failure is surfaced with an explicit Retry button instead
        // of being retried on every poll tick, which would hammer a stuck device.
        if (!onb.preparing && !onb.done && !onb.prepareFailed) runPreparation();
        return;
    }
    // Leaving the ready state clears the failure so reconnecting recovers by itself.
    onb.prepareFailed = false;

    // Only repaint when something meaningful changed, so the screen stays stable.
    const key = [stage, deviceState.usbDeviceCount || 0, deviceState.adbStatus || '', deviceState.adbDeviceId || ''].join('|');
    if (key !== onb.lastKey) {
        onb.lastKey = key;
        renderOnboarding();
    }
}

async function runPreparation(forceRefresh) {
    const onb = state.onboarding;
    if (onb.preparing) return;
    onb.preparing = true;
    onb.error = '';
    onb.progress = { stage: 'apps', percent: 2, message: t('onbGettingReady') };
    renderOnboarding();

    try {
        const session = await PrepareSession({
            includeApps: true,
            includeFiles: true,
            iconMode: state.apps.iconOptions.mode,
            apkFolder: state.apps.iconOptions.folder || '',
            workers: state.apps.iconOptions.workers,
            // System apps use the built-in Android icon (as documented): it keeps
            // the extraction pass focused on the apps the user actually sees.
            genericSystem: true,
            forceRefresh: !!forceRefresh,
            fileRoot: '/sdcard',
        });
        onb.preparing = false;
        if (session) seedSessionState(session);
        // The gate may have been skipped while this was running in the
        // background — refresh whatever view is open instead of forcing the
        // waiting screen back on top of the user.
        if (!onb.active) {
            toast(t('onbReadyTitle'), 'success');
            navigate(state.view || 'dashboard');
            return;
        }
        onb.done = true;
        onb.progress = { percent: 100, message: t('onbReadyTitle') };
        renderOnboarding();
        setTimeout(() => {
            hideOnboarding();
            navigate(state.view || 'dashboard');
        }, 600);
    } catch (err) {
        onb.preparing = false;
        onb.prepareFailed = true;
        onb.error = err.message || String(err);
        if (!onb.active) {
            // Skipped gate: show the failure as a toast instead of a screen
            // nobody is looking at. Reopening the gate re-probes the device.
            toast(onb.error, 'error');
            return;
        }
        renderOnboarding();
        // Watch for the device again so an unplugged cable recovers by itself.
        startOnboardingPoll();
    }
}

function onboardingShell(inner) {
    return `<div class="fixed inset-0 z-[90] bg-[#0b0d12]/85 backdrop-blur-xl flex items-center justify-center p-6">
        <div class="w-full max-w-2xl bg-[#141821] border border-white/10 rounded-2xl shadow-2xl max-h-[92vh] overflow-y-auto scroll-area">${inner}</div>
    </div>`;
}

function onboardingHeader(icon, title, subtitle) {
    return `<div class="px-6 pt-6 pb-4 border-b border-white/10 flex items-start gap-4">
        <div class="w-12 h-12 shrink-0 rounded-2xl bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-2xl">${icon}</div>
        <div class="min-w-0">
            <h2 class="text-xl font-semibold">${escapeHtml(title)}</h2>
            <p class="text-sm text-gray-400 mt-1 leading-relaxed">${escapeHtml(subtitle)}</p>
        </div>
    </div>`;
}

function onboardingFooter(secondaryId, secondaryLabel, primaryId, primaryLabel, primaryDisabled) {
    return `<div class="px-6 py-5 flex items-center justify-between gap-3">
        <button id="${secondaryId}" class="px-4 py-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-sm">${escapeHtml(secondaryLabel)}</button>
        <button id="${primaryId}" ${primaryDisabled ? 'disabled' : ''} class="px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 font-medium disabled:opacity-50">${escapeHtml(primaryLabel)}</button>
    </div>`;
}

function usbDeviceListMarkup(deviceState) {
    const devices = (deviceState && deviceState.usbDevices) || [];
    if (devices.length === 0) return '';
    const chips = devices.map((device) => {
        const name = device.vendorName || `${device.vendorId}:${device.productId}`;
        const tone = device.android
            ? 'bg-emerald-500/15 border-emerald-400/30 text-emerald-200'
            : 'bg-white/5 border-white/10 text-gray-300';
        const dot = device.android ? 'bg-emerald-400' : 'bg-gray-500';
        return `<span class="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs border ${tone}">
            <span class="w-1.5 h-1.5 rounded-full ${dot}"></span>${escapeHtml(name)}</span>`;
    }).join('');
    return `<div class="mt-5">
        <div class="text-xs uppercase tracking-wide text-gray-500 mb-2">${escapeHtml(t('onbUsbDevices'))}</div>
        <div class="flex flex-wrap gap-2">${chips}</div>
    </div>`;
}

function onboardingWaitingUSB() {
    const deviceState = state.onboarding.state || {};
    const hint = deviceState.usbDeviceCount > 0 && !deviceState.androidUsb ? t('onbNoPhoneYet') : '';
    return onboardingShell(`
        ${onboardingHeader('🔌', t('onbConnectTitle'), t('onbConnectDesc'))}
        <div class="px-6 pt-5">
            <div class="flex items-center gap-3 text-gray-300">${spinner()}<span>${escapeHtml(t('onbConnectHint'))}</span></div>
            ${usbDeviceListMarkup(deviceState)}
            ${hint ? `<p class="text-xs text-amber-300 mt-3">${escapeHtml(hint)}</p>` : ''}
            ${deviceState.usbError ? `<p class="text-xs text-amber-300 mt-2">${escapeHtml(deviceState.usbError)}</p>` : ''}
        </div>
        ${onboardingFooter('onb-skip', t('onbSkip'), 'onb-recheck', t('onbCheckAgain'), false)}`);
}

function onboardingGuide() {
    const steps = [1, 2, 3, 4].map((n) => `
        <div class="flex items-start gap-3">
            <div class="w-7 h-7 shrink-0 rounded-full bg-blue-500 flex items-center justify-center text-sm font-bold">${n}</div>
            <div class="min-w-0">
                <h3 class="font-medium text-white">${escapeHtml(t('step' + n + 'Title'))}</h3>
                <p class="text-sm text-gray-400 mt-0.5">${escapeHtml(t('step' + n + 'Desc'))}</p>
            </div>
        </div>`).join('');
    return onboardingShell(`
        ${onboardingHeader('🐛', t('onbEnableTitle'), t('onbEnableDesc'))}
        <div class="px-6 pt-5">
            <div class="space-y-4">${steps}</div>
            <p class="text-xs text-amber-300 mt-4 leading-relaxed">${escapeHtml(t('onbUsbModeHint'))}</p>
        </div>
        ${onboardingFooter('onb-skip', t('onbSkip'), 'onb-enabled', t('onbDone'), false)}`);
}

function onboardingAuthorize() {
    const deviceState = state.onboarding.state || {};
    const deviceLine = deviceState.adbDeviceId
        ? `<div class="mt-4 text-xs text-gray-400">${escapeHtml(t('onbDeviceLabel'))}: <span class="text-gray-200">${escapeHtml(deviceState.deviceModel || deviceState.adbDeviceId)}</span> <span class="text-amber-300">(${escapeHtml(deviceState.adbStatus || '')})</span></div>`
        : '';
    return onboardingShell(`
        ${onboardingHeader('📲', t('onbAuthorizeTitle'), t('onbAuthorizeDesc'))}
        <div class="px-6 pt-5">
            <div class="flex items-center gap-3 text-gray-300">${spinner()}<span>${escapeHtml(t('onbAuthorizeHint'))}</span></div>
            ${deviceLine}
        </div>
        ${onboardingFooter('onb-skip', t('onbSkip'), 'onb-check', t('onbCheckAgain'), false)}`);
}

function onboardingPreparing() {
    const progress = state.onboarding.progress || { percent: 2, message: t('onbGettingReady') };
    const width = Math.max(4, Math.min(100, progress.percent || 0));
    return onboardingShell(`
        ${onboardingHeader('⚙️', t('onbGettingReady'), t('onbPreparingDesc'))}
        <div class="px-6 py-6">
            <div class="w-full h-3 bg-white/10 rounded-full overflow-hidden">
                <div id="onb-progress-bar" class="h-full bg-gradient-to-r from-blue-500 to-emerald-500 transition-all" style="width:${width}%"></div>
            </div>
            <div class="flex justify-between text-xs text-gray-400 mt-2 gap-3">
                <span id="onb-progress-message" class="truncate">${escapeHtml(progress.message || t('onbGettingReady'))}</span>
                <span id="onb-progress-percent">${progress.percent || 0}%</span>
            </div>
            <div class="flex justify-end mt-5">
                <button id="onb-skip" class="px-3 py-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-sm">${escapeHtml(t('onbSkip'))}</button>
            </div>
        </div>`);
}

function onboardingProblem(icon, title, message) {
    return onboardingShell(`
        ${onboardingHeader(icon, title, message)}
        ${onboardingFooter('onb-skip', t('onbSkip'), 'onb-retry', t('onbRetry'), false)}`);
}

function renderOnboarding() {
    const root = onboardingRoot();
    if (!root) return;
    const onb = state.onboarding;
    if (!onb.active) {
        root.innerHTML = '';
        return;
    }
    if (onb.error) {
        root.innerHTML = onboardingProblem('⚠️', t('onbErrorTitle'), onb.error);
    } else if (onb.preparing || onb.done) {
        root.innerHTML = onboardingPreparing();
    } else {
        switch (onb.stage) {
            case 'ready':
                root.innerHTML = onboardingPreparing();
                break;
            case 'authorize':
            case 'unauthorized':
                root.innerHTML = onboardingAuthorize();
                break;
            case 'usb_only':
                root.innerHTML = onboardingGuide();
                break;
            case 'no_adb_binary':
                root.innerHTML = onboardingProblem('🧰', t('onbAdbMissingTitle'), t('onbAdbMissingDesc'));
                break;
            case 'offline':
                root.innerHTML = onboardingProblem('🔁', t('onbOfflineTitle'), t('onbOfflineDesc'));
                break;
            default:
                root.innerHTML = onboardingWaitingUSB();
        }
    }
    bindOnboarding();
}

function updateOnboardingProgress() {
    const progress = state.onboarding.progress || {};
    const bar = document.getElementById('onb-progress-bar');
    if (bar) bar.style.width = `${Math.max(4, Math.min(100, progress.percent || 0))}%`;
    const percent = document.getElementById('onb-progress-percent');
    if (percent) percent.textContent = `${progress.percent || 0}%`;
    const message = document.getElementById('onb-progress-message');
    if (message && progress.message) message.textContent = progress.message;
}

// askADB restarts the ADB server (which makes the phone show its prompt) and waits
// for the user to accept it, repainting live from the device:state events.
async function askADB(button, timeoutMs) {
    if (button) {
        button.disabled = true;
        button.textContent = t('onbGettingReady');
    }
    stopOnboardingPoll();
    state.onboarding.stage = 'authorize';
    renderOnboarding();
    try {
        const deviceState = await RequestADBAuthorization(timeoutMs);
        applyDeviceState(deviceState);
    } catch (err) {
        state.onboarding.error = err.message || String(err);
        renderOnboarding();
    } finally {
        // Still not usable? Keep watching so no manual restart is ever needed.
        if (!state.onboarding.preparing && !state.onboarding.done) {
            startOnboardingPoll();
        }
    }
}

function bindOnboarding() {
    const skip = document.getElementById('onb-skip');
    if (skip) {
        skip.addEventListener('click', () => {
            hideOnboarding();
            toast(t('onbSkip'), 'info');
        });
    }

    const check = document.getElementById('onb-check');
    if (check) {
        check.addEventListener('click', () => askADB(check, 20000));
    }

    const enabled = document.getElementById('onb-enabled');
    if (enabled) {
        enabled.addEventListener('click', () => askADB(enabled, 30000));
    }

    const recheck = document.getElementById('onb-recheck');
    if (recheck) {
        recheck.addEventListener('click', () => pollDeviceState());
    }

    const retry = document.getElementById('onb-retry');
    if (retry) {
        retry.addEventListener('click', () => {
            const onb = state.onboarding;
            onb.error = '';
            onb.prepareFailed = false;
            renderOnboarding();
            // Ready but the last load failed -> retry the load; otherwise re-probe.
            if (onb.state && onb.state.canProceed) runPreparation();
            else startOnboardingPoll();
        });
    }
}

/* ------------------------------------------------------------------ *
 * Shell wiring + init
 * ------------------------------------------------------------------ */

function renderNav() {
    const icons = {
        dashboard: '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zm10 0a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zm10 0a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z"></path>',
        apps: '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 18h.01M8 21h8a2 2 0 002-2V5a2 2 0 00-2-2H8a2 2 0 00-2 2v14a2 2 0 002 2z"></path>',
        backup: '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7H5a2 2 0 00-2 2v9a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-3m-1 4l-3 3m0 0l-3-3m3 3V4"></path>',
        tasks: '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"></path>',
        files: '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-6l-2-2H5a2 2 0 00-2 2z"></path>',
        guide: '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>',
    };
    Object.entries(icons).forEach(([name, path]) => {
        const el = document.getElementById('nav-' + name);
        if (!el) return;
        el.innerHTML = `<svg class="w-5 h-5 mr-3 rtl:ml-3 rtl:mr-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">${path}</svg><span>${escapeHtml(t(name))}</span>`;
    });
    const brand = document.getElementById('brand-text');
    if (brand) brand.innerText = t('brand');
    const langSwitch = document.getElementById('lang-switch');
    if (langSwitch) langSwitch.innerText = t('langSwitch');
    const refresh = document.getElementById('refresh-btn');
    if (refresh) refresh.innerText = t('scan');
}

function applyLanguage() {
    document.documentElement.dir = state.lang === 'ar' ? 'rtl' : 'ltr';
    renderNav();
}

document.getElementById('lang-switch').addEventListener('click', () => {
    state.lang = state.lang === 'en' ? 'ar' : 'en';
    applyLanguage();
    navigate(state.view);
});

document.querySelectorAll('.nav-item').forEach((item) => {
    item.addEventListener('click', () => navigate(item.dataset.view));
});

// The header button both rescans and, when nothing is attached, reopens the
// onboarding gate so the user is never stuck without a way back in.
document.getElementById('refresh-btn').addEventListener('click', async () => {
    let devices = [];
    try {
        devices = (await GetConnectedDevices()) || [];
    } catch (err) {
        devices = [];
    }
    if (devices.length === 0) {
        showOnboarding();
        return;
    }
    scanDevices(state.token, state.view);
});

// Live progress from the Go side. Scoped to the currently visible view.
try {
    EventsOn('transfer:progress', (payload) => {
        if (!payload) return;
        // Plan building happens before any transfer panel exists; it streams its
        // status to whatever is on screen (review card or transfer panel).
        if (payload.operation === 'plan') {
            const planStatus = document.getElementById('plan-status');
            if (planStatus && payload.message) planStatus.textContent = payload.message;
            const panel = document.getElementById('transfer-message');
            if (panel && payload.message) panel.textContent = payload.message;
            return;
        }
        if (state.transferHandler) state.transferHandler(payload);
    });

    // Device samples streamed while the onboarding gate waits for a phone.
    EventsOn('device:state', (deviceState) => {
        if (!state.onboarding.active || state.onboarding.preparing) return;
        applyDeviceState(deviceState);
    });

    // "Getting data ready" progress.
    EventsOn('session:progress', (payload) => {
        if (!payload) return;
        state.onboarding.progress = payload;
        updateOnboardingProgress();
    });

    // Icon extraction progress (onboarding and the app manager both use it).
    EventsOn('icons:progress', (payload) => {
        if (!payload || !payload.total) return;
        const line = `${t('extractingIcons')} ${payload.completed} / ${payload.total}`
            + (payload.failed ? ` · ${payload.failed} ${t('backupFailed')}` : '');
        const appProgress = document.getElementById('apps-icon-progress');
        if (appProgress) appProgress.textContent = line;
        if (state.onboarding.preparing) {
            // Keep the waiting screen moving: the bar follows the icon batch
            // instead of sitting frozen on the stage's starting percentage.
            const progress = state.onboarding.progress || {};
            state.onboarding.progress = {
                ...progress,
                stage: 'icons',
                message: (payload.done && payload.message) ? payload.message : line,
                percent: Math.max(progress.percent || 0, payload.percent || 0),
            };
            updateOnboardingProgress();
        }
    });
} catch (err) {
    // Running outside the Wails runtime (e.g. plain vite preview) — no events.
    console.warn('runtime events unavailable:', err);
}

// Boot: paint from any cached session first so the UI is instant, then open the
// onboarding gate that verifies the device and (re)loads the data.
applyLanguage();
navigate('dashboard');
ensureGenericIcon();

(async () => {
    try {
        const cached = await GetCachedSession();
        if (cached) seedSessionState(cached);
    } catch (err) {
        // No cache yet is completely normal.
    }
    // Backups and restores share the same absolute per-device folder (keyed by the
    // device model), so a backup is always where the restore screen looks for it.
    await ensureDefaultBackupFolders();
    showOnboarding();
})();
