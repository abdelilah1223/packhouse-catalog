export namespace main {
	
	export class AndroidFileEntry {
	    name: string;
	    path: string;
	    isDir: boolean;
	    size: number;
	    modified: string;
	    kind: string;
	    mimeType: string;
	    isSymlink: boolean;
	
	    static createFrom(source: any = {}) {
	        return new AndroidFileEntry(source);
	    }
	
	    constructor(source: any = {}) {
	        if ('string' === typeof source) source = JSON.parse(source);
	        this.name = source["name"];
	        this.path = source["path"];
	        this.isDir = source["isDir"];
	        this.size = source["size"];
	        this.modified = source["modified"];
	        this.kind = source["kind"];
	        this.mimeType = source["mimeType"];
	        this.isSymlink = source["isSymlink"];
	    }
	}
	export class AppBackupItem {
	    package: string;
	    name: string;
	    isSystem: boolean;
	    apkPaths: string[];
	    totalBytes: number;
	    error: string;
	
	    static createFrom(source: any = {}) {
	        return new AppBackupItem(source);
	    }
	
	    constructor(source: any = {}) {
	        if ('string' === typeof source) source = JSON.parse(source);
	        this.package = source["package"];
	        this.name = source["name"];
	        this.isSystem = source["isSystem"];
	        this.apkPaths = source["apkPaths"];
	        this.totalBytes = source["totalBytes"];
	        this.error = source["error"];
	    }
	}
	export class AppBackupPlan {
	    targetFolder: string;
	    items: AppBackupItem[];
	    totalFiles: number;
	    totalBytes: number;
	
	    static createFrom(source: any = {}) {
	        return new AppBackupPlan(source);
	    }
	
	    constructor(source: any = {}) {
	        if ('string' === typeof source) source = JSON.parse(source);
	        this.targetFolder = source["targetFolder"];
	        this.items = this.convertValues(source["items"], AppBackupItem);
	        this.totalFiles = source["totalFiles"];
	        this.totalBytes = source["totalBytes"];
	    }
	
		convertValues(a: any, classs: any, asMap: boolean = false): any {
		    if (!a) {
		        return a;
		    }
		    if (a.slice && a.map) {
		        return (a as any[]).map(elem => this.convertValues(elem, classs));
		    } else if ("object" === typeof a) {
		        if (asMap) {
		            for (const key of Object.keys(a)) {
		                a[key] = new classs(a[key]);
		            }
		            return a;
		        }
		        return new classs(a);
		    }
		    return a;
		}
	}
	export class AppData {
	    list: string;
	    description: string;
	    dependencies: string[];
	    neededBy: string[];
	    labels: string[];
	    removal: string;
	
	    static createFrom(source: any = {}) {
	        return new AppData(source);
	    }
	
	    constructor(source: any = {}) {
	        if ('string' === typeof source) source = JSON.parse(source);
	        this.list = source["list"];
	        this.description = source["description"];
	        this.dependencies = source["dependencies"];
	        this.neededBy = source["neededBy"];
	        this.labels = source["labels"];
	        this.removal = source["removal"];
	    }
	}
	export class AppInfo {
	    packageName: string;
	    name: string;
	    icon: string;
	    path: string;
	    isSystem: boolean;
	    isThirdParty: boolean;
	    isLaunchable: boolean;
	    isServiceLike: boolean;
	    isDisabled: boolean;
	    recommended: string;
	    isSafe: boolean;
	
	    static createFrom(source: any = {}) {
	        return new AppInfo(source);
	    }
	
	    constructor(source: any = {}) {
	        if ('string' === typeof source) source = JSON.parse(source);
	        this.packageName = source["packageName"];
	        this.name = source["name"];
	        this.icon = source["icon"];
	        this.path = source["path"];
	        this.isSystem = source["isSystem"];
	        this.isThirdParty = source["isThirdParty"];
	        this.isLaunchable = source["isLaunchable"];
	        this.isServiceLike = source["isServiceLike"];
	        this.isDisabled = source["isDisabled"];
	        this.recommended = source["recommended"];
	        this.isSafe = source["isSafe"];
	    }
	}
	export class BackupCategory {
	    id: string;
	    label: string;
	    remotePath: string;
	    description: string;
	    available: boolean;
	    recursive: boolean;
	
	    static createFrom(source: any = {}) {
	        return new BackupCategory(source);
	    }
	
	    constructor(source: any = {}) {
	        if ('string' === typeof source) source = JSON.parse(source);
	        this.id = source["id"];
	        this.label = source["label"];
	        this.remotePath = source["remotePath"];
	        this.description = source["description"];
	        this.available = source["available"];
	        this.recursive = source["recursive"];
	    }
	}
	export class BackupPlanItem {
	    category: string;
	    label: string;
	    remotePath: string;
	    fileCount: number;
	    totalBytes: number;
	    available: boolean;
	    error: string;
	
	    static createFrom(source: any = {}) {
	        return new BackupPlanItem(source);
	    }
	
	    constructor(source: any = {}) {
	        if ('string' === typeof source) source = JSON.parse(source);
	        this.category = source["category"];
	        this.label = source["label"];
	        this.remotePath = source["remotePath"];
	        this.fileCount = source["fileCount"];
	        this.totalBytes = source["totalBytes"];
	        this.available = source["available"];
	        this.error = source["error"];
	    }
	}
	export class BackupPlan {
	    targetFolder: string;
	    items: BackupPlanItem[];
	    totalFiles: number;
	    totalBytes: number;
	
	    static createFrom(source: any = {}) {
	        return new BackupPlan(source);
	    }
	
	    constructor(source: any = {}) {
	        if ('string' === typeof source) source = JSON.parse(source);
	        this.targetFolder = source["targetFolder"];
	        this.items = this.convertValues(source["items"], BackupPlanItem);
	        this.totalFiles = source["totalFiles"];
	        this.totalBytes = source["totalBytes"];
	    }
	
		convertValues(a: any, classs: any, asMap: boolean = false): any {
		    if (!a) {
		        return a;
		    }
		    if (a.slice && a.map) {
		        return (a as any[]).map(elem => this.convertValues(elem, classs));
		    } else if ("object" === typeof a) {
		        if (asMap) {
		            for (const key of Object.keys(a)) {
		                a[key] = new classs(a[key]);
		            }
		            return a;
		        }
		        return new classs(a);
		    }
		    return a;
		}
	}
	
	export class CallLogItem {
	    name: string;
	    number: string;
	    type: string;
	    date: string;
	
	    static createFrom(source: any = {}) {
	        return new CallLogItem(source);
	    }
	
	    constructor(source: any = {}) {
	        if ('string' === typeof source) source = JSON.parse(source);
	        this.name = source["name"];
	        this.number = source["number"];
	        this.type = source["type"];
	        this.date = source["date"];
	    }
	}
	export class Device {
	    id: string;
	    status: string;
	    model: string;
	
	    static createFrom(source: any = {}) {
	        return new Device(source);
	    }
	
	    constructor(source: any = {}) {
	        if ('string' === typeof source) source = JSON.parse(source);
	        this.id = source["id"];
	        this.status = source["status"];
	        this.model = source["model"];
	    }
	}
	export class SessionIcon {
	    packageName: string;
	    dataUrl: string;
	    source: string;
	    filePath: string;
	
	    static createFrom(source: any = {}) {
	        return new SessionIcon(source);
	    }
	
	    constructor(source: any = {}) {
	        if ('string' === typeof source) source = JSON.parse(source);
	        this.packageName = source["packageName"];
	        this.dataUrl = source["dataUrl"];
	        this.source = source["source"];
	        this.filePath = source["filePath"];
	    }
	}
	export class DeviceSession {
	    version: string;
	    serial: string;
	    model: string;
	    apps: AppInfo[];
	    fileRoot: string;
	    fileRoots: Record<string, Array<AndroidFileEntry>>;
	    icons: SessionIcon[];
	    iconMode: string;
	    savedAt: string;
	    fromCache: boolean;
	
	    static createFrom(source: any = {}) {
	        return new DeviceSession(source);
	    }
	
	    constructor(source: any = {}) {
	        if ('string' === typeof source) source = JSON.parse(source);
	        this.version = source["version"];
	        this.serial = source["serial"];
	        this.model = source["model"];
	        this.apps = this.convertValues(source["apps"], AppInfo);
	        this.fileRoot = source["fileRoot"];
	        this.fileRoots = this.convertValues(source["fileRoots"], Array<AndroidFileEntry>, true);
	        this.icons = this.convertValues(source["icons"], SessionIcon);
	        this.iconMode = source["iconMode"];
	        this.savedAt = source["savedAt"];
	        this.fromCache = source["fromCache"];
	    }
	
		convertValues(a: any, classs: any, asMap: boolean = false): any {
		    if (!a) {
		        return a;
		    }
		    if (a.slice && a.map) {
		        return (a as any[]).map(elem => this.convertValues(elem, classs));
		    } else if ("object" === typeof a) {
		        if (asMap) {
		            for (const key of Object.keys(a)) {
		                a[key] = new classs(a[key]);
		            }
		            return a;
		        }
		        return new classs(a);
		    }
		    return a;
		}
	}
	export class USBDevice {
	    bus: number;
	    address: number;
	    vendorId: string;
	    productId: string;
	    vendorName: string;
	    class: number;
	    mtp: boolean;
	    adbInterface: boolean;
	    android: boolean;
	
	    static createFrom(source: any = {}) {
	        return new USBDevice(source);
	    }
	
	    constructor(source: any = {}) {
	        if ('string' === typeof source) source = JSON.parse(source);
	        this.bus = source["bus"];
	        this.address = source["address"];
	        this.vendorId = source["vendorId"];
	        this.productId = source["productId"];
	        this.vendorName = source["vendorName"];
	        this.class = source["class"];
	        this.mtp = source["mtp"];
	        this.adbInterface = source["adbInterface"];
	        this.android = source["android"];
	    }
	}
	export class DeviceState {
	    adbInstalled: boolean;
	    adbError: string;
	    usbConnected: boolean;
	    usbError: string;
	    usbDeviceCount: number;
	    usbDevices: USBDevice[];
	    androidUsb: boolean;
	    usbDevice?: USBDevice;
	    adbDeviceId: string;
	    adbStatus: string;
	    deviceModel: string;
	    stage: string;
	    canProceed: boolean;
	    message: string;
	
	    static createFrom(source: any = {}) {
	        return new DeviceState(source);
	    }
	
	    constructor(source: any = {}) {
	        if ('string' === typeof source) source = JSON.parse(source);
	        this.adbInstalled = source["adbInstalled"];
	        this.adbError = source["adbError"];
	        this.usbConnected = source["usbConnected"];
	        this.usbError = source["usbError"];
	        this.usbDeviceCount = source["usbDeviceCount"];
	        this.usbDevices = this.convertValues(source["usbDevices"], USBDevice);
	        this.androidUsb = source["androidUsb"];
	        this.usbDevice = this.convertValues(source["usbDevice"], USBDevice);
	        this.adbDeviceId = source["adbDeviceId"];
	        this.adbStatus = source["adbStatus"];
	        this.deviceModel = source["deviceModel"];
	        this.stage = source["stage"];
	        this.canProceed = source["canProceed"];
	        this.message = source["message"];
	    }
	
		convertValues(a: any, classs: any, asMap: boolean = false): any {
		    if (!a) {
		        return a;
		    }
		    if (a.slice && a.map) {
		        return (a as any[]).map(elem => this.convertValues(elem, classs));
		    } else if ("object" === typeof a) {
		        if (asMap) {
		            for (const key of Object.keys(a)) {
		                a[key] = new classs(a[key]);
		            }
		            return a;
		        }
		        return new classs(a);
		    }
		    return a;
		}
	}
	export class FilePreview {
	    path: string;
	    name: string;
	    kind: string;
	    mimeType: string;
	    dataUrl: string;
	    text: string;
	    size: number;
	    tooLarge: boolean;
	    downloadLimit: number;
	    message: string;
	
	    static createFrom(source: any = {}) {
	        return new FilePreview(source);
	    }
	
	    constructor(source: any = {}) {
	        if ('string' === typeof source) source = JSON.parse(source);
	        this.path = source["path"];
	        this.name = source["name"];
	        this.kind = source["kind"];
	        this.mimeType = source["mimeType"];
	        this.dataUrl = source["dataUrl"];
	        this.text = source["text"];
	        this.size = source["size"];
	        this.tooLarge = source["tooLarge"];
	        this.downloadLimit = source["downloadLimit"];
	        this.message = source["message"];
	    }
	}
	export class IconExtractRequest {
	    packages: string[];
	    mode: string;
	    apkFolder: string;
	    workers: number;
	    skipCached: boolean;
	    genericSystem: boolean;
	
	    static createFrom(source: any = {}) {
	        return new IconExtractRequest(source);
	    }
	
	    constructor(source: any = {}) {
	        if ('string' === typeof source) source = JSON.parse(source);
	        this.packages = source["packages"];
	        this.mode = source["mode"];
	        this.apkFolder = source["apkFolder"];
	        this.workers = source["workers"];
	        this.skipCached = source["skipCached"];
	        this.genericSystem = source["genericSystem"];
	    }
	}
	export class IconExtractResult {
	    packageName: string;
	    dataUrl: string;
	    source: string;
	    filePath: string;
	    apkPath: string;
	    error: string;
	
	    static createFrom(source: any = {}) {
	        return new IconExtractResult(source);
	    }
	
	    constructor(source: any = {}) {
	        if ('string' === typeof source) source = JSON.parse(source);
	        this.packageName = source["packageName"];
	        this.dataUrl = source["dataUrl"];
	        this.source = source["source"];
	        this.filePath = source["filePath"];
	        this.apkPath = source["apkPath"];
	        this.error = source["error"];
	    }
	}
	export class InstalledApp {
	    PackageName: string;
	    Data: AppData;
	    IsInstalled: boolean;
	
	    static createFrom(source: any = {}) {
	        return new InstalledApp(source);
	    }
	
	    constructor(source: any = {}) {
	        if ('string' === typeof source) source = JSON.parse(source);
	        this.PackageName = source["PackageName"];
	        this.Data = this.convertValues(source["Data"], AppData);
	        this.IsInstalled = source["IsInstalled"];
	    }
	
		convertValues(a: any, classs: any, asMap: boolean = false): any {
		    if (!a) {
		        return a;
		    }
		    if (a.slice && a.map) {
		        return (a as any[]).map(elem => this.convertValues(elem, classs));
		    } else if ("object" === typeof a) {
		        if (asMap) {
		            for (const key of Object.keys(a)) {
		                a[key] = new classs(a[key]);
		            }
		            return a;
		        }
		        return new classs(a);
		    }
		    return a;
		}
	}
	export class LocalAppBackup {
	    package: string;
	    name: string;
	    files: string[];
	    totalBytes: number;
	
	    static createFrom(source: any = {}) {
	        return new LocalAppBackup(source);
	    }
	
	    constructor(source: any = {}) {
	        if ('string' === typeof source) source = JSON.parse(source);
	        this.package = source["package"];
	        this.name = source["name"];
	        this.files = source["files"];
	        this.totalBytes = source["totalBytes"];
	    }
	}
	export class MessageItem {
	    address: string;
	    body: string;
	    date: string;
	    type: string;
	
	    static createFrom(source: any = {}) {
	        return new MessageItem(source);
	    }
	
	    constructor(source: any = {}) {
	        if ('string' === typeof source) source = JSON.parse(source);
	        this.address = source["address"];
	        this.body = source["body"];
	        this.date = source["date"];
	        this.type = source["type"];
	    }
	}
	export class PrepareRequest {
	    includeApps: boolean;
	    includeFiles: boolean;
	    iconMode: string;
	    apkFolder: string;
	    workers: number;
	    genericSystem: boolean;
	    forceRefresh: boolean;
	    fileRoot: string;
	
	    static createFrom(source: any = {}) {
	        return new PrepareRequest(source);
	    }
	
	    constructor(source: any = {}) {
	        if ('string' === typeof source) source = JSON.parse(source);
	        this.includeApps = source["includeApps"];
	        this.includeFiles = source["includeFiles"];
	        this.iconMode = source["iconMode"];
	        this.apkFolder = source["apkFolder"];
	        this.workers = source["workers"];
	        this.genericSystem = source["genericSystem"];
	        this.forceRefresh = source["forceRefresh"];
	        this.fileRoot = source["fileRoot"];
	    }
	}
	export class ProcessStat {
	    pid: string;
	    name: string;
	    cpu: string;
	    memory: string;
	    status: string;
	    package: string;
	
	    static createFrom(source: any = {}) {
	        return new ProcessStat(source);
	    }
	
	    constructor(source: any = {}) {
	        if ('string' === typeof source) source = JSON.parse(source);
	        this.pid = source["pid"];
	        this.name = source["name"];
	        this.cpu = source["cpu"];
	        this.memory = source["memory"];
	        this.status = source["status"];
	        this.package = source["package"];
	    }
	}
	export class RecoveryItem {
	    path: string;
	    name: string;
	    type: string;
	    kind: string;
	    size: string;
	    sizeBytes: number;
	    hidden: boolean;
	    notes: string;
	    sourcePath: string;
	
	    static createFrom(source: any = {}) {
	        return new RecoveryItem(source);
	    }
	
	    constructor(source: any = {}) {
	        if ('string' === typeof source) source = JSON.parse(source);
	        this.path = source["path"];
	        this.name = source["name"];
	        this.type = source["type"];
	        this.kind = source["kind"];
	        this.size = source["size"];
	        this.sizeBytes = source["sizeBytes"];
	        this.hidden = source["hidden"];
	        this.notes = source["notes"];
	        this.sourcePath = source["sourcePath"];
	    }
	}
	export class RecoveryRequest {
	    mode: string;
	    query: string;
	    deep: boolean;
	
	    static createFrom(source: any = {}) {
	        return new RecoveryRequest(source);
	    }
	
	    constructor(source: any = {}) {
	        if ('string' === typeof source) source = JSON.parse(source);
	        this.mode = source["mode"];
	        this.query = source["query"];
	        this.deep = source["deep"];
	    }
	}
	export class RestorePlanItem {
	    category: string;
	    label: string;
	    fileCount: number;
	    totalBytes: number;
	    available: boolean;
	    error: string;
	
	    static createFrom(source: any = {}) {
	        return new RestorePlanItem(source);
	    }
	
	    constructor(source: any = {}) {
	        if ('string' === typeof source) source = JSON.parse(source);
	        this.category = source["category"];
	        this.label = source["label"];
	        this.fileCount = source["fileCount"];
	        this.totalBytes = source["totalBytes"];
	        this.available = source["available"];
	        this.error = source["error"];
	    }
	}
	export class RestorePlan {
	    localFolder: string;
	    items: RestorePlanItem[];
	    totalFiles: number;
	    totalBytes: number;
	    hasManifest: boolean;
	    error: string;
	
	    static createFrom(source: any = {}) {
	        return new RestorePlan(source);
	    }
	
	    constructor(source: any = {}) {
	        if ('string' === typeof source) source = JSON.parse(source);
	        this.localFolder = source["localFolder"];
	        this.items = this.convertValues(source["items"], RestorePlanItem);
	        this.totalFiles = source["totalFiles"];
	        this.totalBytes = source["totalBytes"];
	        this.hasManifest = source["hasManifest"];
	        this.error = source["error"];
	    }
	
		convertValues(a: any, classs: any, asMap: boolean = false): any {
		    if (!a) {
		        return a;
		    }
		    if (a.slice && a.map) {
		        return (a as any[]).map(elem => this.convertValues(elem, classs));
		    } else if ("object" === typeof a) {
		        if (asMap) {
		            for (const key of Object.keys(a)) {
		                a[key] = new classs(a[key]);
		            }
		            return a;
		        }
		        return new classs(a);
		    }
		    return a;
		}
	}
	
	
	export class StorageVolume {
	    label: string;
	    path: string;
	    mountPath: string;
	    totalBytes: number;
	    usedBytes: number;
	    freeBytes: number;
	    isRemovable: boolean;
	
	    static createFrom(source: any = {}) {
	        return new StorageVolume(source);
	    }
	
	    constructor(source: any = {}) {
	        if ('string' === typeof source) source = JSON.parse(source);
	        this.label = source["label"];
	        this.path = source["path"];
	        this.mountPath = source["mountPath"];
	        this.totalBytes = source["totalBytes"];
	        this.usedBytes = source["usedBytes"];
	        this.freeBytes = source["freeBytes"];
	        this.isRemovable = source["isRemovable"];
	    }
	}
	export class TransferResult {
	    operation: string;
	    targetFolder: string;
	    totalFiles: number;
	    copied: number;
	    failed: number;
	    bytes: number;
	    errors: string[];
	    manifestPath: string;
	
	    static createFrom(source: any = {}) {
	        return new TransferResult(source);
	    }
	
	    constructor(source: any = {}) {
	        if ('string' === typeof source) source = JSON.parse(source);
	        this.operation = source["operation"];
	        this.targetFolder = source["targetFolder"];
	        this.totalFiles = source["totalFiles"];
	        this.copied = source["copied"];
	        this.failed = source["failed"];
	        this.bytes = source["bytes"];
	        this.errors = source["errors"];
	        this.manifestPath = source["manifestPath"];
	    }
	}
	
	export class ZipEntryInfo {
	    name: string;
	    size: number;
	    isDir: boolean;
	
	    static createFrom(source: any = {}) {
	        return new ZipEntryInfo(source);
	    }
	
	    constructor(source: any = {}) {
	        if ('string' === typeof source) source = JSON.parse(source);
	        this.name = source["name"];
	        this.size = source["size"];
	        this.isDir = source["isDir"];
	    }
	}

}

