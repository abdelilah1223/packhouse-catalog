package main

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"runtime"
	"sort"
	"strings"
	"sync"
	"time"
)

// App backup: copy installed apps to the PC as installable APK files.
//
// Modern apps are rarely a single APK: a base.apk is accompanied by split APKs
// (per-ABI, per-language, per-density). All of them are pulled, in install
// order, so the backup can be reinstalled with `adb install-multiple` later.

// AppBackupItem is one app's contribution to an app-backup plan.
type AppBackupItem struct {
	Package    string   `json:"package"`
	Name       string   `json:"name"`
	IsSystem   bool     `json:"isSystem"`
	ApkPaths   []string `json:"apkPaths"`
	TotalBytes int64    `json:"totalBytes"`
	Error      string   `json:"error"`
}

// AppBackupPlan is the reviewable preview shown before an app backup starts.
type AppBackupPlan struct {
	TargetFolder string          `json:"targetFolder"`
	Items        []AppBackupItem `json:"items"`
	TotalFiles   int             `json:"totalFiles"`
	TotalBytes   int64           `json:"totalBytes"`
}

// deviceApkPaths returns every APK file that makes up an installed app
// (base.apk plus any split APKs), with base.apk first so the backup can be
// reinstalled with install-multiple directly.
func deviceApkPaths(pkg string) ([]string, error) {
	out, err := executeADB("shell", "pm", "path", pkg)
	if err != nil {
		return nil, err
	}
	paths := make([]string, 0, 4)
	for _, line := range strings.Split(out, "\n") {
		if path, ok := apkPathFromPMLine(line); ok {
			paths = append(paths, path)
		}
	}
	if len(paths) == 0 {
		return nil, fmt.Errorf("the device reported no APK path for %s", pkg)
	}
	sort.Slice(paths, func(i, j int) bool {
		baseI := strings.Contains(strings.ToLower(paths[i]), "base.apk")
		baseJ := strings.Contains(strings.ToLower(paths[j]), "base.apk")
		if baseI != baseJ {
			return baseI
		}
		return paths[i] < paths[j]
	})
	return paths, nil
}

// PreviewAppBackup resolves what an app backup would copy before it starts:
// for every selected package the full APK list with real byte sizes.
func (a *App) PreviewAppBackup(packages []string, targetFolder string) (*AppBackupPlan, error) {
	if err := a.requireAnyDevice(); err != nil {
		return nil, err
	}
	targetFolder = strings.TrimSpace(targetFolder)
	if targetFolder == "" {
		targetFolder = a.defaultBackupFolder()
	}

	wanted := make([]string, 0, len(packages))
	seen := map[string]bool{}
	for _, pkg := range packages {
		pkg = strings.TrimSpace(pkg)
		if pkg == "" || seen[pkg] {
			continue
		}
		seen[pkg] = true
		wanted = append(wanted, pkg)
	}

	plan := &AppBackupPlan{TargetFolder: targetFolder, Items: make([]AppBackupItem, 0, len(wanted))}

	sem := make(chan struct{}, 6)
	var mu sync.Mutex
	var wg sync.WaitGroup
	for _, pkg := range wanted {
		wg.Add(1)
		sem <- struct{}{}
		go func(name string) {
			defer wg.Done()
			defer func() { <-sem }()
			item := AppBackupItem{Package: name, Name: formatAppLabel(name)}
			if apkPaths, err := deviceApkPaths(name); err != nil {
				item.Error = err.Error()
			} else {
				item.ApkPaths = apkPaths
				for _, path := range apkPaths {
					if size, err := remoteFileSize(path); err == nil {
						item.TotalBytes += size
					}
				}
			}
			mu.Lock()
			plan.Items = append(plan.Items, item)
			plan.TotalFiles += len(item.ApkPaths)
			plan.TotalBytes += item.TotalBytes
			mu.Unlock()
		}(pkg)
	}
	wg.Wait()

	sort.Slice(plan.Items, func(i, j int) bool {
		return strings.ToLower(plan.Items[i].Name) < strings.ToLower(plan.Items[j].Name)
	})
	return plan, nil
}

// appBackupManifest makes an app backup self-describing and reinstallable.
type appBackupManifest struct {
	CreatedAt string             `json:"createdAt"`
	Apps      []AppBackupFileRef `json:"apps"`
}

// AppBackupFileRef records one app's APK copies inside a backup folder.
type AppBackupFileRef struct {
	Package string   `json:"package"`
	Name    string   `json:"name"`
	Files   []string `json:"files"` // paths relative to the backup folder
}

// RunAppBackup copies the selected apps' APK files to the PC with live progress.
// Each app gets its own folder because an app may consist of several APKs.
func (a *App) RunAppBackup(packages []string, targetFolder string) (*TransferResult, error) {
	if err := a.requireAnyDevice(); err != nil {
		return nil, err
	}
	targetFolder = strings.TrimSpace(targetFolder)
	if targetFolder == "" {
		targetFolder = a.defaultBackupFolder()
	}
	appsRoot := filepath.Join(targetFolder, "Apps")
	if err := os.MkdirAll(appsRoot, 0o755); err != nil {
		return nil, fmt.Errorf("failed to create app backup folder: %v", err)
	}

	plan, err := a.PreviewAppBackup(packages, targetFolder)
	if err != nil {
		return nil, err
	}

	result := &TransferResult{Operation: "app-backup", TargetFolder: targetFolder, TotalFiles: plan.TotalFiles}
	reporter := newProgressReporter(a, "app-backup", len(plan.Items))
	reporter.report("planning", "", "", false, fmt.Sprintf("Planned %d APK files", plan.TotalFiles))

	workers := runtime.NumCPU()
	if workers < 2 {
		workers = 2
	}
	if workers > 6 {
		workers = 6
	}
	jobCh := make(chan AppBackupItem, workers)
	var mu sync.Mutex
	var wg sync.WaitGroup
	manifestRefs := make([]AppBackupFileRef, 0, len(plan.Items))

	for w := 0; w < workers; w++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for item := range jobCh {
				ref := AppBackupFileRef{Package: item.Package, Name: item.Name}
				fail := func(err error) {
					reporter.addFailed()
					mu.Lock()
					result.Failed++
					if len(result.Errors) < 40 {
						result.Errors = append(result.Errors, fmt.Sprintf("%s: %v", item.Package, err))
					}
					mu.Unlock()
				}

				if item.Error != "" {
					fail(fmt.Errorf("%s", item.Error))
					reporter.report("copying", item.Package, item.Name, false, "")
					continue
				}

				appDir := filepath.Join(appsRoot, sanitizeFileComponent(item.Package))
				if err := os.MkdirAll(appDir, 0o755); err != nil {
					fail(err)
					reporter.report("copying", item.Package, item.Name, false, "")
					continue
				}

				for _, apkPath := range item.ApkPaths {
					name := remoteBaseName(apkPath)
					if name == "" {
						name = "base.apk"
					}
					dest := filepath.Join(appDir, name)
					if info, err := os.Stat(dest); err == nil && info.Size() > 0 {
						if size, err := remoteFileSize(apkPath); err == nil && info.Size() == size {
							// Already backed up with the same size — reuse it.
							ref.Files = append(ref.Files, filepath.ToSlash(filepath.Join("Apps", filepath.Base(appDir), name)))
							reporter.addBytes(size)
							mu.Lock()
							result.Bytes += size
							result.Copied++
							mu.Unlock()
							continue
						}
					}
					partial := dest + ".part"
					_ = os.Remove(partial)
					if _, err := executeADB("pull", apkPath, partial); err != nil {
						_ = os.Remove(partial)
						fail(err)
						continue
					}
					if err := os.Rename(partial, dest); err != nil {
						_ = os.Remove(partial)
						fail(err)
						continue
					}
					ref.Files = append(ref.Files, filepath.ToSlash(filepath.Join("Apps", filepath.Base(appDir), name)))
					if size, err := remoteFileSize(apkPath); err == nil {
						reporter.addBytes(size)
						mu.Lock()
						result.Bytes += size
						result.Copied++
						mu.Unlock()
					} else {
						mu.Lock()
						result.Copied++
						mu.Unlock()
					}
				}
				mu.Lock()
				manifestRefs = append(manifestRefs, ref)
				mu.Unlock()
				reporter.report("copying", item.Package, item.Name, false, "")
			}
		}()
	}

	for _, item := range plan.Items {
		jobCh <- item
	}
	close(jobCh)
	wg.Wait()

	manifest := appBackupManifest{
		CreatedAt: time.Now().Format(time.RFC3339),
		Apps:      manifestRefs,
	}
	if data, err := json.MarshalIndent(manifest, "", "  "); err == nil {
		manifestPath := filepath.Join(appsRoot, "apps.json")
		if err := os.WriteFile(manifestPath, data, 0o644); err == nil {
			result.ManifestPath = manifestPath
		}
	}

	message := fmt.Sprintf("Backed up %d of %d apps", len(manifestRefs), len(plan.Items))
	if result.Failed > 0 {
		message += fmt.Sprintf(" (%d failed)", result.Failed)
	}
	reporter.finish(message)
	return result, nil
}

// LocalAppBackup is one app found in a backup folder on the PC, ready to reinstall.
type LocalAppBackup struct {
	Package    string   `json:"package"`
	Name       string   `json:"name"`
	Files      []string `json:"files"`
	TotalBytes int64    `json:"totalBytes"`
}

// ListLocalAppBackups scans a backup folder for previously backed-up apps
// (Apps/<package>/*.apk) and reports what can be reinstalled from there.
func (a *App) ListLocalAppBackups(localFolder string) ([]LocalAppBackup, error) {
	localFolder = strings.TrimSpace(localFolder)
	if localFolder == "" {
		return nil, fmt.Errorf("no backup folder given")
	}
	appsRoot := filepath.Join(localFolder, "Apps")
	entries, err := os.ReadDir(appsRoot)
	if err != nil {
		return nil, fmt.Errorf("no app backups found in %s", localFolder)
	}

	// A manifest is optional; when present it restores the app display names.
	names := map[string]string{}
	if data, err := os.ReadFile(filepath.Join(appsRoot, "apps.json")); err == nil {
		var manifest appBackupManifest
		if err := json.Unmarshal(data, &manifest); err == nil {
			for _, ref := range manifest.Apps {
				names[ref.Package] = ref.Name
			}
		}
	}

	result := make([]LocalAppBackup, 0, len(entries))
	for _, entry := range entries {
		if !entry.IsDir() {
			continue
		}
		pkg := entry.Name()
		files := make([]string, 0, 4)
		var total int64
		apks, err := os.ReadDir(filepath.Join(appsRoot, pkg))
		if err != nil {
			continue
		}
		for _, apk := range apks {
			if apk.IsDir() || !strings.EqualFold(filepath.Ext(apk.Name()), ".apk") {
				continue
			}
			full := filepath.Join(appsRoot, pkg, apk.Name())
			files = append(files, full)
			if info, err := apk.Info(); err == nil {
				total += info.Size()
			}
		}
		if len(files) == 0 {
			continue
		}
		// base.apk must come first for install-multiple.
		sort.Slice(files, func(i, j int) bool {
			baseI := strings.Contains(strings.ToLower(files[i]), "base.apk")
			baseJ := strings.Contains(strings.ToLower(files[j]), "base.apk")
			if baseI != baseJ {
				return baseI
			}
			return files[i] < files[j]
		})
		result = append(result, LocalAppBackup{
			Package:    pkg,
			Name:       names[pkg],
			Files:      files,
			TotalBytes: total,
		})
	}
	sort.Slice(result, func(i, j int) bool {
		return strings.ToLower(result[i].Package) < strings.ToLower(result[j].Package)
	})
	return result, nil
}

// InstallAppBackups reinstalls previously backed-up apps onto the phone with
// `adb install-multiple -r` (handles split APKs) with live progress.
func (a *App) InstallAppBackups(localFolder string, packages []string) (*TransferResult, error) {
	if err := a.requireAnyDevice(); err != nil {
		return nil, err
	}
	localFolder = strings.TrimSpace(localFolder)
	if localFolder == "" {
		return nil, fmt.Errorf("no backup folder given")
	}

	all, err := a.ListLocalAppBackups(localFolder)
	if err != nil {
		return nil, err
	}
	wanted := map[string]bool{}
	for _, pkg := range packages {
		wanted[strings.TrimSpace(pkg)] = true
	}
	targets := make([]LocalAppBackup, 0, len(all))
	for _, backup := range all {
		if len(wanted) == 0 || wanted[backup.Package] {
			targets = append(targets, backup)
		}
	}
	if len(targets) == 0 {
		return nil, fmt.Errorf("no app backups matched the selection")
	}

	result := &TransferResult{Operation: "install", TargetFolder: localFolder, TotalFiles: len(targets)}
	reporter := newProgressReporter(a, "install", len(targets))

	for _, target := range targets {
		args := append([]string{"install-multiple", "-r"}, target.Files...)
		if out, err := executeADB(args...); err != nil {
			reporter.addFailed()
			result.Failed++
			if len(result.Errors) < 40 {
				result.Errors = append(result.Errors, fmt.Sprintf("%s: %v (%s)", target.Package, err, strings.TrimSpace(out)))
			}
		} else {
			result.Copied++
		}
		reporter.report("installing", target.Package, target.Name, false, "")
	}

	message := fmt.Sprintf("Installed %d of %d apps", result.Copied, result.TotalFiles)
	if result.Failed > 0 {
		message += fmt.Sprintf(" (%d failed)", result.Failed)
	}
	reporter.finish(message)
	return result, nil
}
