package main

import (
	"encoding/binary"
	"sort"
)

// resourceCandidate is one file a resource ID can resolve to, together with the
// density qualifier of the configuration it came from.
type resourceCandidate struct {
	path    string
	density int
}

// Android density qualifiers, used to prefer the sharpest icon.
var densityNames = map[int]int{
	120: 2, 160: 5, 213: 6, 240: 6, 320: 7, 480: 8, 640: 9,
}

// resourceFileCandidates resolves a resource ID (as found in android:icon) to the
// list of files it may be stored as, ordered sharpest-first. A single ID usually
// maps to one file per density bucket, and for obfuscated APKs those names carry
// no hint of what they are, so the density from the config is the only signal.
func resourceFileCandidates(arsc []byte, resID uint32) []resourceCandidate {
	if len(arsc) < 12 || binary.LittleEndian.Uint16(arsc) != chunkTableType {
		return nil
	}
	headerSize := int(binary.LittleEndian.Uint16(arsc[2:]))

	// The global value string pool precedes the package chunks, so collect it
	// first and only then walk the packages.
	var valuePool *stringPool
	packages := make([]int, 0, 2)
	for pos := headerSize; pos+8 <= len(arsc); {
		chunkType := binary.LittleEndian.Uint16(arsc[pos:])
		chunkSize := int(binary.LittleEndian.Uint32(arsc[pos+4:]))
		if chunkSize <= 0 {
			break
		}
		switch chunkType {
		case chunkStringPool:
			if valuePool == nil {
				if parsed, ok := parseStringPool(arsc, pos); ok {
					valuePool = parsed
				}
			}
		case chunkTablePackage:
			packages = append(packages, pos)
		}
		pos += chunkSize
	}
	if valuePool == nil || len(packages) == 0 {
		return nil
	}

	results := make([]resourceCandidate, 0, 8)
	for _, packageOffset := range packages {
		results = append(results, packageResourceCandidates(arsc, packageOffset, valuePool, resID)...)
	}
	sort.SliceStable(results, func(i, j int) bool {
		return densityRankOf(results[i].density) > densityRankOf(results[j].density)
	})
	return results
}

func densityRankOf(density int) int {
	if rank, ok := densityNames[density]; ok {
		return rank
	}
	if density == 0 {
		return 3 // unspecified
	}
	return 1
}

func packageResourceCandidates(arsc []byte, packageOffset int, valuePool *stringPool, resID uint32) []resourceCandidate {
	if packageOffset+8 > len(arsc) {
		return nil
	}
	headerSize := int(binary.LittleEndian.Uint16(arsc[packageOffset+2:]))
	packageSize := int(binary.LittleEndian.Uint32(arsc[packageOffset+4:]))
	packageEnd := packageOffset + packageSize
	if packageEnd > len(arsc) || packageEnd <= packageOffset {
		packageEnd = len(arsc)
	}

	wantType := uint8((resID >> 16) & 0xFF)
	wantEntry := int(resID & 0xFFFF)

	results := make([]resourceCandidate, 0, 4)
	for pos := packageOffset + headerSize; pos+8 <= packageEnd; {
		chunkType := binary.LittleEndian.Uint16(arsc[pos:])
		chunkSize := int(binary.LittleEndian.Uint32(arsc[pos+4:]))
		if chunkSize <= 0 {
			break
		}
		if chunkType == chunkTableTypeType {
			if path, density, ok := typeChunkEntry(arsc, pos, valuePool, wantType, wantEntry); ok {
				results = append(results, resourceCandidate{path: path, density: density})
			}
		}
		pos += chunkSize
	}
	return results
}

// typeChunkEntry reads one RES_TABLE_TYPE chunk and returns the file path stored
// for the requested entry, if this chunk covers it.
func typeChunkEntry(arsc []byte, off int, valuePool *stringPool, wantType uint8, wantEntry int) (string, int, bool) {
	const typeHeaderSize = 20
	if off+typeHeaderSize+4 > len(arsc) {
		return "", 0, false
	}
	typeID := arsc[off+8]
	flags := arsc[off+9]
	entryCount := int(binary.LittleEndian.Uint32(arsc[off+12:]))
	entriesStart := int(binary.LittleEndian.Uint32(arsc[off+16:]))
	if typeID != wantType || wantEntry >= entryCount || entryCount < 0 {
		return "", 0, false
	}

	configSize := int(binary.LittleEndian.Uint32(arsc[off+20:]))
	if configSize < 4 {
		return "", 0, false
	}
	density := 0
	if configSize >= 16 && off+20+16 <= len(arsc) {
		density = int(binary.LittleEndian.Uint16(arsc[off+20+14:]))
	}

	offsetsStart := off + 20 + configSize
	var entryOffset int
	if flags&0x01 != 0 {
		// Sparse table: {uint16 index; uint16 offset/4}
		pos := offsetsStart + wantEntry*4
		if pos+4 > len(arsc) {
			return "", 0, false
		}
		if int(binary.LittleEndian.Uint16(arsc[pos:])) != wantEntry {
			return "", 0, false
		}
		entryOffset = int(binary.LittleEndian.Uint16(arsc[pos+2:])) * 4
	} else {
		pos := offsetsStart + wantEntry*4
		if pos+4 > len(arsc) {
			return "", 0, false
		}
		raw := binary.LittleEndian.Uint32(arsc[pos:])
		if raw == 0xFFFFFFFF {
			return "", 0, false
		}
		entryOffset = int(raw)
	}

	entryPos := off + entriesStart + entryOffset
	if entryPos+12 > len(arsc) {
		return "", 0, false
	}
	if binary.LittleEndian.Uint16(arsc[entryPos+2:])&0x01 != 0 {
		// FLAG_COMPLEX: a bag/map entry, never a plain file path.
		return "", 0, false
	}
	dataType := arsc[entryPos+11]
	value := binary.LittleEndian.Uint32(arsc[entryPos+12:])
	if dataType != valueTypeString {
		return "", 0, false
	}
	path := valuePool.at(value)
	if path == "" {
		return "", 0, false
	}
	return path, density, true
}
