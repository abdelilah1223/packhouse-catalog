package main

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"sync/atomic"
)

// App names: the user sees the label from the launcher (android:label), not the
// package name, so formatAppLabel() is only a guess. The real label lives in the
// APK manifest — either as a literal string or as a reference into
// resources.arsc — and is resolved once per app, then cached in a JSON index
// keyed by package name so later launches cost nothing.

var (
	labelIndexMu    sync.Mutex
	labelIndexCache map[string]string // nil until first load
)

func labelIndexPath() string {
	return filepath.Join(appCacheDir("labels"), "labels.json")
}

// loadLabelIndexLocked reads the on-disk index once and keeps it in memory.
func loadLabelIndexLocked() map[string]string {
	if labelIndexCache != nil {
		return labelIndexCache
	}
	labelIndexCache = map[string]string{}
	if data, err := os.ReadFile(labelIndexPath()); err == nil {
		parsed := map[string]string{}
		if err := json.Unmarshal(data, &parsed); err == nil {
			for pkg, label := range parsed {
				if pkg != "" && label != "" {
					labelIndexCache[pkg] = label
				}
			}
		}
	}
	return labelIndexCache
}

// cachedAppLabel returns the remembered display name of a package ("" when the
// label has not been resolved yet).
func cachedAppLabel(packageName string) string {
	labelIndexMu.Lock()
	defer labelIndexMu.Unlock()
	return loadLabelIndexLocked()[packageName]
}

// rememberAppLabel stores a resolved display name in the index file. Empty or
// unresolved ("@…") labels are ignored so failures are retried next run.
func rememberAppLabel(packageName, label string) error {
	label = cleanAppLabel(label)
	if strings.TrimSpace(packageName) == "" || label == "" {
		return nil
	}

	labelIndexMu.Lock()
	defer labelIndexMu.Unlock()
	index := loadLabelIndexLocked()
	if index[packageName] == label {
		return nil
	}
	index[packageName] = label

	data, err := json.MarshalIndent(index, "", "  ")
	if err != nil {
		return err
	}
	if err := os.MkdirAll(filepath.Dir(labelIndexPath()), 0o755); err != nil {
		return err
	}
	return os.WriteFile(labelIndexPath(), data, 0o644)
}

// cleanAppLabel normalizes a label read from an APK: unresolved references
// ("@string/…") and accidental file paths are rejected so the caller can fall
// back to the package-name guess.
func cleanAppLabel(value string) string {
	value = strings.TrimSpace(value)
	if value == "" {
		return ""
	}
	if strings.HasPrefix(value, "@") || strings.HasPrefix(value, "?") {
		return ""
	}
	if strings.ContainsAny(value, `/\`) || strings.HasSuffix(strings.ToLower(value), ".png") {
		return ""
	}
	if len(value) > 80 {
		value = value[:80]
	}
	return value
}

// resolveAppLabel reads the user-visible label of an installed app straight out
// of its APK: manifest first (literal labels are common), then the resource
// table when android:label is a reference. Returns "" when it cannot be read,
// so the caller keeps the package-name fallback.
func resolveAppLabel(apkPath string) string {
	apkPath = strings.TrimSpace(apkPath)
	if apkPath == "" {
		return ""
	}
	reader := deviceAPKReader{apkPath}

	manifest, err := reader.read("AndroidManifest.xml")
	if err != nil || len(manifest) == 0 {
		return ""
	}
	literal, resID, ok := manifestLabel(manifest)
	if !ok {
		return ""
	}
	if label := cleanAppLabel(literal); label != "" {
		return label
	}
	if resID == 0 {
		return ""
	}

	arsc, err := reader.read("resources.arsc")
	if err != nil || len(arsc) == 0 {
		return ""
	}
	// A string resource resolves through the same table walk the icon uses; the
	// candidate "path" is then the string value itself.
	for _, candidate := range resourceFileCandidates(arsc, resID) {
		if label := cleanAppLabel(candidate.path); label != "" {
			return label
		}
	}
	return ""
}

// ensureAppLabel resolves and remembers the label of one app if it is not
// cached yet. Used by the icon pipeline, which is already reading each APK, so
// the label costs no extra device round trips on later runs.
func ensureAppLabel(packageName, apkPath string) {
	if cachedAppLabel(packageName) != "" || strings.TrimSpace(apkPath) == "" {
		return
	}
	if label := resolveAppLabel(apkPath); label != "" {
		_ = rememberAppLabel(packageName, label)
	}
}

// warmAppLabels resolves missing display names with bounded parallelism before
// the app list is sent to the UI. Without this, a fresh launch shows package-name
// guesses until icon extraction happens later. progress, when set, is called as
// (done, total) after each name so the "Getting data ready" screen can move
// instead of sitting at one percentage while hundreds of APKs are opened.
func warmAppLabels(paths map[string]string, progress func(done, total int)) {
	if len(paths) == 0 {
		return
	}
	type job struct {
		pkg string
		apk string
	}
	pending := make([]job, 0, len(paths))
	for pkg, apkPath := range paths {
		if strings.TrimSpace(pkg) == "" || strings.TrimSpace(apkPath) == "" || cachedAppLabel(pkg) != "" {
			continue
		}
		pending = append(pending, job{pkg: pkg, apk: apkPath})
	}
	if len(pending) == 0 {
		return
	}

	jobs := make(chan job)
	var wg sync.WaitGroup
	var completed int32
	workers := 6
	if len(pending) < workers {
		workers = len(pending)
	}
	for i := 0; i < workers; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for item := range jobs {
				ensureAppLabel(item.pkg, item.apk)
				if progress != nil {
					progress(int(atomic.AddInt32(&completed, 1)), len(pending))
				}
			}
		}()
	}
	for _, item := range pending {
		jobs <- item
	}
	close(jobs)
	wg.Wait()
}

// LabelCachePath exposes where the resolved names are stored (for the UI).
func (a *App) LabelCachePath() (string, error) {
	path := labelIndexPath()
	if _, err := os.Stat(path); err != nil {
		return path, fmt.Errorf("no resolved app names yet — extract app icons once and they will be saved here")
	}
	return path, nil
}
