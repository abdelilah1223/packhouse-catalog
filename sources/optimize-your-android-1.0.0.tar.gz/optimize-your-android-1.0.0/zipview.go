package main

import (
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"sync"
)

// Archive inspection: the user can look INSIDE a zip on the phone without
// extracting it. The archive is pulled once into a local cache, then entries are
// read straight out of the local copy — listing is instant afterwards.

// ZipEntryInfo is one entry inside a device archive.
type ZipEntryInfo struct {
	Name  string `json:"name"`
	Size  int64  `json:"size"`
	IsDir bool   `json:"isDir"`
}

// maxZipInspectBytes caps what we are willing to pull just to look inside an
// archive. Bigger archives are better handled by saving them to the PC first.
const maxZipInspectBytes = 300 * 1024 * 1024

// maxCachedZips bounds how many pulled archives stay cached in one session.
const maxCachedZips = 4

type zipCacheEntry struct {
	localPath string
	entries   []apkEntry
	order     int
}

var (
	zipCacheMu    sync.Mutex
	zipCache      = map[string]zipCacheEntry{}
	zipCacheClock = 0
)

// dropZipCacheLocked evicts the oldest cached archive.
func dropZipCacheLocked() {
	oldestKey := ""
	oldestOrder := -1
	for key, entry := range zipCache {
		if oldestOrder == -1 || entry.order < oldestOrder {
			oldestOrder = entry.order
			oldestKey = key
		}
	}
	if oldestKey != "" {
		_ = os.RemoveAll(filepath.Dir(zipCache[oldestKey].localPath))
		delete(zipCache, oldestKey)
	}
}

// localZipForInspect returns a local copy of a device archive plus its entry
// list, pulling it once and reusing the copy for follow-up entry reads.
func localZipForInspect(remotePath string) (zipCacheEntry, error) {
	remotePath = strings.TrimSpace(remotePath)
	if remotePath == "" {
		return zipCacheEntry{}, fmt.Errorf("missing archive path")
	}
	size, err := remoteFileSize(remotePath)
	if err != nil {
		return zipCacheEntry{}, fmt.Errorf("could not read the archive size: %v", err)
	}
	if size > maxZipInspectBytes {
		return zipCacheEntry{}, fmt.Errorf("the archive is %s — too large to inspect in the app (limit %s). Save it to the PC first", humanBytes(size), humanBytes(maxZipInspectBytes))
	}

	key := fmt.Sprintf("%s|%d", remotePath, size)
	zipCacheMu.Lock()
	if entry, ok := zipCache[key]; ok {
		zipCacheMu.Unlock()
		return entry, nil
	}
	zipCacheMu.Unlock()

	tmpDir, err := os.MkdirTemp("", "zipview-*")
	if err != nil {
		return zipCacheEntry{}, err
	}
	name := remoteBaseName(remotePath)
	name = sanitizeFileComponent(name)
	if name == "" || name == "item" {
		name = "archive.zip"
	}
	local := filepath.Join(tmpDir, name)
	if _, err := executeADB("pull", remotePath, local); err != nil {
		_ = os.RemoveAll(tmpDir)
		return zipCacheEntry{}, fmt.Errorf("could not copy the archive from the device: %v", err)
	}
	entries, err := localZipEntries(local)
	if err != nil {
		_ = os.RemoveAll(tmpDir)
		return zipCacheEntry{}, fmt.Errorf("this file is not a readable zip archive: %v", err)
	}

	zipCacheMu.Lock()
	defer zipCacheMu.Unlock()
	zipCacheClock++
	entry := zipCacheEntry{localPath: local, entries: entries, order: zipCacheClock}
	zipCache[key] = entry
	for len(zipCache) > maxCachedZips {
		dropZipCacheLocked()
	}
	return entry, nil
}

// ListZipContents lists the entries inside a zip on the device.
func (a *App) ListZipContents(remotePath string) ([]ZipEntryInfo, error) {
	if err := a.requireAnyDevice(); err != nil {
		return nil, err
	}
	entry, err := localZipForInspect(remotePath)
	if err != nil {
		return nil, err
	}
	result := make([]ZipEntryInfo, 0, len(entry.entries))
	for _, item := range entry.entries {
		result = append(result, ZipEntryInfo{
			Name:  item.name,
			Size:  item.size,
			IsDir: strings.HasSuffix(item.name, "/"),
		})
	}
	return result, nil
}

// ReadZipEntry reads one entry out of a device archive and returns whatever
// preview it supports (image, video, audio, pdf, text) — the same inline
// viewers the file browser uses, pointed inside the archive.
func (a *App) ReadZipEntry(remotePath, entryName string) (*FilePreview, error) {
	if err := a.requireAnyDevice(); err != nil {
		return nil, err
	}
	entry, err := localZipForInspect(remotePath)
	if err != nil {
		return nil, err
	}
	data, err := readLocalZipEntry(entry.localPath, entryName)
	if err != nil {
		return nil, fmt.Errorf("could not read %s from the archive: %v", entryName, err)
	}
	return previewFromBytes(entryName, data), nil
}

// previewFromBytes builds the inline preview structure for already-read bytes,
// mirroring the caps used by GetFilePreview.
func previewFromBytes(name string, data []byte) *FilePreview {
	kind := fileKind(name)
	result := &FilePreview{
		Path:     name,
		Name:     name,
		Kind:     kind,
		MimeType: fileMime(name),
	}
	limit := int64(maxGenericFile)
	switch kind {
	case KindImage:
		limit = maxInlineImage
	case KindVideo:
		limit = maxInlineVideo
	case KindAudio:
		limit = maxInlineAudio
	case KindPDF:
		limit = maxInlinePDF
	case KindText:
		limit = maxInlineText
	}
	result.DownloadLimit = limit
	if int64(len(data)) > limit {
		result.TooLarge = true
		result.Message = fmt.Sprintf("This file is %s — too large to preview. Extract the archive to open it.", humanBytes(int64(len(data))))
		return result
	}

	switch kind {
	case KindImage:
		if detected := detectImageMime(data); detected != "" {
			result.MimeType = detected
		}
		result.DataURL = dataURL(result.MimeType, data)
	case KindVideo, KindAudio, KindPDF:
		result.DataURL = dataURL(result.MimeType, data)
	case KindText:
		if looksLikeTextData(data) {
			result.Text = string(data)
		} else {
			result.Message = "This file is binary and cannot be shown as text."
		}
	default:
		if strings.HasPrefix(result.MimeType, "text/") && looksLikeTextData(data) {
			result.Text = string(data)
		} else {
			result.Message = "No preview available for this file type."
		}
	}
	return result
}
