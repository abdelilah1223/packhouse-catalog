package main

import (
	"fmt"
	"os/exec"
	"time"

	wruntime "github.com/wailsapp/wails/v2/pkg/runtime"
)

// Onboarding stages, reported to the frontend so it can pick the right screen.
// The stage is derived purely from standard signals: libusb enumeration for the
// physical cable and `adb devices -l` for the debugging / authorization state.
const (
	StageNoADB        = "no_adb_binary" // the adb executable is missing on the host
	StageNoUSB        = "no_usb"        // nothing plugged in that looks like a phone
	StageUSBOnly      = "usb_only"      // phone on the cable, USB debugging still off
	StageUnauthorized = "unauthorized"  // debugging on, user has not accepted the prompt
	StageOffline      = "offline"       // device present but adb cannot talk to it
	StageReady        = "ready"         // authorized and usable
)

// DeviceState is a complete, ADB-independent picture of whether a usable phone is
// attached. The onboarding screens are driven entirely by these fields, so the UI
// never has to guess what went wrong.
type DeviceState struct {
	AdbInstalled bool   `json:"adbInstalled"`
	AdbError     string `json:"adbError"`

	USBConnected   bool        `json:"usbConnected"`
	USBError       string      `json:"usbError"`
	USBDeviceCount int         `json:"usbDeviceCount"`
	USBDevices     []USBDevice `json:"usbDevices"`
	AndroidUSB     bool        `json:"androidUsb"`
	USBDevice      *USBDevice  `json:"usbDevice"`

	ADBDeviceID string `json:"adbDeviceId"`
	ADBStatus   string `json:"adbStatus"`
	DeviceModel string `json:"deviceModel"`

	Stage      string `json:"stage"`
	CanProceed bool   `json:"canProceed"`
	Message    string `json:"message"`
}

// CheckDeviceState is a cheap, side-effect-free probe. It never errors on a
// missing cable or a missing device: the absence is reported through Stage.
func (a *App) CheckDeviceState() (*DeviceState, error) {
	state := &DeviceState{}

	if _, err := exec.LookPath("adb"); err == nil {
		state.AdbInstalled = true
	}

	if devices, err := listUSBDevices(); err != nil {
		state.USBError = err.Error()
	} else {
		state.USBDevices = devices
		state.USBDeviceCount = len(devices)
		state.USBConnected = len(devices) > 0
		if best, ok := findAndroidUSBDevice(devices); ok {
			state.AndroidUSB = true
			state.USBDevice = &best
		}
	}

	if state.AdbInstalled {
		if devices, err := a.GetConnectedDevices(); err != nil {
			state.AdbError = err.Error()
		} else {
			applyADBDevices(state, devices)
		}
	}

	state.Stage = deviceStage(state)
	state.CanProceed = state.Stage == StageReady
	state.Message = deviceMessage(state)
	return state, nil
}

// applyADBDevices keeps the most useful device row. A phone that is authorized
// outranks one waiting on the prompt, which outranks an offline/unauthorized stub.
func applyADBDevices(state *DeviceState, devices []Device) {
	rank := func(status string) int {
		switch status {
		case "device":
			return 4
		case "unauthorized":
			return 3
		case "offline":
			return 2
		case "":
			return 0
		default:
			return 1
		}
	}
	best := -1
	for _, device := range devices {
		if score := rank(device.Status); score > best {
			best = score
			state.ADBDeviceID = device.ID
			state.ADBStatus = device.Status
			state.DeviceModel = device.Model
		}
	}
}

func deviceStage(state *DeviceState) string {
	switch {
	case !state.AdbInstalled:
		return StageNoADB
	case state.ADBStatus == "device":
		return StageReady
	case state.ADBStatus == "unauthorized":
		return StageUnauthorized
	case state.ADBStatus != "":
		return StageOffline
	case state.AndroidUSB:
		return StageUSBOnly
	default:
		return StageNoUSB
	}
}

// deviceMessage is an English fallback; the frontend localises by Stage.
func deviceMessage(state *DeviceState) string {
	switch state.Stage {
	case StageNoADB:
		return "The adb tool was not found. Install Android platform-tools and reopen the app."
	case StageReady:
		return "Device connected and authorized."
	case StageUnauthorized:
		return "USB debugging is on. Tap \"Allow\" on the phone screen to authorize this computer."
	case StageOffline:
		return fmt.Sprintf("Device is %s — unplug and replug the cable, then try again.", state.ADBStatus)
	case StageUSBOnly:
		return "A phone is connected over USB, but USB debugging is still disabled."
	default:
		if state.USBDeviceCount > 0 {
			return "USB devices detected, but none look like an Android phone."
		}
		return "No phone detected. Connect it with a USB cable."
	}
}

// RefreshDeviceState re-probes and streams the result so any open screen updates.
func (a *App) RefreshDeviceState() (*DeviceState, error) {
	state, err := a.CheckDeviceState()
	if err != nil {
		return nil, err
	}
	a.emitDeviceState(state)
	return state, nil
}

func (a *App) emitDeviceState(state *DeviceState) {
	if a.ctx == nil || state == nil {
		return
	}
	wruntime.EventsEmit(a.ctx, "device:state", state)
}

// WaitForADBDevice polls the device state, streaming every sample to the UI, until
// the phone is usable or the timeout elapses. It deliberately does not return an
// error on timeout: the caller inspects Stage and can simply retry, which keeps
// the onboarding experience forgiving when the USB link is flaky.
func (a *App) WaitForADBDevice(timeoutMs int) (*DeviceState, error) {
	if timeoutMs <= 0 {
		timeoutMs = 25000
	}
	deadline := time.Now().Add(time.Duration(timeoutMs) * time.Millisecond)

	var last *DeviceState
	for {
		state, err := a.CheckDeviceState()
		if err == nil && state != nil {
			last = state
			a.emitDeviceState(state)
			if state.CanProceed {
				return state, nil
			}
		}
		if !time.Now().Before(deadline) {
			break
		}
		time.Sleep(1200 * time.Millisecond)
	}
	if last == nil {
		last = &DeviceState{Stage: StageNoUSB, Message: "No phone detected. Connect it with a USB cable."}
	}
	a.emitDeviceState(last)
	return last, nil
}

// RequestADBAuthorization restarts the ADB server so a phone whose USB debugging
// was just enabled receives the on-device "Allow USB debugging?" prompt, then
// waits for the user to accept it. Restarting is the standard way to make that
// prompt appear immediately instead of after a manual replug.
func (a *App) RequestADBAuthorization(timeoutMs int) (*DeviceState, error) {
	// Bounded by adbDeviceTimeout so a wedged adb server can never hang the
	// authorization screen; the polling loop below keeps the UI alive regardless.
	_, _ = executeADB("kill-server")
	_, _ = executeADB("start-server")
	return a.WaitForADBDevice(timeoutMs)
}
