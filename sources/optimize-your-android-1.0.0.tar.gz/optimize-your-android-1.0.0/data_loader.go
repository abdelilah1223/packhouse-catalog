package main

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"runtime"
	"strings"
	"sync"
)

// AppData represents the JSON structure for each app in uad_lists.json
type AppData struct {
	List         string   `json:"list"`
	Description  string   `json:"description"`
	Dependencies []string `json:"dependencies"`
	NeededBy     []string `json:"neededBy"`
	Labels       []string `json:"labels"`
	Removal      string   `json:"removal"`
}

// InstalledApp represents an app on the device combined with its JSON data
type InstalledApp struct {
	PackageName string
	Data        AppData
	IsInstalled bool
}

// LoadAppData loads the JSON and compares it against installed apps in parallel
func (a *App) LoadAppData() ([]InstalledApp, error) {
	// 1. Fetch installed packages from the device
	out, err := executeADB("shell", "pm", "list", "packages")
	if err != nil {
		return nil, fmt.Errorf("failed to list packages: %v", err)
	}

	installedPackages := make(map[string]bool)
	lines := strings.Split(out, "\n")
	for _, line := range lines {
		line = strings.TrimSpace(line)
		if strings.HasPrefix(line, "package:") {
			pkg := strings.TrimPrefix(line, "package:")
			installedPackages[pkg] = true
		}
	}

	// 2. Load JSON file
	fileBytes, err := loadAppDataFile()
	if err != nil {
		return nil, err
	}

	var allApps map[string]AppData
	if err := json.Unmarshal(fileBytes, &allApps); err != nil {
		return nil, fmt.Errorf("failed to parse JSON data: %v", err)
	}

	// 3. Parallel Processing (Workers)
	// We split the installed packages into chunks to process them using multiple goroutines.
	// This demonstrates the requested parallel data loader.

	packageList := make([]string, 0, len(installedPackages))
	for pkg := range installedPackages {
		packageList = append(packageList, pkg)
	}

	numWorkers := runtime.NumCPU() // Use all available CPU cores
	chunkSize := (len(packageList) + numWorkers - 1) / numWorkers

	var wg sync.WaitGroup
	results := make(chan []InstalledApp, numWorkers)

	for i := 0; i < numWorkers; i++ {
		start := i * chunkSize
		end := start + chunkSize
		if start >= len(packageList) {
			break
		}
		if end > len(packageList) {
			end = len(packageList)
		}

		wg.Add(1)
		// Worker goroutine
		go func(pkgs []string) {
			defer wg.Done()
			var chunkResult []InstalledApp
			for _, pkg := range pkgs {
				// Check if this package exists in our JSON database
				if data, exists := allApps[pkg]; exists {
					chunkResult = append(chunkResult, InstalledApp{
						PackageName: pkg,
						Data:        data,
						IsInstalled: true,
					})
				} else {
					// Package not in database, mark as unknown
					chunkResult = append(chunkResult, InstalledApp{
						PackageName: pkg,
						Data: AppData{
							Description: "Unknown app. Proceed with caution.",
							Removal:     "Unknown",
						},
						IsInstalled: true,
					})
				}
			}
			results <- chunkResult
		}(packageList[start:end])
	}

	// Close results channel when all workers finish
	go func() {
		wg.Wait()
		close(results)
	}()

	// Collect results
	var finalResult []InstalledApp
	for chunk := range results {
		finalResult = append(finalResult, chunk...)
	}

	return finalResult, nil
}

// UninstallApp uninstalls an app for the main user and reports what the phone
// actually did. Two device behaviours used to reach the UI as a green
// "uninstalled" toast while the app stayed on the phone: some pm builds print
// "Failure …" and still exit 0, and a device can drop the request without a
// word (MIUI blocks it unless "USB debugging (Security settings)" is allowed).
// So the pm output is checked and the package list is re-read afterwards.
func (a *App) UninstallApp(packageName string, isUnsafe bool) error {
	packageName = strings.TrimSpace(packageName)
	if packageName == "" {
		return fmt.Errorf("missing package name")
	}
	if isUnsafe {
		return fmt.Errorf("cannot uninstall %s: Marked as Unsafe", packageName)
	}
	// For system apps, we usually need 'adb shell pm uninstall --user 0 <pkg>'
	out, err := executeADB("shell", "pm", "uninstall", "--user", "0", packageName)
	if err := checkPMOutput(out, err, "uninstall", packageName); err != nil {
		return err
	}
	// An unverifiable device answer (nil list) is left alone: the output check
	// above already rejected the loud failures.
	if installed := listAllPackageNames(); installed != nil && containsPackage(installed, packageName) {
		return fmt.Errorf("could not uninstall %s: the phone still reports it as installed — on MIUI/HyperOS allow “USB debugging (Security settings)” in Developer options, then retry", packageName)
	}
	return nil
}

// containsPackage reports whether a `pm list packages` result includes the
// exact package name (the shell command also matches substrings).
func containsPackage(packages []string, packageName string) bool {
	for _, pkg := range packages {
		if pkg == packageName {
			return true
		}
	}
	return false
}

// checkPMOutput turns a pm command into a real error when the output reports a
// failure (some pm builds print "Failed" and still exit 0). Only failure markers
// at the start of a line count: package names themselves may contain words like
// "error", and a success line reads "Package … new state: …".
func checkPMOutput(out string, err error, action, packageName string) error {
	if err != nil {
		return fmt.Errorf("could not %s %s: %v", action, packageName, err)
	}
	for _, line := range strings.Split(out, "\n") {
		lower := strings.ToLower(strings.TrimSpace(line))
		switch {
		case lower == "":
			continue
		case strings.HasPrefix(lower, "error"),
			strings.HasPrefix(lower, "failed"),
			strings.HasPrefix(lower, "exception"),
			strings.HasPrefix(lower, "java.lang"),
			strings.Contains(lower, "failed to "):
			return fmt.Errorf("could not %s %s: %s", action, packageName, strings.TrimSpace(out))
		}
	}
	return nil
}

// DisableApp disables an installed app for the main user WITHOUT uninstalling
// it, so it can be brought back later. Guarded like uninstall: apps flagged
// unsafe to remove must not be touched.
func (a *App) DisableApp(packageName string, isUnsafe bool) error {
	packageName = strings.TrimSpace(packageName)
	if packageName == "" {
		return fmt.Errorf("missing package name")
	}
	if isUnsafe {
		return fmt.Errorf("cannot disable %s: marked as unsafe", packageName)
	}
	out, err := executeADB("shell", "pm", "disable-user", "--user", "0", packageName)
	return checkPMOutput(out, err, "disable", packageName)
}

// EnableApp re-enables a previously disabled app.
func (a *App) EnableApp(packageName string) error {
	packageName = strings.TrimSpace(packageName)
	if packageName == "" {
		return fmt.Errorf("missing package name")
	}
	out, err := executeADB("shell", "pm", "enable", "--user", "0", packageName)
	return checkPMOutput(out, err, "enable", packageName)
}

func loadAppDataFile() ([]byte, error) {
	candidates := []string{
		filepath.Join("data", "uad_lists.json"),
		filepath.Join(".", "data", "uad_lists.json"),
	}

	if exePath, err := os.Executable(); err == nil {
		candidates = append(candidates, filepath.Join(filepath.Dir(exePath), "data", "uad_lists.json"))
	}

	for _, candidate := range candidates {
		if bytes, err := os.ReadFile(candidate); err == nil {
			return bytes, nil
		}
	}

	if bytes, err := embeddedData.ReadFile("data/uad_lists.json"); err == nil {
		return bytes, nil
	}

	return nil, fmt.Errorf("failed to read JSON data: open data/uad_lists.json: no such file or directory")
}

func loadAppRecommendations() (map[string]AppData, error) {
	fileBytes, err := loadAppDataFile()
	if err != nil {
		return nil, err
	}

	var allApps map[string]AppData
	if err := json.Unmarshal(fileBytes, &allApps); err != nil {
		return nil, fmt.Errorf("failed to parse JSON data: %v", err)
	}
	return allApps, nil
}
