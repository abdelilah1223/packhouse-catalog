package main

import (
	"path/filepath"
	"strings"
)

// File kinds shared across the file browser, recovery scanner and preview engine.
const (
	KindDir      = "dir"
	KindImage    = "image"
	KindVideo    = "video"
	KindAudio    = "audio"
	KindPDF      = "pdf"
	KindText     = "text"
	KindDocument = "document"
	KindArchive  = "archive"
	KindAPK      = "apk"
	KindOther    = "other"
)

var extensionKinds = map[string]string{
	// images
	".jpg": KindImage, ".jpeg": KindImage, ".png": KindImage, ".gif": KindImage,
	".bmp": KindImage, ".webp": KindImage, ".heic": KindImage, ".heif": KindImage,
	".dng": KindImage, ".tif": KindImage, ".tiff": KindImage, ".avif": KindImage,
	// video
	".mp4": KindVideo, ".mov": KindVideo, ".avi": KindVideo, ".mkv": KindVideo,
	".3gp": KindVideo, ".webm": KindVideo, ".m4v": KindVideo, ".flv": KindVideo,
	".ts": KindVideo, ".wmv": KindVideo, ".mpg": KindVideo, ".mpeg": KindVideo,
	// audio
	".mp3": KindAudio, ".m4a": KindAudio, ".aac": KindAudio, ".wav": KindAudio,
	".ogg": KindAudio, ".opus": KindAudio, ".flac": KindAudio, ".amr": KindAudio,
	".mid": KindAudio, ".m4b": KindAudio,
	// documents
	".pdf": KindPDF,
	".txt": KindText, ".log": KindText, ".md": KindText, ".csv": KindText,
	".json": KindText, ".xml": KindText, ".yml": KindText, ".yaml": KindText,
	".html": KindText, ".htm": KindText, ".ini": KindText, ".conf": KindText,
	".srt": KindText, ".vtt": KindText,
	".doc": KindDocument, ".docx": KindDocument, ".xls": KindDocument,
	".xlsx": KindDocument, ".ppt": KindDocument, ".pptx": KindDocument,
	".odt": KindDocument, ".ods": KindDocument, ".rtf": KindDocument,
	// archives
	".zip": KindArchive, ".rar": KindArchive, ".7z": KindArchive,
	".tar": KindArchive, ".gz": KindArchive, ".bz2": KindArchive,
	".xz": KindArchive, ".backup": KindArchive,
	// android packages
	".apk": KindAPK, ".apks": KindAPK, ".aab": KindAPK,
}

var mimeByExtension = map[string]string{
	".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".png": "image/png",
	".gif": "image/gif", ".bmp": "image/bmp", ".webp": "image/webp",
	".heic": "image/heic", ".heif": "image/heif", ".avif": "image/avif",
	".mp4": "video/mp4", ".mov": "video/quicktime", ".avi": "video/x-msvideo",
	".mkv": "video/x-matroska", ".3gp": "video/3gpp", ".webm": "video/webm",
	".m4v": "video/x-m4v",
	".mp3": "audio/mpeg", ".m4a": "audio/mp4", ".aac": "audio/aac",
	".wav": "audio/wav", ".ogg": "audio/ogg", ".opus": "audio/opus",
	".flac": "audio/flac", ".amr": "audio/amr",
	".pdf": "application/pdf",
	".txt": "text/plain", ".log": "text/plain", ".md": "text/markdown",
	".csv": "text/csv", ".json": "application/json", ".xml": "application/xml",
	".html": "text/html", ".htm": "text/html",
	".srt": "text/plain", ".vtt": "text/vtt",
	".zip": "application/zip", ".rar": "application/vnd.rar",
	".7z": "application/x-7z-compressed", ".tar": "application/x-tar",
	".gz":  "application/gzip",
	".apk": "application/vnd.android.package-archive",
}

// fileExtension returns the lower-cased extension (including the leading dot).
func fileExtension(name string) string {
	return strings.ToLower(filepath.Ext(name))
}

// fileKind classifies a file by its extension.
func fileKind(name string) string {
	if kind, ok := extensionKinds[fileExtension(name)]; ok {
		return kind
	}
	return KindOther
}

// fileMime returns a best-effort MIME type for the given file name.
func fileMime(name string) string {
	if mime, ok := mimeByExtension[fileExtension(name)]; ok {
		return mime
	}
	return "application/octet-stream"
}

// kindMatchesMode reports whether a file kind satisfies a recovery/browser mode filter.
func kindMatchesMode(kind, mode string) bool {
	mode = strings.ToLower(strings.TrimSpace(mode))
	switch mode {
	case "", "all", "any":
		return true
	case "photo", "photos", "image", "images":
		return kind == KindImage
	case "video", "videos":
		return kind == KindVideo
	case "audio", "music":
		return kind == KindAudio
	case "pdf", "pdfs":
		return kind == KindPDF || kind == KindDocument
	case "doc", "document", "documents", "file", "files":
		return kind == KindDocument || kind == KindPDF || kind == KindText
	case "text", "texts", "notes":
		return kind == KindText
	case "archive", "archives", "zip":
		return kind == KindArchive
	case "apk", "apks", "app", "apps":
		return kind == KindAPK
	}
	// "phone" mode is resolved by path markers in the recovery scanner, not here.
	return true
}
