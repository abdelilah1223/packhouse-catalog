package main

import (
	"encoding/base64"
	"fmt"
	"os"
	"path/filepath"
	"runtime"
	"strconv"
	"strings"
)

// Icon extraction reads entries out of each app's APK on the device with its own
// `unzip`, which is present on virtually every Android build. Only the entries
// that are actually needed — the binary manifest, the resource table and the
// chosen image — cross the wire, versus pulling a multi-megabyte APK per app.
//
// The icon itself is resolved the way Android resolves it (android:icon on the
// <application> element, followed through resources.arsc), which also works for
// APKs whose resources have been renamed by obfuscation. See iconpipeline.go for
// the APK-pull mode, the generic system icon and the batch/extraction plumbing.
//
// Results are cached on the host so a second launch is instant.

// appCacheDir returns (and creates) a per-purpose cache directory on the host.
func appCacheDir(purpose string) string {
	base, err := os.UserCacheDir()
	if err != nil || base == "" {
		base = os.TempDir()
	}
	dir := filepath.Join(base, "optimize-your-android", purpose)
	_ = os.MkdirAll(dir, 0o755)
	return dir
}

func sanitizeFileComponent(value string) string {
	if strings.TrimSpace(value) == "" {
		return "item"
	}
	replacer := strings.NewReplacer(
		"/", "_", "\\", "_", ":", "_", "*", "_", "?", "_",
		"\"", "_", "<", "_", ">", "_", "|", "_", "\n", "_", "\r", "_",
	)
	out := replacer.Replace(strings.TrimSpace(value))
	if out == "" {
		out = "item"
	}
	if len(out) > 160 {
		out = out[len(out)-160:]
	}
	return out
}

type apkEntry struct {
	name string
	size int64
}

// listApkEntries asks the device to list the entries inside an APK.
func listApkEntries(apkPath string) ([]apkEntry, error) {
	out, err := executeADB("shell", "unzip", "-l", deviceQuote(apkPath))
	if err != nil {
		return nil, err
	}

	entries := make([]apkEntry, 0, 64)
	for _, line := range strings.Split(out, "\n") {
		fields := strings.Fields(strings.TrimSpace(line))
		if len(fields) < 4 {
			continue
		}
		size, err := strconv.ParseInt(fields[0], 10, 64)
		if err != nil {
			continue
		}
		name := strings.Join(fields[3:], " ")
		if name == "" {
			continue
		}
		entries = append(entries, apkEntry{name: name, size: size})
	}
	return entries, nil
}

func isIconImageEntry(name string) bool {
	switch fileExtension(name) {
	case ".png", ".webp", ".jpg", ".jpeg":
		return true
	}
	return false
}

func densityRank(name string) int {
	switch {
	case strings.Contains(name, "xxxhdpi"):
		return 9
	case strings.Contains(name, "xxhdpi"):
		return 8
	case strings.Contains(name, "xhdpi"):
		return 7
	case strings.Contains(name, "hdpi"):
		return 6
	case strings.Contains(name, "mdpi"):
		return 5
	case strings.Contains(name, "nodpi"):
		return 4
	case strings.Contains(name, "ldpi"):
		return 2
	}
	return 3
}

// iconNameMarkers are the resource-name patterns that identify a launcher icon.
// Requiring one of these is what stops us from grabbing an arbitrary drawable
// (a flag, a menu glyph, a notification badge) and showing it as the app icon.
var iconNameMarkers = []string{
	"launcher", "app_icon", "appicon", "icon_app", "application_icon", "app_logo",
}

func isIconNameCandidate(lower string) bool {
	for _, marker := range iconNameMarkers {
		if strings.Contains(lower, marker) {
			return true
		}
	}
	return false
}

// scoreIconEntry ranks candidate launcher icons; -1 means "not a candidate".
func scoreIconEntry(name string) int {
	lower := strings.ToLower(name)
	if !isIconImageEntry(lower) || !isIconNameCandidate(lower) {
		return -1
	}

	score := 0
	if strings.HasPrefix(lower, "res/") {
		score += 5
	}
	if strings.Contains(lower, "mipmap") {
		score += 20
	} else if strings.Contains(lower, "drawable") {
		score += 4
	}

	switch {
	case strings.Contains(lower, "launcher_foreground"):
		// Only the front layer of an adaptive icon; usable but incomplete.
		score += 2
	case strings.Contains(lower, "launcher_round"):
		score += 10
	case strings.Contains(lower, "ic_launcher"):
		score += 24
	case strings.Contains(lower, "launcher"):
		score += 14
	case strings.Contains(lower, "app_icon") || strings.Contains(lower, "appicon"):
		score += 16
	}

	if strings.Contains(lower, "notification") || strings.Contains(lower, "splash") || strings.Contains(lower, "badge") {
		score -= 20
	}

	score += densityRank(lower)
	if strings.Contains(lower, "anydpi") {
		score -= 4
	}
	return score
}

func pickIconEntry(entries []apkEntry) (apkEntry, bool) {
	var best apkEntry
	bestScore := -1
	for _, entry := range entries {
		score := scoreIconEntry(entry.name)
		if score < 0 {
			continue
		}
		// Prefer higher-ranked names, then larger (usually higher density) files.
		if score > bestScore || (score == bestScore && entry.size > best.size) {
			bestScore = score
			best = entry
		}
	}
	return best, bestScore >= 0
}

// detectImageMime sniffs an image container from its magic bytes.
func detectImageMime(data []byte) string {
	switch {
	case len(data) >= 8 && string(data[:8]) == "\x89PNG\r\n\x1a\n":
		return "image/png"
	case len(data) >= 3 && data[0] == 0xFF && data[1] == 0xD8 && data[2] == 0xFF:
		return "image/jpeg"
	case len(data) >= 12 && string(data[:4]) == "RIFF" && string(data[8:12]) == "WEBP":
		return "image/webp"
	case len(data) >= 6 && (string(data[:6]) == "GIF87a" || string(data[:6]) == "GIF89a"):
		return "image/gif"
	case len(data) >= 2 && data[0] == 'B' && data[1] == 'M':
		return "image/bmp"
	case len(data) >= 12 && string(data[4:8]) == "ftyp":
		return "image/heic"
	}
	return ""
}

func dataURL(mime string, data []byte) string {
	return "data:" + mime + ";base64," + base64.StdEncoding.EncodeToString(data)
}

// iconCacheVersion is bumped whenever the icon-selection rules change so stale
// (possibly wrong) cached icons from an older build are ignored. v4 avoids stale
// generic-icon decisions from runs where package paths were missing.
const iconCacheVersion = "v4"

func iconCachePath(packageName string) string {
	name := iconCacheVersion + "_" + sanitizeFileComponent(packageName) + ".bin"
	return filepath.Join(appCacheDir("icons"), name)
}

// iconImagePath is the human-readable copy of an app icon. It is written next to
// the raw cache file so the user can browse the extracted icons as real images.
func iconImagePath(packageName, mime string) string {
	ext := ".png"
	switch mime {
	case "image/jpeg":
		ext = ".jpg"
	case "image/webp":
		ext = ".webp"
	case "image/gif":
		ext = ".gif"
	case "image/bmp":
		ext = ".bmp"
	case "image/heic":
		ext = ".heic"
	case "image/heif":
		ext = ".heif"
	case "image/avif":
		ext = ".avif"
	case "image/x-icon":
		ext = ".ico"
	case "image/svg+xml":
		ext = ".svg"
	}
	return filepath.Join(appCacheDir("icons"), sanitizeFileComponent(packageName)+ext)
}

// readIconCache returns (data, true) when a cached decision exists. An empty
// non-nil slice means "we looked and this app has no extractable icon".
func readIconCache(packageName string) ([]byte, bool) {
	path := iconCachePath(packageName)
	info, err := os.Stat(path)
	if err != nil || info.IsDir() {
		return nil, false
	}
	data, err := os.ReadFile(path)
	if err != nil {
		return nil, false
	}
	return data, true
}

// writeIconCache persists the raw bytes as the authoritative cache entry, plus a
// readable image file named after the app's identifier (package name), and
// returns the path of the readable copy (empty when the app has no extractable
// icon). Errors are returned instead of swallowed so callers can tell the user
// when extracted icons could not be saved.
func writeIconCache(packageName string, data []byte) (string, error) {
	if data == nil {
		data = []byte{}
	}
	if err := os.MkdirAll(appCacheDir("icons"), 0o755); err != nil {
		return "", fmt.Errorf("icon cache folder is not writable: %v", err)
	}
	cachePath := iconCachePath(packageName)
	if err := os.WriteFile(cachePath, data, 0o644); err != nil {
		return "", fmt.Errorf("could not save the icon cache entry for %s: %v", packageName, err)
	}
	// Ensure predictable permissions on created files to avoid subsequent
	// writes failing on restrictive platforms or odd umask settings.
	_ = os.Chmod(cachePath, 0o644)
	if len(data) == 0 {
		return "", nil
	}
	mime := detectImageMime(data)
	if mime == "" {
		mime = "image/png"
	}
	path := iconImagePath(packageName, mime)
	if err := os.WriteFile(path, data, 0o644); err != nil {
		return "", fmt.Errorf("could not save the icon image for %s: %v", packageName, err)
	}
	_ = os.Chmod(path, 0o644)
	return path, nil
}

// extractViaPull is the fallback for devices without `unzip`: pull the APK and
// read the best icon entry locally. Guarded by a size cap so we never stall.
func extractViaPull(apkPath string) []byte {
	const maxAPKBytes = 60 * 1024 * 1024
	if size, err := remoteFileSize(apkPath); err == nil && size > maxAPKBytes {
		return nil
	}

	tmpDir, err := os.MkdirTemp("", "apk-icon-*")
	if err != nil {
		return nil
	}
	defer os.RemoveAll(tmpDir)

	localPath := filepath.Join(tmpDir, "base.apk")
	if _, err := executeADB("pull", apkPath, localPath); err != nil {
		return nil
	}
	return iconFromLocalAPK(localPath)
}

// fetchIconFromAPKPath reads an icon straight out of an on-device APK. The second
// result reports whether the answer is conclusive: true means the APK was opened
// and inspected, so an empty result may be remembered.
func fetchIconFromAPKPath(apkPath string) ([]byte, bool) {
	apkPath = strings.TrimSpace(apkPath)
	if apkPath == "" {
		return nil, false
	}
	entries, err := listApkEntries(apkPath)
	if err != nil {
		if data := extractViaPull(apkPath); len(data) > 0 {
			return data, true
		}
		return nil, false
	}
	if data := extractAPKIcon(deviceAPKReader{apkPath}, entries); len(data) > 0 {
		return data, true
	}
	if data := extractViaPull(apkPath); len(data) > 0 {
		return data, true
	}
	return nil, true
}

func fetchAppIconBytesForApp(packageName, apkPath string) ([]byte, bool) {
	packageName = strings.TrimSpace(packageName)
	apkPath = strings.TrimSpace(apkPath)

	if data, ok := fetchIconFromAPKPath(apkPath); len(data) > 0 || ok {
		if len(data) > 0 {
			return data, true
		}
		// Keep looking through pm path below before remembering "no icon"; split
		// APK installs can put resources outside the base path reported by -f.
	}

	if packageName != "" {
		if paths, err := getAPKPaths(packageName); err == nil {
			conclusive := false
			for _, path := range paths {
				if path == apkPath {
					continue
				}
				data, ok := fetchIconFromAPKPath(path)
				if len(data) > 0 {
					return data, true
				}
				conclusive = conclusive || ok
			}
			return nil, conclusive || len(paths) > 0
		}
	}

	return nil, false
}

// GetAppIcon returns a data URL for an installed app's launcher icon. When the
// icon cannot be read (a resource-obfuscated APK, for example) it returns the
// generic Android icon rather than an empty string, so a row is never blank.
func (a *App) GetAppIcon(packageName, apkPath string) (string, error) {
	packageName = strings.TrimSpace(packageName)
	if packageName == "" {
		return "", fmt.Errorf("missing package name")
	}

	if data, ok := readIconCache(packageName); ok {
		if len(data) == 0 {
			return systemAppIconDataURL(), nil
		}
		return iconDataURL(data), nil
	}

	if err := a.requireAnyDevice(); err != nil {
		return "", err
	}

	data, conclusive := fetchAppIconBytesForApp(packageName, apkPath)
	if conclusive {
		// Remember the outcome (including "no icon") keyed by the package name so
		// the next launch never reads this APK again. When the write fails we still
		// show the extracted icon — the batch extractor surfaces folder problems.
		_, _ = writeIconCache(packageName, data)
	}
	if len(data) == 0 {
		return systemAppIconDataURL(), nil
	}
	return iconDataURL(data), nil
}

// ExtractAllUserAppIcons extracts launcher icons from the APKs of all
// third-party (user-installed) apps and saves them into the app cache. It
// forces APK-pull mode so the full APK is inspected locally which improves
// accuracy for resource-obfuscated packages.
func (a *App) ExtractAllUserAppIcons(apkFolder string, workers int) ([]IconExtractResult, error) {
	if err := a.requireAnyDevice(); err != nil {
		return nil, err
	}
	installed, err := a.GetInstalledApps()
	if err != nil {
		return nil, err
	}

	targets := make([]AppInfo, 0, len(installed))
	for _, app := range installed {
		if app.IsThirdParty {
			targets = append(targets, app)
		}
	}
	if len(targets) == 0 {
		return nil, nil
	}

	// Default APK folder when not provided.
	if strings.TrimSpace(apkFolder) == "" {
		apkFolder = defaultAPKFolder()
	}
	_ = os.MkdirAll(apkFolder, 0o755)

	// Pick a reasonable default for workers: two per CPU core, capped at 16.
	if workers <= 0 {
		workers = runtime.NumCPU() * 2
		if workers < 1 {
			workers = 1
		}
		if workers > 16 {
			workers = 16
		}
	}

	// Skip cached entries by default to make a first run fast; callers may set
	// SkipCached=false if they want to force re-extraction.
	req := IconExtractRequest{
		Packages:      nil,
		Mode:          "apk",
		APKFolder:     apkFolder,
		Workers:       workers,
		SkipCached:    true,
		GenericSystem: false,
	}
	return a.extractIcons(targets, req, 0, 100), nil
}

func iconDataURL(data []byte) string {
	if len(data) == 0 {
		return ""
	}
	mime := detectImageMime(data)
	if mime == "" {
		mime = "image/png"
	}
	return dataURL(mime, data)
}

// ClearIconCache drops every cached icon so the next visit re-reads the device.
func (a *App) ClearIconCache() error {
	dir := appCacheDir("icons")
	entries, err := os.ReadDir(dir)
	if err != nil {
		return err
	}
	for _, entry := range entries {
		_ = os.RemoveAll(filepath.Join(dir, entry.Name()))
	}
	return nil
}
